--
-- PostgreSQL database dump
--

\restrict eeUbA8mCfJdW8Qe6sd6m9WKed65b098gBKaglXMk8VPPFgfyjSVWSqHi2B6EbFC

-- Dumped from database version 16.13
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: account_status; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE public.account_status AS ENUM (
    'ACTIVE',
    'INACTIVE'
);


ALTER TYPE public.account_status OWNER TO app_user;

--
-- Name: account_type; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE public.account_type AS ENUM (
    'REVENUE',
    'EXPENSE',
    'ASSET',
    'LIABILITY'
);


ALTER TYPE public.account_type OWNER TO app_user;

--
-- Name: assumption_value_type; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE public.assumption_value_type AS ENUM (
    'PERCENTAGE',
    'CURRENCY',
    'INTEGER',
    'DECIMAL',
    'TEXT'
);


ALTER TYPE public.assumption_value_type OWNER TO app_user;

--
-- Name: center_type; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE public.center_type AS ENUM (
    'PROFIT_CENTER',
    'COST_CENTER'
);


ALTER TYPE public.center_type OWNER TO app_user;

--
-- Name: department_band; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE public.department_band AS ENUM (
    'MATERNELLE',
    'ELEMENTAIRE',
    'COLLEGE',
    'LYCEE',
    'NON_ACADEMIC'
);


ALTER TYPE public.department_band OWNER TO app_user;

--
-- Name: grade_band; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE public.grade_band AS ENUM (
    'MATERNELLE',
    'ELEMENTAIRE',
    'COLLEGE',
    'LYCEE'
);


ALTER TYPE public.grade_band OWNER TO app_user;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE public.user_role AS ENUM (
    'Admin',
    'BudgetOwner',
    'Editor',
    'Viewer'
);


ALTER TYPE public.user_role OWNER TO app_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO app_user;

--
-- Name: academic_years; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.academic_years (
    id integer NOT NULL,
    fiscal_year character varying(6) NOT NULL,
    ay1_start date NOT NULL,
    ay1_end date NOT NULL,
    ay2_start date NOT NULL,
    ay2_end date NOT NULL,
    summer_start date NOT NULL,
    summer_end date NOT NULL,
    academic_weeks integer NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer NOT NULL,
    updated_by integer NOT NULL,
    CONSTRAINT chk_academic_weeks CHECK (((academic_weeks >= 1) AND (academic_weeks <= 52))),
    CONSTRAINT chk_date_ordering CHECK (((ay1_start < ay1_end) AND (ay1_end <= summer_start) AND (summer_start < summer_end) AND (summer_end <= ay2_start) AND (ay2_start < ay2_end)))
);


ALTER TABLE public.academic_years OWNER TO app_user;

--
-- Name: academic_years_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.academic_years_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.academic_years_id_seq OWNER TO app_user;

--
-- Name: academic_years_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.academic_years_id_seq OWNED BY public.academic_years.id;


--
-- Name: actuals_import_log; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.actuals_import_log (
    id integer NOT NULL,
    version_id integer NOT NULL,
    module character varying(12) NOT NULL,
    source_file character varying(255) NOT NULL,
    validation_status character varying(10) NOT NULL,
    rows_imported integer DEFAULT 0 NOT NULL,
    imported_by_id integer NOT NULL,
    imported_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.actuals_import_log OWNER TO app_user;

--
-- Name: actuals_import_log_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.actuals_import_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.actuals_import_log_id_seq OWNER TO app_user;

--
-- Name: actuals_import_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.actuals_import_log_id_seq OWNED BY public.actuals_import_log.id;


--
-- Name: assumptions; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.assumptions (
    id integer NOT NULL,
    key character varying(50) NOT NULL,
    value character varying(500) NOT NULL,
    unit character varying(20) NOT NULL,
    section character varying(50) NOT NULL,
    label character varying(100) NOT NULL,
    value_type public.assumption_value_type NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    updated_by integer
);


ALTER TABLE public.assumptions OWNER TO app_user;

--
-- Name: assumptions_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.assumptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.assumptions_id_seq OWNER TO app_user;

--
-- Name: assumptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.assumptions_id_seq OWNED BY public.assumptions.id;


--
-- Name: audit_entries; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.audit_entries (
    id integer NOT NULL,
    user_id integer,
    operation character varying(50) NOT NULL,
    table_name character varying(100),
    record_id integer,
    old_values jsonb,
    new_values jsonb,
    ip_address character varying(45),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    user_email character varying(255),
    session_id character varying(100),
    audit_note text
);


ALTER TABLE public.audit_entries OWNER TO app_user;

--
-- Name: audit_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.audit_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_entries_id_seq OWNER TO app_user;

--
-- Name: audit_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.audit_entries_id_seq OWNED BY public.audit_entries.id;


--
-- Name: budget_versions; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.budget_versions (
    id integer NOT NULL,
    fiscal_year smallint NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(10) NOT NULL,
    status character varying(10) DEFAULT 'Draft'::character varying NOT NULL,
    description text,
    data_source character varying(12) DEFAULT 'CALCULATED'::character varying NOT NULL,
    source_version_id integer,
    modification_count integer DEFAULT 0 NOT NULL,
    stale_modules text[] DEFAULT ARRAY[]::text[],
    created_by_id integer NOT NULL,
    published_at timestamp with time zone,
    locked_at timestamp with time zone,
    archived_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    updated_by_id integer
);


ALTER TABLE public.budget_versions OWNER TO app_user;

--
-- Name: budget_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.budget_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_versions_id_seq OWNER TO app_user;

--
-- Name: budget_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.budget_versions_id_seq OWNED BY public.budget_versions.id;


--
-- Name: calculation_audit_log; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.calculation_audit_log (
    id integer NOT NULL,
    version_id integer,
    run_id uuid NOT NULL,
    module character varying(20) DEFAULT 'ENROLLMENT'::character varying NOT NULL,
    status character varying(20) DEFAULT 'STARTED'::character varying NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    duration_ms integer,
    input_summary jsonb,
    output_summary jsonb,
    triggered_by integer
);


ALTER TABLE public.calculation_audit_log OWNER TO app_user;

--
-- Name: calculation_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.calculation_audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.calculation_audit_log_id_seq OWNER TO app_user;

--
-- Name: calculation_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.calculation_audit_log_id_seq OWNED BY public.calculation_audit_log.id;


--
-- Name: category_monthly_costs; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.category_monthly_costs (
    id integer NOT NULL,
    version_id integer NOT NULL,
    month smallint NOT NULL,
    category character varying(40) NOT NULL,
    amount numeric(15,4) NOT NULL,
    calculated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    calculated_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.category_monthly_costs OWNER TO app_user;

--
-- Name: category_monthly_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.category_monthly_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.category_monthly_costs_id_seq OWNER TO app_user;

--
-- Name: category_monthly_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.category_monthly_costs_id_seq OWNED BY public.category_monthly_costs.id;


--
-- Name: chart_of_accounts; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.chart_of_accounts (
    id integer NOT NULL,
    account_code character varying(10) NOT NULL,
    account_name character varying(100) NOT NULL,
    type public.account_type NOT NULL,
    ifrs_category character varying(100) NOT NULL,
    center_type public.center_type NOT NULL,
    description character varying(500),
    status public.account_status DEFAULT 'ACTIVE'::public.account_status NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer NOT NULL,
    updated_by integer NOT NULL,
    CONSTRAINT chk_account_code CHECK (((account_code)::text ~ '^[A-Z0-9]{3,10}$'::text))
);


ALTER TABLE public.chart_of_accounts OWNER TO app_user;

--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.chart_of_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chart_of_accounts_id_seq OWNER TO app_user;

--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.chart_of_accounts_id_seq OWNED BY public.chart_of_accounts.id;


--
-- Name: cohort_parameters; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.cohort_parameters (
    id integer NOT NULL,
    version_id integer NOT NULL,
    grade_level character varying(10) NOT NULL,
    retention_rate numeric(5,4) DEFAULT 0.97 NOT NULL,
    lateral_entry_count integer DEFAULT 0 NOT NULL,
    lateral_weight_fr numeric(5,4) DEFAULT 0 NOT NULL,
    lateral_weight_nat numeric(5,4) DEFAULT 0 NOT NULL,
    lateral_weight_aut numeric(5,4) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.cohort_parameters OWNER TO app_user;

--
-- Name: cohort_parameters_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.cohort_parameters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cohort_parameters_id_seq OWNER TO app_user;

--
-- Name: cohort_parameters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.cohort_parameters_id_seq OWNED BY public.cohort_parameters.id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.departments (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    label character varying(100) NOT NULL,
    band_mapping public.department_band NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer NOT NULL,
    updated_by integer NOT NULL,
    CONSTRAINT chk_department_code CHECK (((code)::text ~ '^[A-Z_]{2,20}$'::text))
);


ALTER TABLE public.departments OWNER TO app_user;

--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.departments_id_seq OWNER TO app_user;

--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;


--
-- Name: dhg_grille_config; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.dhg_grille_config (
    id integer NOT NULL,
    grade_level character varying(10) NOT NULL,
    subject character varying(100) NOT NULL,
    dhg_type character varying(20) DEFAULT 'Structural'::character varying NOT NULL,
    hours_per_week_per_section numeric(5,2) NOT NULL,
    effective_from_year integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dhg_grille_config OWNER TO app_user;

--
-- Name: dhg_grille_config_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.dhg_grille_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dhg_grille_config_id_seq OWNER TO app_user;

--
-- Name: dhg_grille_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.dhg_grille_config_id_seq OWNED BY public.dhg_grille_config.id;


--
-- Name: dhg_requirements; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.dhg_requirements (
    id integer NOT NULL,
    version_id integer NOT NULL,
    academic_period character varying(3) NOT NULL,
    grade_level character varying(10) NOT NULL,
    headcount integer DEFAULT 0 NOT NULL,
    max_class_size integer NOT NULL,
    sections_needed integer DEFAULT 0 NOT NULL,
    utilization numeric(5,1) DEFAULT 0 NOT NULL,
    alert character varying(10),
    recruitment_slots integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    total_weekly_hours numeric(10,4) DEFAULT 0 NOT NULL,
    total_annual_hours numeric(10,4) DEFAULT 0 NOT NULL,
    fte numeric(7,4) DEFAULT 0 NOT NULL
);


ALTER TABLE public.dhg_requirements OWNER TO app_user;

--
-- Name: dhg_requirements_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.dhg_requirements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dhg_requirements_id_seq OWNER TO app_user;

--
-- Name: dhg_requirements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.dhg_requirements_id_seq OWNED BY public.dhg_requirements.id;


--
-- Name: discount_policies; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.discount_policies (
    id integer NOT NULL,
    version_id integer NOT NULL,
    tariff character varying(10) NOT NULL,
    nationality character varying(10),
    discount_rate numeric(7,6) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer NOT NULL,
    updated_by integer
);


ALTER TABLE public.discount_policies OWNER TO app_user;

--
-- Name: discount_policies_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.discount_policies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.discount_policies_id_seq OWNER TO app_user;

--
-- Name: discount_policies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.discount_policies_id_seq OWNED BY public.discount_policies.id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    version_id integer NOT NULL,
    employee_code character varying(20) NOT NULL,
    name character varying(200) NOT NULL,
    function_role character varying(100) NOT NULL,
    department character varying(50) NOT NULL,
    status character varying(10) DEFAULT 'Existing'::character varying NOT NULL,
    joining_date date NOT NULL,
    payment_method character varying(50) NOT NULL,
    is_saudi boolean DEFAULT false NOT NULL,
    is_ajeer boolean DEFAULT false NOT NULL,
    is_teaching boolean DEFAULT false NOT NULL,
    hourly_percentage numeric(5,4) DEFAULT 1.0000 NOT NULL,
    base_salary bytea NOT NULL,
    housing_allowance bytea NOT NULL,
    transport_allowance bytea NOT NULL,
    responsibility_premium bytea DEFAULT public.pgp_sym_encrypt('0.0000'::text, current_setting('app.encryption_key'::text)) NOT NULL,
    hsa_amount bytea DEFAULT public.pgp_sym_encrypt('0.0000'::text, current_setting('app.encryption_key'::text)) NOT NULL,
    augmentation bytea DEFAULT public.pgp_sym_encrypt('0.0000'::text, current_setting('app.encryption_key'::text)) NOT NULL,
    augmentation_effective_date date,
    ajeer_annual_levy numeric(15,4) DEFAULT 0 NOT NULL,
    ajeer_monthly_fee numeric(15,4) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer NOT NULL,
    updated_by integer
);


ALTER TABLE public.employees OWNER TO app_user;

--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employees_id_seq OWNER TO app_user;

--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: enrollment_detail; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.enrollment_detail (
    id integer NOT NULL,
    version_id integer NOT NULL,
    academic_period character varying(3) NOT NULL,
    grade_level character varying(10) NOT NULL,
    nationality character varying(10) NOT NULL,
    tariff character varying(10) NOT NULL,
    headcount integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer NOT NULL,
    updated_by integer
);


ALTER TABLE public.enrollment_detail OWNER TO app_user;

--
-- Name: enrollment_detail_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.enrollment_detail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.enrollment_detail_id_seq OWNER TO app_user;

--
-- Name: enrollment_detail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.enrollment_detail_id_seq OWNED BY public.enrollment_detail.id;


--
-- Name: enrollment_headcount; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.enrollment_headcount (
    id integer NOT NULL,
    version_id integer NOT NULL,
    academic_period character varying(3) NOT NULL,
    grade_level character varying(10) NOT NULL,
    headcount integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer NOT NULL,
    updated_by integer
);


ALTER TABLE public.enrollment_headcount OWNER TO app_user;

--
-- Name: enrollment_headcount_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.enrollment_headcount_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.enrollment_headcount_id_seq OWNER TO app_user;

--
-- Name: enrollment_headcount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.enrollment_headcount_id_seq OWNED BY public.enrollment_headcount.id;


--
-- Name: eos_provisions; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.eos_provisions (
    id integer NOT NULL,
    version_id integer NOT NULL,
    employee_id integer NOT NULL,
    years_of_service numeric(7,4) NOT NULL,
    eos_base numeric(15,4) NOT NULL,
    eos_annual numeric(15,4) NOT NULL,
    eos_monthly_accrual numeric(15,4) NOT NULL,
    as_of_date date NOT NULL,
    calculated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.eos_provisions OWNER TO app_user;

--
-- Name: eos_provisions_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.eos_provisions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.eos_provisions_id_seq OWNER TO app_user;

--
-- Name: eos_provisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.eos_provisions_id_seq OWNED BY public.eos_provisions.id;


--
-- Name: fee_grids; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.fee_grids (
    id integer NOT NULL,
    version_id integer NOT NULL,
    academic_period character varying(3) NOT NULL,
    grade_level character varying(10) NOT NULL,
    nationality character varying(10) NOT NULL,
    tariff character varying(10) NOT NULL,
    dai numeric(15,4) DEFAULT 0 NOT NULL,
    tuition_ttc numeric(15,4) NOT NULL,
    tuition_ht numeric(15,4) NOT NULL,
    term1_amount numeric(15,4) DEFAULT 0 NOT NULL,
    term2_amount numeric(15,4) DEFAULT 0 NOT NULL,
    term3_amount numeric(15,4) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer NOT NULL,
    updated_by integer
);


ALTER TABLE public.fee_grids OWNER TO app_user;

--
-- Name: fee_grids_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.fee_grids_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fee_grids_id_seq OWNER TO app_user;

--
-- Name: fee_grids_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.fee_grids_id_seq OWNED BY public.fee_grids.id;


--
-- Name: fiscal_periods; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.fiscal_periods (
    id integer NOT NULL,
    fiscal_year smallint NOT NULL,
    month smallint NOT NULL,
    status character varying(10) DEFAULT 'Draft'::character varying NOT NULL,
    actual_version_id integer,
    locked_at timestamp with time zone,
    locked_by_id integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    updated_by_id integer
);


ALTER TABLE public.fiscal_periods OWNER TO app_user;

--
-- Name: fiscal_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.fiscal_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fiscal_periods_id_seq OWNER TO app_user;

--
-- Name: fiscal_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.fiscal_periods_id_seq OWNED BY public.fiscal_periods.id;


--
-- Name: grade_levels; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.grade_levels (
    id integer NOT NULL,
    grade_code character varying(10) NOT NULL,
    grade_name character varying(60) NOT NULL,
    band public.grade_band NOT NULL,
    max_class_size integer NOT NULL,
    plancher_pct numeric(5,4) NOT NULL,
    cible_pct numeric(5,4) NOT NULL,
    plafond_pct numeric(5,4) NOT NULL,
    display_order integer NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT chk_max_class_size CHECK (((max_class_size >= 1) AND (max_class_size <= 50))),
    CONSTRAINT chk_pct_ordering CHECK (((plancher_pct <= cible_pct) AND (cible_pct <= plafond_pct)))
);


ALTER TABLE public.grade_levels OWNER TO app_user;

--
-- Name: grade_levels_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.grade_levels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.grade_levels_id_seq OWNER TO app_user;

--
-- Name: grade_levels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.grade_levels_id_seq OWNED BY public.grade_levels.id;


--
-- Name: monthly_budget_summary; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.monthly_budget_summary (
    id integer NOT NULL,
    version_id integer NOT NULL,
    month smallint NOT NULL,
    revenue_ht numeric(15,4) DEFAULT 0 NOT NULL,
    staff_costs numeric(15,4) DEFAULT 0 NOT NULL,
    net_profit numeric(15,4) DEFAULT 0 NOT NULL,
    calculated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.monthly_budget_summary OWNER TO app_user;

--
-- Name: monthly_budget_summary_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.monthly_budget_summary_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.monthly_budget_summary_id_seq OWNER TO app_user;

--
-- Name: monthly_budget_summary_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.monthly_budget_summary_id_seq OWNED BY public.monthly_budget_summary.id;


--
-- Name: monthly_other_revenue; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.monthly_other_revenue (
    id integer NOT NULL,
    version_id integer NOT NULL,
    scenario_name character varying(20) DEFAULT 'Base'::character varying NOT NULL,
    line_item_name text NOT NULL,
    ifrs_category character varying(50) NOT NULL,
    executive_category character varying(40),
    month smallint NOT NULL,
    amount numeric(15,4) DEFAULT 0 NOT NULL,
    calculated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    calculated_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.monthly_other_revenue OWNER TO app_user;

--
-- Name: monthly_other_revenue_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.monthly_other_revenue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.monthly_other_revenue_id_seq OWNER TO app_user;

--
-- Name: monthly_other_revenue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.monthly_other_revenue_id_seq OWNED BY public.monthly_other_revenue.id;


--
-- Name: monthly_revenue; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.monthly_revenue (
    id integer NOT NULL,
    version_id integer NOT NULL,
    scenario_name character varying(20) DEFAULT 'Base'::character varying NOT NULL,
    academic_period character varying(3) NOT NULL,
    grade_level character varying(10) NOT NULL,
    nationality character varying(10) NOT NULL,
    tariff character varying(10) NOT NULL,
    month smallint NOT NULL,
    gross_revenue_ht numeric(15,4) DEFAULT 0 NOT NULL,
    discount_amount numeric(15,4) DEFAULT 0 NOT NULL,
    scholarship_deduction numeric(15,4) DEFAULT 0 NOT NULL,
    net_revenue_ht numeric(15,4) DEFAULT 0 NOT NULL,
    vat_amount numeric(15,4) DEFAULT 0 NOT NULL,
    calculated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    calculated_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.monthly_revenue OWNER TO app_user;

--
-- Name: monthly_revenue_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.monthly_revenue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.monthly_revenue_id_seq OWNER TO app_user;

--
-- Name: monthly_revenue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.monthly_revenue_id_seq OWNED BY public.monthly_revenue.id;


--
-- Name: monthly_staff_costs; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.monthly_staff_costs (
    id integer NOT NULL,
    version_id integer NOT NULL,
    employee_id integer NOT NULL,
    month smallint NOT NULL,
    base_gross numeric(15,4) NOT NULL,
    adjusted_gross numeric(15,4) NOT NULL,
    housing_allowance numeric(15,4) DEFAULT 0 NOT NULL,
    transport_allowance numeric(15,4) DEFAULT 0 NOT NULL,
    responsibility_premium numeric(15,4) DEFAULT 0 NOT NULL,
    hsa_amount numeric(15,4) DEFAULT 0 NOT NULL,
    gosi_amount numeric(15,4) DEFAULT 0 NOT NULL,
    ajeer_amount numeric(15,4) DEFAULT 0 NOT NULL,
    eos_monthly_accrual numeric(15,4) DEFAULT 0 NOT NULL,
    total_cost numeric(15,4) NOT NULL,
    calculated_at timestamp with time zone DEFAULT now() NOT NULL,
    calculated_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.monthly_staff_costs OWNER TO app_user;

--
-- Name: monthly_staff_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.monthly_staff_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.monthly_staff_costs_id_seq OWNER TO app_user;

--
-- Name: monthly_staff_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.monthly_staff_costs_id_seq OWNED BY public.monthly_staff_costs.id;


--
-- Name: nationalities; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.nationalities (
    id integer NOT NULL,
    code character varying(5) NOT NULL,
    label character varying(100) NOT NULL,
    vat_exempt boolean DEFAULT false NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer NOT NULL,
    updated_by integer NOT NULL,
    CONSTRAINT chk_nationality_code CHECK (((code)::text ~ '^[A-Z]{2,5}$'::text))
);


ALTER TABLE public.nationalities OWNER TO app_user;

--
-- Name: nationalities_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.nationalities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nationalities_id_seq OWNER TO app_user;

--
-- Name: nationalities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.nationalities_id_seq OWNED BY public.nationalities.id;


--
-- Name: nationality_breakdown; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.nationality_breakdown (
    id integer NOT NULL,
    version_id integer NOT NULL,
    academic_period character varying(3) NOT NULL,
    grade_level character varying(10) NOT NULL,
    nationality character varying(10) NOT NULL,
    weight numeric(5,4) DEFAULT 0 NOT NULL,
    headcount integer DEFAULT 0 NOT NULL,
    is_overridden boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.nationality_breakdown OWNER TO app_user;

--
-- Name: nationality_breakdown_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.nationality_breakdown_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nationality_breakdown_id_seq OWNER TO app_user;

--
-- Name: nationality_breakdown_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.nationality_breakdown_id_seq OWNED BY public.nationality_breakdown.id;


--
-- Name: other_revenue_items; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.other_revenue_items (
    id integer NOT NULL,
    version_id integer NOT NULL,
    line_item_name text NOT NULL,
    annual_amount numeric(15,4) NOT NULL,
    distribution_method character varying(20) NOT NULL,
    weight_array jsonb,
    specific_months integer[],
    ifrs_category character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer NOT NULL,
    updated_by integer
);


ALTER TABLE public.other_revenue_items OWNER TO app_user;

--
-- Name: other_revenue_items_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.other_revenue_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.other_revenue_items_id_seq OWNER TO app_user;

--
-- Name: other_revenue_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.other_revenue_items_id_seq OWNED BY public.other_revenue_items.id;


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.refresh_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token_hash character varying(255) NOT NULL,
    family_id uuid NOT NULL,
    is_revoked boolean DEFAULT false NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.refresh_tokens OWNER TO app_user;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.refresh_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.refresh_tokens_id_seq OWNER TO app_user;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.refresh_tokens_id_seq OWNED BY public.refresh_tokens.id;


--
-- Name: schema_version; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.schema_version (
    id integer DEFAULT 1 NOT NULL,
    version text DEFAULT '0.0.1'::text NOT NULL,
    applied_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.schema_version OWNER TO app_user;

--
-- Name: system_config; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.system_config (
    key character varying(100) NOT NULL,
    value text NOT NULL,
    data_type character varying(20) DEFAULT 'string'::character varying NOT NULL,
    description text,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by integer
);


ALTER TABLE public.system_config OWNER TO app_user;

--
-- Name: tariffs; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.tariffs (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    label character varying(100) NOT NULL,
    description character varying(500),
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer NOT NULL,
    updated_by integer NOT NULL,
    CONSTRAINT chk_tariff_code CHECK (((code)::text ~ '^[A-Z0-9+]{2,10}$'::text))
);


ALTER TABLE public.tariffs OWNER TO app_user;

--
-- Name: tariffs_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.tariffs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tariffs_id_seq OWNER TO app_user;

--
-- Name: tariffs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.tariffs_id_seq OWNED BY public.tariffs.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role public.user_role DEFAULT 'Viewer'::public.user_role NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    failed_attempts integer DEFAULT 0 NOT NULL,
    locked_until timestamp with time zone,
    force_password_reset boolean DEFAULT false NOT NULL,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.users OWNER TO app_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO app_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: academic_years id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.academic_years ALTER COLUMN id SET DEFAULT nextval('public.academic_years_id_seq'::regclass);


--
-- Name: actuals_import_log id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.actuals_import_log ALTER COLUMN id SET DEFAULT nextval('public.actuals_import_log_id_seq'::regclass);


--
-- Name: assumptions id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.assumptions ALTER COLUMN id SET DEFAULT nextval('public.assumptions_id_seq'::regclass);


--
-- Name: audit_entries id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.audit_entries ALTER COLUMN id SET DEFAULT nextval('public.audit_entries_id_seq'::regclass);


--
-- Name: budget_versions id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.budget_versions ALTER COLUMN id SET DEFAULT nextval('public.budget_versions_id_seq'::regclass);


--
-- Name: calculation_audit_log id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.calculation_audit_log ALTER COLUMN id SET DEFAULT nextval('public.calculation_audit_log_id_seq'::regclass);


--
-- Name: category_monthly_costs id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.category_monthly_costs ALTER COLUMN id SET DEFAULT nextval('public.category_monthly_costs_id_seq'::regclass);


--
-- Name: chart_of_accounts id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.chart_of_accounts ALTER COLUMN id SET DEFAULT nextval('public.chart_of_accounts_id_seq'::regclass);


--
-- Name: cohort_parameters id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.cohort_parameters ALTER COLUMN id SET DEFAULT nextval('public.cohort_parameters_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: dhg_grille_config id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.dhg_grille_config ALTER COLUMN id SET DEFAULT nextval('public.dhg_grille_config_id_seq'::regclass);


--
-- Name: dhg_requirements id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.dhg_requirements ALTER COLUMN id SET DEFAULT nextval('public.dhg_requirements_id_seq'::regclass);


--
-- Name: discount_policies id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.discount_policies ALTER COLUMN id SET DEFAULT nextval('public.discount_policies_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: enrollment_detail id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_detail ALTER COLUMN id SET DEFAULT nextval('public.enrollment_detail_id_seq'::regclass);


--
-- Name: enrollment_headcount id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_headcount ALTER COLUMN id SET DEFAULT nextval('public.enrollment_headcount_id_seq'::regclass);


--
-- Name: eos_provisions id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.eos_provisions ALTER COLUMN id SET DEFAULT nextval('public.eos_provisions_id_seq'::regclass);


--
-- Name: fee_grids id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.fee_grids ALTER COLUMN id SET DEFAULT nextval('public.fee_grids_id_seq'::regclass);


--
-- Name: fiscal_periods id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.fiscal_periods ALTER COLUMN id SET DEFAULT nextval('public.fiscal_periods_id_seq'::regclass);


--
-- Name: grade_levels id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.grade_levels ALTER COLUMN id SET DEFAULT nextval('public.grade_levels_id_seq'::regclass);


--
-- Name: monthly_budget_summary id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_budget_summary ALTER COLUMN id SET DEFAULT nextval('public.monthly_budget_summary_id_seq'::regclass);


--
-- Name: monthly_other_revenue id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_other_revenue ALTER COLUMN id SET DEFAULT nextval('public.monthly_other_revenue_id_seq'::regclass);


--
-- Name: monthly_revenue id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_revenue ALTER COLUMN id SET DEFAULT nextval('public.monthly_revenue_id_seq'::regclass);


--
-- Name: monthly_staff_costs id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_staff_costs ALTER COLUMN id SET DEFAULT nextval('public.monthly_staff_costs_id_seq'::regclass);


--
-- Name: nationalities id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.nationalities ALTER COLUMN id SET DEFAULT nextval('public.nationalities_id_seq'::regclass);


--
-- Name: nationality_breakdown id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.nationality_breakdown ALTER COLUMN id SET DEFAULT nextval('public.nationality_breakdown_id_seq'::regclass);


--
-- Name: other_revenue_items id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.other_revenue_items ALTER COLUMN id SET DEFAULT nextval('public.other_revenue_items_id_seq'::regclass);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('public.refresh_tokens_id_seq'::regclass);


--
-- Name: tariffs id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.tariffs ALTER COLUMN id SET DEFAULT nextval('public.tariffs_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
f0ee2678-c855-4e02-a119-201367c0df8e	c08c6c76832d20257875a469ba00ec7f46396d9de0b80c75bd21cee14307e7d8	2026-03-08 19:37:29.938412+00	20260308180000_cohort_nationality	\N	\N	2026-03-08 19:37:29.916057+00	1
530eaf6c-d507-4a52-b85f-03166bd05321	1da64488e702dd1c9f706318a8eb93ceceeb428087dbed724fb1cad7dc34a84c	2026-03-07 22:17:22.941822+00	20260305155638_init	\N	\N	2026-03-07 22:17:22.934931+00	1
404893ed-afd9-40d8-9bef-45be0c50c360	cb60d75c908faa8e383f034413250a79afff01051787975c87e3d48faf53cdfa	2026-03-07 22:17:22.973549+00	20260305200000_auth_and_versions	\N	\N	2026-03-07 22:17:22.942483+00	1
84136bcc-f892-496f-87d5-84050f4404d3	be31ffebc34d9f4624fd7f79cd19bf15b697f201442859d5823ab3b363b5dc3f	2026-03-07 22:17:22.996449+00	20260306120000_master_data	\N	\N	2026-03-07 22:17:22.974023+00	1
4f00dc94-364f-43c2-adcd-7876c7814ce2	9994e41ae6b54149ef1f1fd8f5c876376748a5c35e71741b2f560286e8d3397e	2026-03-09 19:02:18.652333+00	20260309100000_add_staffing_models	\N	\N	2026-03-09 19:02:18.610246+00	1
454f6b9d-3d65-4d0c-8cda-05aadae9df4e	5814805fac983e8a6bee3d69ac91aee8981bfcf0f366bd4d8b964c3c176b6876	2026-03-07 22:17:23.006664+00	20260307120000_add_enrollment_tables	\N	\N	2026-03-07 22:17:22.997003+00	1
c37fa2c8-9339-4a8c-ad9d-b0db53771dad	d1ea2dc5c79b52579ce172bccd7670bb76ec5c0c1a7a79c54a019bae32debd09	\N	20260307141339_revenue_tables	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260307141339_revenue_tables\n\nDatabase error code: 42P01\n\nDatabase error:\nERROR: relation "calculation_audit_log" does not exist\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42P01), message: "relation \\"calculation_audit_log\\" does not exist", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("namespace.c"), line: Some(434), routine: Some("RangeVarGetRelidExtended") }\n\n	2026-03-07 22:18:58.114561+00	2026-03-07 22:17:23.007153+00	0
da0b3ab0-acc6-4c86-b27c-ab5492ccb34c	f6cbbf9e25802c74f0f40811ab5de3116d3807598813e8070ae054400924f182	2026-03-07 22:19:05.44711+00	20260307141339_revenue_tables	\N	\N	2026-03-07 22:19:05.423216+00	1
82af136e-6e6e-4794-b4ba-26f38a3ed16c	684b0b7df8caf7ac530d8eea35c2bf332297e85f91c3806dcfbf02f1fbc28148	2026-03-09 19:02:18.658792+00	20260309120000_add_category_monthly_costs	\N	\N	2026-03-09 19:02:18.652903+00	1
30077b35-b33c-4239-a1b7-d73376d76f0b	e2997bc1c1a5b5d5c2ab518cbbbd3bbdac02c7e97a95e498246fc57ecb6b83ac	2026-03-07 22:19:05.450199+00	20260307180000_fix_audit_entries_role	\N	\N	2026-03-07 22:19:05.44761+00	1
9ae373e3-f0a2-4244-a93d-7099be31bcbd	a6ffa9fe9dea596e10c21ebe7ba4106b460a34dee7f28dc4008d7409b5009b66	2026-03-07 22:19:05.458064+00	20260307180100_add_dhg_and_calc_audit	\N	\N	2026-03-07 22:19:05.450639+00	1
3d150b57-ff1d-4e50-a494-5d7026b5eda8	189e682460e4c77cff291454c3d1f84324e1ad587c83902adcba9b5bf13cb612	2026-03-08 13:25:30.496883+00	20260308100000_add_monthly_other_revenue	\N	\N	2026-03-08 13:25:30.481529+00	1
00ba41b6-4fab-4d6d-af33-492ada81b160	cd7ba9ca6ee93340e4bb56be7b6126d5a28cc29b9cb1d7916094dd3195ed65cc	2026-03-09 19:02:18.683652+00	20260309140000_add_indexes_and_schema_fixes	\N	\N	2026-03-09 19:02:18.659325+00	1
c9f8b30c-269b-4887-97c2-82248438686f	1447ed51794591d933ce67e4a3470c3ff034e6d7bc1649746b621bf7bb642bf0	2026-03-08 17:38:08.282969+00	20260308173000_align_runtime_schema	\N	\N	2026-03-08 17:38:08.253525+00	1
\.


--
-- Data for Name: academic_years; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.academic_years (id, fiscal_year, ay1_start, ay1_end, ay2_start, ay2_end, summer_start, summer_end, academic_weeks, version, created_at, updated_at, created_by, updated_by) FROM stdin;
1	FY2022	2022-01-01	2022-06-30	2022-09-01	2022-12-31	2022-07-01	2022-08-31	36	1	2026-03-09 20:19:33.082+00	2026-03-09 20:20:11.977+00	2	2
2	FY2023	2023-01-01	2023-06-30	2023-09-01	2023-12-31	2023-07-01	2023-08-31	36	1	2026-03-09 20:19:33.083+00	2026-03-09 20:20:11.978+00	2	2
3	FY2024	2024-01-01	2024-06-30	2024-09-01	2024-12-31	2024-07-01	2024-08-31	36	1	2026-03-09 20:19:33.084+00	2026-03-09 20:20:11.979+00	2	2
4	FY2025	2025-01-01	2025-06-30	2025-09-01	2025-12-31	2025-07-01	2025-08-31	36	1	2026-03-09 20:19:33.085+00	2026-03-09 20:20:11.98+00	2	2
5	FY2026	2026-01-01	2026-06-30	2026-09-01	2026-12-31	2026-07-01	2026-08-31	36	1	2026-03-09 20:19:33.086+00	2026-03-09 20:20:11.98+00	2	2
6	FY2027	2027-01-01	2027-06-30	2027-09-01	2027-12-31	2027-07-01	2027-08-31	36	1	2026-03-09 20:19:33.086+00	2026-03-09 20:20:11.981+00	2	2
\.


--
-- Data for Name: actuals_import_log; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.actuals_import_log (id, version_id, module, source_file, validation_status, rows_imported, imported_by_id, imported_at) FROM stdin;
\.


--
-- Data for Name: assumptions; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.assumptions (id, key, value, unit, section, label, value_type, version, created_at, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: audit_entries; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.audit_entries (id, user_id, operation, table_name, record_id, old_values, new_values, ip_address, created_at, user_email, session_id, audit_note) FROM stdin;
1	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	192.168.65.1	2026-03-07 22:19:22.081+00	\N	\N	\N
2	1	LOGIN_SUCCESS	users	\N	\N	\N	192.168.65.1	2026-03-07 22:19:22.089+00	\N	\N	\N
3	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	192.168.65.1	2026-03-07 22:19:28.218+00	\N	\N	\N
4	1	LOGIN_SUCCESS	users	\N	\N	\N	192.168.65.1	2026-03-07 22:19:28.22+00	\N	\N	\N
5	1	SESSION_FORCE_REVOKED	refresh_tokens	\N	\N	{"reason": "max_sessions_exceeded", "familyId": "985e34a0-e0c5-429f-a1da-5df8b6852060"}	172.22.0.4	2026-03-07 22:20:03.65+00	\N	\N	\N
6	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	172.22.0.4	2026-03-07 22:20:03.651+00	\N	\N	\N
7	1	LOGIN_SUCCESS	users	\N	\N	\N	172.22.0.4	2026-03-07 22:20:03.653+00	\N	\N	\N
8	1	SESSION_FORCE_REVOKED	refresh_tokens	\N	\N	{"reason": "max_sessions_exceeded", "familyId": "013b4daf-e306-441e-befd-b4f1162264d6"}	172.22.0.4	2026-03-07 22:23:31.313+00	\N	\N	\N
9	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	172.22.0.4	2026-03-07 22:23:31.316+00	\N	\N	\N
10	1	LOGIN_SUCCESS	users	\N	\N	\N	172.22.0.4	2026-03-07 22:23:31.319+00	\N	\N	\N
11	1	VERSION_CREATED	budget_versions	1	\N	{"name": "test 2 2026", "type": "Budget", "fiscalYear": 2026, "description": "test"}	172.22.0.4	2026-03-07 22:23:59.743+00	\N	\N	\N
12	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	172.22.0.4	2026-03-07 23:11:44.608+00	\N	\N	\N
13	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	172.22.0.4	2026-03-07 23:11:47.975+00	\N	\N	\N
14	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	172.22.0.4	2026-03-08 01:31:49.107+00	\N	\N	\N
15	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	172.22.0.4	2026-03-08 06:39:34.495+00	\N	\N	\N
16	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	172.22.0.4	2026-03-08 11:01:49.98+00	\N	\N	\N
17	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 13:25:44.011+00	\N	\N	\N
18	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 13:25:48.124+00	\N	\N	\N
19	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 13:41:08.194+00	\N	\N	\N
20	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 13:41:09.107+00	\N	\N	\N
21	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 16:19:46.263+00	\N	\N	\N
22	1	LOGOUT	users	\N	\N	\N	127.0.0.1	2026-03-08 16:31:29.198+00	\N	\N	\N
23	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 16:31:36.428+00	\N	\N	\N
24	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-08 16:31:36.431+00	\N	\N	\N
25	1	LOGIN_FAILED	users	\N	\N	\N	127.0.0.1	2026-03-08 17:38:19.157+00	admin@efir.edu.sa	\N	\N
26	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 17:38:19.161+00	\N	\N	\N
27	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-08 17:38:19.166+00	admin@efir.edu.sa	\N	\N
28	1	SESSION_FORCE_REVOKED	refresh_tokens	\N	\N	{"reason": "max_sessions_exceeded", "familyId": "2d19ba37-8cb8-40b8-b663-baecb7921c2c"}	127.0.0.1	2026-03-08 17:38:37.105+00	admin@efir.edu.sa	\N	\N
29	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 17:38:37.11+00	\N	\N	\N
30	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-08 17:38:37.112+00	admin@efir.edu.sa	\N	\N
31	1	SESSION_FORCE_REVOKED	refresh_tokens	\N	\N	{"reason": "max_sessions_exceeded", "familyId": "1940d1de-1dd7-4c78-a9fe-dc6584763918"}	127.0.0.1	2026-03-08 17:40:33.255+00	admin@efir.edu.sa	\N	\N
32	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 17:40:33.258+00	\N	\N	\N
33	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-08 17:40:33.261+00	admin@efir.edu.sa	\N	\N
34	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 18:50:51.808+00	\N	\N	\N
35	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 18:53:09.795+00	\N	\N	\N
36	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 18:53:09.863+00	\N	\N	\N
37	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 18:54:16.972+00	\N	\N	\N
38	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 18:54:16.98+00	\N	\N	\N
40	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:05:46.117+00	\N	\N	\N
39	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:05:46.116+00	\N	\N	\N
41	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:06:46.924+00	\N	\N	\N
42	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:12:08.689+00	\N	\N	\N
43	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:12:28.16+00	\N	\N	\N
44	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:12:44.399+00	\N	\N	\N
45	1	SESSION_FORCE_REVOKED	refresh_tokens	\N	\N	{"reason": "max_sessions_exceeded", "familyId": "0178110a-99e3-47ea-bd26-1231006ea6e4"}	127.0.0.1	2026-03-08 19:12:49.961+00	admin@efir.edu.sa	\N	\N
46	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:12:49.967+00	\N	\N	\N
47	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-08 19:12:49.969+00	admin@efir.edu.sa	\N	\N
48	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:13:47.105+00	\N	\N	\N
49	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:14:09.53+00	\N	\N	\N
50	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:16:43.214+00	\N	\N	\N
51	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:17:10.375+00	\N	\N	\N
52	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:17:29.01+00	\N	\N	\N
53	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:17:49.424+00	\N	\N	\N
54	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:18:09.114+00	\N	\N	\N
55	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:18:30.499+00	\N	\N	\N
56	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:19:47.675+00	\N	\N	\N
57	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:20:13.046+00	\N	\N	\N
58	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:21:31.207+00	\N	\N	\N
59	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:34:16.088+00	\N	\N	\N
60	1	SESSION_FORCE_REVOKED	refresh_tokens	\N	\N	{"reason": "max_sessions_exceeded", "familyId": "4807eb79-5993-42e9-90c5-49d54c324151"}	127.0.0.1	2026-03-08 19:35:44.624+00	admin@efir.edu.sa	\N	\N
61	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:35:44.627+00	\N	\N	\N
62	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-08 19:35:44.633+00	admin@efir.edu.sa	\N	\N
63	1	SESSION_FORCE_REVOKED	refresh_tokens	\N	\N	{"reason": "max_sessions_exceeded", "familyId": "b1e8735b-70bb-4962-8ae2-3fa247728ec9"}	127.0.0.1	2026-03-08 19:38:50.933+00	admin@efir.edu.sa	\N	\N
64	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:38:50.94+00	\N	\N	\N
65	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-08 19:38:50.945+00	admin@efir.edu.sa	\N	\N
66	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 20:16:48.538+00	\N	\N	\N
67	1	SESSION_FORCE_REVOKED	refresh_tokens	\N	\N	{"reason": "max_sessions_exceeded", "familyId": "32ec98e7-b1a8-42b3-a445-9952934e2a01"}	127.0.0.1	2026-03-08 20:17:12.892+00	admin@efir.edu.sa	\N	\N
68	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 20:17:12.897+00	\N	\N	\N
69	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-08 20:17:12.899+00	admin@efir.edu.sa	\N	\N
70	1	ALL_SESSIONS_REVOKED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:13:22.898+00	\N	\N	\N
71	1	TOKEN_FAMILY_REVOKED	refresh_tokens	\N	\N	{"reason": "replay_detected", "familyId": "0178110a-99e3-47ea-bd26-1231006ea6e4"}	127.0.0.1	2026-03-08 21:13:22.901+00	\N	\N	\N
72	1	ALL_SESSIONS_REVOKED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:13:23.232+00	\N	\N	\N
73	1	TOKEN_FAMILY_REVOKED	refresh_tokens	\N	\N	{"reason": "replay_detected", "familyId": "6cf6edcc-3c4d-42a3-917d-8c203dedf738"}	127.0.0.1	2026-03-08 21:13:23.233+00	\N	\N	\N
74	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:50:04.8+00	\N	\N	\N
75	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-08 21:50:04.807+00	admin@efir.edu.sa	\N	\N
76	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:54:19.159+00	\N	\N	\N
77	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:54:25.113+00	\N	\N	\N
78	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:54:38.106+00	\N	\N	\N
79	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:54:44.099+00	\N	\N	\N
80	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:54:50.065+00	\N	\N	\N
81	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:55:01.154+00	\N	\N	\N
82	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:55:14.162+00	\N	\N	\N
83	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:55:20.126+00	\N	\N	\N
84	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:55:54.135+00	\N	\N	\N
85	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:55:55.07+00	\N	\N	\N
86	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:56:00.098+00	\N	\N	\N
87	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:56:13.179+00	\N	\N	\N
88	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:56:24.1+00	\N	\N	\N
89	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:56:33.239+00	\N	\N	\N
90	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:57:00.134+00	\N	\N	\N
91	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:57:05.122+00	\N	\N	\N
92	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:57:33.142+00	\N	\N	\N
93	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 22:01:45.344+00	\N	\N	\N
94	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 22:02:16.246+00	\N	\N	\N
95	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 22:47:50.437+00	\N	\N	\N
96	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 22:51:03.298+00	\N	\N	\N
97	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 06:18:58.219+00	\N	\N	\N
100	\N	LOGOUT	users	\N	\N	\N	127.0.0.1	2026-03-09 14:38:25.738+00	\N	\N	\N
98	\N	LOGOUT	users	\N	\N	\N	127.0.0.1	2026-03-09 14:38:25.738+00	\N	\N	\N
99	\N	LOGOUT	users	\N	\N	\N	127.0.0.1	2026-03-09 14:38:25.738+00	\N	\N	\N
101	\N	LOGOUT	users	\N	\N	\N	127.0.0.1	2026-03-09 14:38:25.738+00	\N	\N	\N
102	\N	LOGOUT	users	\N	\N	\N	127.0.0.1	2026-03-09 14:38:25.738+00	\N	\N	\N
103	\N	LOGOUT	users	\N	\N	\N	127.0.0.1	2026-03-09 14:38:25.738+00	\N	\N	\N
104	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:06:34.843+00	\N	\N	\N
105	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-09 16:06:34.852+00	admin@efir.edu.sa	\N	\N
106	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:08:03.208+00	\N	\N	\N
107	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:08:57.888+00	\N	\N	\N
108	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:09:10.855+00	\N	\N	\N
109	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:09:53.428+00	\N	\N	\N
110	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:12:34.377+00	\N	\N	\N
111	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:15:45.46+00	\N	\N	\N
112	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:18:24.267+00	\N	\N	\N
113	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:19:18.153+00	\N	\N	\N
114	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:21:31.712+00	\N	\N	\N
115	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:30:11.539+00	\N	\N	\N
116	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:30:12.282+00	\N	\N	\N
117	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:30:14.04+00	\N	\N	\N
118	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:30:16.567+00	\N	\N	\N
119	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:30:17.999+00	\N	\N	\N
120	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:30:19.553+00	\N	\N	\N
121	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:31:57.77+00	\N	\N	\N
122	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:33:29.123+00	\N	\N	\N
123	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 17:50:01.859+00	\N	\N	\N
124	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 17:50:02.487+00	\N	\N	\N
125	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 17:50:03.47+00	\N	\N	\N
126	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 17:54:05.51+00	\N	\N	\N
127	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 17:57:44.53+00	\N	\N	\N
128	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:01:21.674+00	\N	\N	\N
129	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:01:22.455+00	\N	\N	\N
130	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:02:49.514+00	\N	\N	\N
131	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:17:09.565+00	\N	\N	\N
132	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:17:14.5+00	\N	\N	\N
133	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:17:38.524+00	\N	\N	\N
134	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:45:34.618+00	\N	\N	\N
135	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:46:28.527+00	\N	\N	\N
136	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:47:29.522+00	\N	\N	\N
137	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:52:43.602+00	\N	\N	\N
138	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:53:05.586+00	\N	\N	\N
139	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:57:11.567+00	\N	\N	\N
140	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 20:00:57.624+00	\N	\N	\N
141	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 20:03:42.466+00	\N	\N	\N
142	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 20:03:48.079+00	\N	\N	\N
143	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-09 20:03:48.081+00	admin@efir.edu.sa	\N	\N
\.


--
-- Data for Name: budget_versions; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.budget_versions (id, fiscal_year, name, type, status, description, data_source, source_version_id, modification_count, stale_modules, created_by_id, published_at, locked_at, archived_at, created_at, updated_at, updated_by_id) FROM stdin;
1	2026	test 2 2026	Budget	Draft	test	CALCULATED	\N	0	{}	1	\N	\N	\N	2026-03-07 22:23:59.739+00	2026-03-07 22:23:59.739+00	\N
8	2026	Migration FY2026	Budget	Draft	\N	IMPORTED	\N	0	{}	2	\N	\N	\N	2026-03-09 20:20:12.027+00	2026-03-09 20:20:12.027+00	\N
9	2022	Actual FY2022	Actual	Locked	\N	IMPORTED	\N	0	{}	2	\N	2026-03-09 20:20:12.027+00	\N	2026-03-09 20:20:12.028+00	2026-03-09 20:20:12.028+00	\N
10	2023	Actual FY2023	Actual	Locked	\N	IMPORTED	\N	0	{}	2	\N	2026-03-09 20:20:12.028+00	\N	2026-03-09 20:20:12.028+00	2026-03-09 20:20:12.028+00	\N
11	2024	Actual FY2024	Actual	Locked	\N	IMPORTED	\N	0	{}	2	\N	2026-03-09 20:20:12.028+00	\N	2026-03-09 20:20:12.029+00	2026-03-09 20:20:12.029+00	\N
12	2025	Actual FY2025	Actual	Locked	\N	IMPORTED	\N	0	{}	2	\N	2026-03-09 20:20:12.028+00	\N	2026-03-09 20:20:12.029+00	2026-03-09 20:20:12.029+00	\N
13	2026	Actual FY2026	Actual	Locked	\N	IMPORTED	\N	0	{}	2	\N	2026-03-09 20:20:12.029+00	\N	2026-03-09 20:20:12.029+00	2026-03-09 20:20:12.029+00	\N
\.


--
-- Data for Name: calculation_audit_log; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.calculation_audit_log (id, version_id, run_id, module, status, started_at, completed_at, duration_ms, input_summary, output_summary, triggered_by) FROM stdin;
\.


--
-- Data for Name: category_monthly_costs; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.category_monthly_costs (id, version_id, month, category, amount, calculated_at, calculated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chart_of_accounts; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.chart_of_accounts (id, account_code, account_name, type, ifrs_category, center_type, description, status, version, created_at, updated_at, created_by, updated_by) FROM stdin;
3	R002	Tuition HT — Elementaire	REVENUE	Tuition Revenue	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.088+00	2026-03-09 20:20:11.983+00	2	2
4	R003	Tuition HT — College	REVENUE	Tuition Revenue	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.088+00	2026-03-09 20:20:11.983+00	2	2
5	R004	Tuition HT — Lycee	REVENUE	Tuition Revenue	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.089+00	2026-03-09 20:20:11.984+00	2	2
6	R005	DAI Revenue	REVENUE	Registration Fees	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.089+00	2026-03-09 20:20:11.984+00	2	2
7	R006	DPI Revenue	REVENUE	Registration Fees	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.09+00	2026-03-09 20:20:11.985+00	2	2
8	R007	Frais de Dossier	REVENUE	Registration Fees	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.091+00	2026-03-09 20:20:11.985+00	2	2
10	R009	Examination Fees — DNB	REVENUE	Examination Fees	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.092+00	2026-03-09 20:20:11.986+00	2	2
11	R010	Examination Fees — EAF	REVENUE	Examination Fees	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.092+00	2026-03-09 20:20:11.987+00	2	2
12	R011	Examination Fees — SIELE	REVENUE	Examination Fees	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.093+00	2026-03-09 20:20:11.987+00	2	2
13	R012	After-School Activities	REVENUE	Activities & Services	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.093+00	2026-03-09 20:20:11.988+00	2	2
14	R013	Daycare Revenue	REVENUE	Activities & Services	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.093+00	2026-03-09 20:20:11.988+00	2	2
15	R014	Class Photos Revenue	REVENUE	Activities & Services	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.094+00	2026-03-09 20:20:11.989+00	2	2
16	R015	PSG Academy Rental	REVENUE	Activities & Services	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.094+00	2026-03-09 20:20:11.989+00	2	2
17	R016	Evaluation Fees	REVENUE	Registration Fees	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.095+00	2026-03-09 20:20:11.989+00	2	2
18	R017	Bourses AEFE	REVENUE	Other Revenue	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.095+00	2026-03-09 20:20:11.99+00	2	2
19	R018	Bourses AESH	REVENUE	Other Revenue	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.096+00	2026-03-09 20:20:11.99+00	2	2
20	SC001	Base Salary — Residents	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.096+00	2026-03-09 20:20:11.991+00	2	2
21	SC002	Base Salary — Contrats Locaux	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.097+00	2026-03-09 20:20:11.991+00	2	2
22	SC003	Housing Allowance	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.097+00	2026-03-09 20:20:11.992+00	2	2
23	SC004	Transport Allowance	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.098+00	2026-03-09 20:20:11.992+00	2	2
24	SC005	Responsibility Premium	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.098+00	2026-03-09 20:20:11.993+00	2	2
25	SC006	HSA Payments	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.099+00	2026-03-09 20:20:11.993+00	2	2
26	SC007	Augmentation Costs	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.099+00	2026-03-09 20:20:11.994+00	2	2
27	SC008	GOSI Employer Contribution	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.099+00	2026-03-09 20:20:11.994+00	2	2
28	SC009	GOSI Employee Contribution	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.1+00	2026-03-09 20:20:11.994+00	2	2
29	SC010	Ajeer Levy	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.1+00	2026-03-09 20:20:11.995+00	2	2
30	SC011	Ajeer Monthly Fee	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.101+00	2026-03-09 20:20:11.995+00	2	2
31	SC012	End of Service — Accrual	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.101+00	2026-03-09 20:20:11.996+00	2	2
32	SC013	Recruitment Costs	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.102+00	2026-03-09 20:20:11.996+00	2	2
33	SC014	Training & Development	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.102+00	2026-03-09 20:20:11.997+00	2	2
34	SC015	Staff Insurance	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.103+00	2026-03-09 20:20:11.997+00	2	2
35	OX001	Building Rent	EXPENSE	Occupancy	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.103+00	2026-03-09 20:20:11.998+00	2	2
36	OX002	Building Maintenance	EXPENSE	Occupancy	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.103+00	2026-03-09 20:20:11.998+00	2	2
37	OX003	Utilities — Electricity	EXPENSE	Occupancy	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.104+00	2026-03-09 20:20:11.999+00	2	2
38	OX004	Utilities — Water	EXPENSE	Occupancy	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.104+00	2026-03-09 20:20:11.999+00	2	2
39	OX005	Utilities — Gas	EXPENSE	Occupancy	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.105+00	2026-03-09 20:20:11.999+00	2	2
40	OX006	Security Services	EXPENSE	Occupancy	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.105+00	2026-03-09 20:20:12+00	2	2
41	OX007	Cleaning Services	EXPENSE	Occupancy	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.106+00	2026-03-09 20:20:12+00	2	2
43	OX009	Insurance — Liability	EXPENSE	Insurance	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.107+00	2026-03-09 20:20:12.001+00	2	2
44	OX010	Insurance — Vehicle	EXPENSE	Insurance	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.107+00	2026-03-09 20:20:12.002+00	2	2
45	OX011	IT Infrastructure	EXPENSE	Technology	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.107+00	2026-03-09 20:20:12.002+00	2	2
46	OX012	Software Licenses	EXPENSE	Technology	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.108+00	2026-03-09 20:20:12.002+00	2	2
47	OX013	Network & Internet	EXPENSE	Technology	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.108+00	2026-03-09 20:20:12.003+00	2	2
48	OX014	IT Equipment	EXPENSE	Technology	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.109+00	2026-03-09 20:20:12.003+00	2	2
49	OX015	IT Support Services	EXPENSE	Technology	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.109+00	2026-03-09 20:20:12.004+00	2	2
50	OX016	Textbooks & Curriculum	EXPENSE	Educational	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.109+00	2026-03-09 20:20:12.004+00	2	2
51	OX017	Library Resources	EXPENSE	Educational	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.11+00	2026-03-09 20:20:12.004+00	2	2
52	OX018	Laboratory Supplies	EXPENSE	Educational	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.111+00	2026-03-09 20:20:12.005+00	2	2
53	OX019	Sports Equipment	EXPENSE	Educational	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.112+00	2026-03-09 20:20:12.005+00	2	2
54	OX020	Art & Music Supplies	EXPENSE	Educational	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.113+00	2026-03-09 20:20:12.006+00	2	2
55	OX021	Office Supplies	EXPENSE	Administrative	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.113+00	2026-03-09 20:20:12.006+00	2	2
56	OX022	Printing & Stationery	EXPENSE	Administrative	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.114+00	2026-03-09 20:20:12.007+00	2	2
57	OX023	Postage & Courier	EXPENSE	Administrative	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.115+00	2026-03-09 20:20:12.007+00	2	2
58	OX024	Legal Fees	EXPENSE	Professional Services	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.115+00	2026-03-09 20:20:12.007+00	2	2
59	OX025	Audit Fees	EXPENSE	Professional Services	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.116+00	2026-03-09 20:20:12.008+00	2	2
60	OX026	Consultancy Fees	EXPENSE	Professional Services	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.116+00	2026-03-09 20:20:12.008+00	2	2
61	OX027	Bank Charges	EXPENSE	Financial	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.117+00	2026-03-09 20:20:12.009+00	2	2
62	OX028	Currency Exchange Loss	EXPENSE	Financial	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.117+00	2026-03-09 20:20:12.009+00	2	2
63	OX029	Marketing & Communications	EXPENSE	Marketing	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.118+00	2026-03-09 20:20:12.009+00	2	2
64	OX030	Events & Activities	EXPENSE	Marketing	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.119+00	2026-03-09 20:20:12.01+00	2	2
65	OX031	Travel — Staff	EXPENSE	Travel	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.119+00	2026-03-09 20:20:12.01+00	2	2
66	OX032	Travel — Management	EXPENSE	Travel	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.12+00	2026-03-09 20:20:12.011+00	2	2
67	OX033	Vehicle Fuel	EXPENSE	Transport	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.12+00	2026-03-09 20:20:12.011+00	2	2
2	R001	Tuition HT — Maternelle	REVENUE	Tuition Revenue	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.087+00	2026-03-09 20:20:11.982+00	2	2
9	R008	Examination Fees — BAC	REVENUE	Examination Fees	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.091+00	2026-03-09 20:20:11.986+00	2	2
42	OX008	Insurance — Property	EXPENSE	Insurance	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.106+00	2026-03-09 20:20:12.001+00	2	2
68	OX034	Vehicle Maintenance	EXPENSE	Transport	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.121+00	2026-03-09 20:20:12.011+00	2	2
69	OX035	School Bus Costs	EXPENSE	Transport	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.121+00	2026-03-09 20:20:12.012+00	2	2
70	OX036	AEFE Fees	EXPENSE	Regulatory	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.122+00	2026-03-09 20:20:12.012+00	2	2
71	OX037	Government Licenses	EXPENSE	Regulatory	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.122+00	2026-03-09 20:20:12.012+00	2	2
72	OX038	Accreditation Fees	EXPENSE	Regulatory	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.123+00	2026-03-09 20:20:12.013+00	2	2
73	OX039	Depreciation — Furniture	EXPENSE	Depreciation	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.123+00	2026-03-09 20:20:12.013+00	2	2
74	OX040	Depreciation — Equipment	EXPENSE	Depreciation	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.124+00	2026-03-09 20:20:12.014+00	2	2
75	OX041	Depreciation — Vehicles	EXPENSE	Depreciation	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.124+00	2026-03-09 20:20:12.014+00	2	2
76	OX042	Contingency Reserve	EXPENSE	Contingency	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.125+00	2026-03-09 20:20:12.014+00	2	2
77	OX043	Miscellaneous OPEX	EXPENSE	Miscellaneous	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.125+00	2026-03-09 20:20:12.015+00	2	2
\.


--
-- Data for Name: cohort_parameters; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.cohort_parameters (id, version_id, grade_level, retention_rate, lateral_entry_count, lateral_weight_fr, lateral_weight_nat, lateral_weight_aut, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.departments (id, code, label, band_mapping, version, created_at, updated_at, created_by, updated_by) FROM stdin;
1	TEST	Test	NON_ACADEMIC	1	2026-03-09 20:16:02.122+00	2026-03-09 20:16:02.122+00	1	1
2	TEACHING	Teaching	NON_ACADEMIC	1	2026-03-09 20:19:33.079+00	2026-03-09 20:20:11.974+00	2	2
3	ADMIN	Administration	NON_ACADEMIC	1	2026-03-09 20:19:33.08+00	2026-03-09 20:20:11.975+00	2	2
4	SUPPORT	Support	NON_ACADEMIC	1	2026-03-09 20:19:33.08+00	2026-03-09 20:20:11.976+00	2	2
5	MGMT	Management	NON_ACADEMIC	1	2026-03-09 20:19:33.081+00	2026-03-09 20:20:11.976+00	2	2
6	MAINT	Maintenance	NON_ACADEMIC	1	2026-03-09 20:19:33.082+00	2026-03-09 20:20:11.977+00	2	2
\.


--
-- Data for Name: dhg_grille_config; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.dhg_grille_config (id, grade_level, subject, dhg_type, hours_per_week_per_section, effective_from_year, created_at, updated_at) FROM stdin;
2	MS	Mobiliser le langage	Structural	6.00	2026	2026-03-09 20:15:46.552+00	2026-03-09 20:20:12.271+00
3	GS	Mobiliser le langage	Structural	6.50	2026	2026-03-09 20:15:46.552+00	2026-03-09 20:20:12.272+00
4	PS	Activites physiques	Structural	5.00	2026	2026-03-09 20:15:46.553+00	2026-03-09 20:20:12.272+00
5	MS	Activites physiques	Structural	5.00	2026	2026-03-09 20:15:46.553+00	2026-03-09 20:20:12.272+00
6	GS	Activites physiques	Structural	4.00	2026	2026-03-09 20:15:46.554+00	2026-03-09 20:20:12.273+00
7	PS	Activites artistiques	Structural	3.00	2026	2026-03-09 20:15:46.554+00	2026-03-09 20:20:12.273+00
8	MS	Activites artistiques	Structural	3.00	2026	2026-03-09 20:15:46.554+00	2026-03-09 20:20:12.273+00
9	GS	Activites artistiques	Structural	3.00	2026	2026-03-09 20:15:46.555+00	2026-03-09 20:20:12.274+00
10	PS	Construire les premiers outils	Structural	4.00	2026	2026-03-09 20:15:46.555+00	2026-03-09 20:20:12.274+00
11	MS	Construire les premiers outils	Structural	5.00	2026	2026-03-09 20:15:46.555+00	2026-03-09 20:20:12.275+00
13	PS	Explorer le monde	Structural	4.00	2026	2026-03-09 20:15:46.556+00	2026-03-09 20:20:12.275+00
14	MS	Explorer le monde	Structural	4.00	2026	2026-03-09 20:15:46.557+00	2026-03-09 20:20:12.276+00
15	GS	Explorer le monde	Structural	4.50	2026	2026-03-09 20:15:46.557+00	2026-03-09 20:20:12.276+00
16	PS	Arabe	Structural	2.00	2026	2026-03-09 20:15:46.557+00	2026-03-09 20:20:12.276+00
17	MS	Arabe	Structural	2.00	2026	2026-03-09 20:15:46.558+00	2026-03-09 20:20:12.277+00
18	GS	Arabe	Structural	2.50	2026	2026-03-09 20:15:46.558+00	2026-03-09 20:20:12.277+00
19	PS	Anglais	Structural	1.00	2026	2026-03-09 20:15:46.558+00	2026-03-09 20:20:12.278+00
20	MS	Anglais	Structural	1.50	2026	2026-03-09 20:15:46.559+00	2026-03-09 20:20:12.278+00
21	GS	Anglais	Structural	2.00	2026	2026-03-09 20:15:46.559+00	2026-03-09 20:20:12.278+00
22	CP	Francais	Structural	10.00	2026	2026-03-09 20:15:46.559+00	2026-03-09 20:20:12.279+00
23	CE1	Francais	Structural	8.00	2026	2026-03-09 20:15:46.56+00	2026-03-09 20:20:12.279+00
24	CE2	Francais	Structural	8.00	2026	2026-03-09 20:15:46.56+00	2026-03-09 20:20:12.279+00
25	CM1	Francais	Structural	7.50	2026	2026-03-09 20:15:46.56+00	2026-03-09 20:20:12.28+00
26	CM2	Francais	Structural	7.50	2026	2026-03-09 20:15:46.561+00	2026-03-09 20:20:12.28+00
27	CP	Mathematiques	Structural	5.00	2026	2026-03-09 20:15:46.561+00	2026-03-09 20:20:12.28+00
28	CE1	Mathematiques	Structural	5.00	2026	2026-03-09 20:15:46.561+00	2026-03-09 20:20:12.281+00
29	CE2	Mathematiques	Structural	5.00	2026	2026-03-09 20:15:46.562+00	2026-03-09 20:20:12.281+00
30	CM1	Mathematiques	Structural	5.00	2026	2026-03-09 20:15:46.562+00	2026-03-09 20:20:12.281+00
31	CM2	Mathematiques	Structural	5.00	2026	2026-03-09 20:15:46.563+00	2026-03-09 20:20:12.282+00
32	CP	EPS	Structural	3.00	2026	2026-03-09 20:15:46.563+00	2026-03-09 20:20:12.282+00
33	CE1	EPS	Structural	3.00	2026	2026-03-09 20:15:46.563+00	2026-03-09 20:20:12.282+00
34	CE2	EPS	Structural	3.00	2026	2026-03-09 20:15:46.564+00	2026-03-09 20:20:12.283+00
35	CM1	EPS	Structural	3.00	2026	2026-03-09 20:15:46.564+00	2026-03-09 20:20:12.283+00
36	CM2	EPS	Structural	3.00	2026	2026-03-09 20:15:46.564+00	2026-03-09 20:20:12.283+00
37	CP	Sciences et Technologie	Structural	1.00	2026	2026-03-09 20:15:46.565+00	2026-03-09 20:20:12.284+00
38	CE1	Sciences et Technologie	Structural	1.50	2026	2026-03-09 20:15:46.565+00	2026-03-09 20:20:12.284+00
39	CE2	Sciences et Technologie	Structural	1.50	2026	2026-03-09 20:15:46.565+00	2026-03-09 20:20:12.284+00
40	CM1	Sciences et Technologie	Structural	2.00	2026	2026-03-09 20:15:46.566+00	2026-03-09 20:20:12.285+00
42	CP	Histoire-Geographie-EMC	Structural	0.50	2026	2026-03-09 20:15:46.566+00	2026-03-09 20:20:12.285+00
43	CE1	Histoire-Geographie-EMC	Structural	1.00	2026	2026-03-09 20:15:46.567+00	2026-03-09 20:20:12.286+00
44	CE2	Histoire-Geographie-EMC	Structural	1.50	2026	2026-03-09 20:15:46.567+00	2026-03-09 20:20:12.286+00
45	CM1	Histoire-Geographie-EMC	Structural	2.50	2026	2026-03-09 20:15:46.568+00	2026-03-09 20:20:12.286+00
46	CM2	Histoire-Geographie-EMC	Structural	2.50	2026	2026-03-09 20:15:46.568+00	2026-03-09 20:20:12.286+00
47	CP	Arts Plastiques	Structural	1.00	2026	2026-03-09 20:15:46.568+00	2026-03-09 20:20:12.287+00
48	CE1	Arts Plastiques	Structural	1.00	2026	2026-03-09 20:15:46.569+00	2026-03-09 20:20:12.287+00
49	CE2	Arts Plastiques	Structural	1.00	2026	2026-03-09 20:15:46.569+00	2026-03-09 20:20:12.287+00
50	CM1	Arts Plastiques	Structural	1.00	2026	2026-03-09 20:15:46.569+00	2026-03-09 20:20:12.288+00
51	CM2	Arts Plastiques	Structural	1.00	2026	2026-03-09 20:15:46.57+00	2026-03-09 20:20:12.288+00
52	CP	Education Musicale	Structural	1.00	2026	2026-03-09 20:15:46.57+00	2026-03-09 20:20:12.288+00
53	CE1	Education Musicale	Structural	1.00	2026	2026-03-09 20:15:46.57+00	2026-03-09 20:20:12.289+00
54	CE2	Education Musicale	Structural	1.00	2026	2026-03-09 20:15:46.571+00	2026-03-09 20:20:12.289+00
55	CM1	Education Musicale	Structural	1.00	2026	2026-03-09 20:15:46.571+00	2026-03-09 20:20:12.289+00
56	CM2	Education Musicale	Structural	1.00	2026	2026-03-09 20:15:46.571+00	2026-03-09 20:20:12.29+00
57	CP	Arabe	Structural	2.00	2026	2026-03-09 20:15:46.572+00	2026-03-09 20:20:12.29+00
58	CE1	Arabe	Structural	2.50	2026	2026-03-09 20:15:46.572+00	2026-03-09 20:20:12.29+00
59	CE2	Arabe	Structural	2.50	2026	2026-03-09 20:15:46.572+00	2026-03-09 20:20:12.291+00
60	CM1	Arabe	Structural	2.50	2026	2026-03-09 20:15:46.573+00	2026-03-09 20:20:12.291+00
61	CM2	Arabe	Structural	2.50	2026	2026-03-09 20:15:46.573+00	2026-03-09 20:20:12.291+00
62	CP	Anglais	Structural	1.50	2026	2026-03-09 20:15:46.574+00	2026-03-09 20:20:12.292+00
63	CE1	Anglais	Structural	2.00	2026	2026-03-09 20:15:46.574+00	2026-03-09 20:20:12.292+00
64	CE2	Anglais	Structural	2.00	2026	2026-03-09 20:15:46.574+00	2026-03-09 20:20:12.292+00
65	CM1	Anglais	Structural	2.00	2026	2026-03-09 20:15:46.575+00	2026-03-09 20:20:12.293+00
66	CM2	Anglais	Structural	2.00	2026	2026-03-09 20:15:46.575+00	2026-03-09 20:20:12.293+00
67	6EME	Francais	Structural	4.50	2026	2026-03-09 20:15:46.575+00	2026-03-09 20:20:12.293+00
69	6EME	Histoire-Geographie-EMC	Structural	3.00	2026	2026-03-09 20:15:46.576+00	2026-03-09 20:20:12.294+00
70	6EME	SVT	Structural	1.50	2026	2026-03-09 20:15:46.576+00	2026-03-09 20:20:12.294+00
71	6EME	Physique-Chimie	Structural	1.00	2026	2026-03-09 20:15:46.577+00	2026-03-09 20:20:12.295+00
72	6EME	Technologie	Structural	1.50	2026	2026-03-09 20:15:46.577+00	2026-03-09 20:20:12.295+00
73	6EME	Anglais	Structural	4.00	2026	2026-03-09 20:15:46.578+00	2026-03-09 20:20:12.295+00
74	6EME	Arabe	Structural	3.00	2026	2026-03-09 20:15:46.578+00	2026-03-09 20:20:12.295+00
75	6EME	Arts Plastiques	Structural	1.00	2026	2026-03-09 20:15:46.578+00	2026-03-09 20:20:12.296+00
76	6EME	Education Musicale	Structural	1.00	2026	2026-03-09 20:15:46.579+00	2026-03-09 20:20:12.296+00
77	6EME	EPS	Structural	4.00	2026	2026-03-09 20:15:46.579+00	2026-03-09 20:20:12.296+00
78	5EME	Francais	Structural	4.50	2026	2026-03-09 20:15:46.579+00	2026-03-09 20:20:12.297+00
79	5EME	Mathematiques	Structural	3.50	2026	2026-03-09 20:15:46.58+00	2026-03-09 20:20:12.297+00
80	5EME	Histoire-Geographie-EMC	Structural	3.00	2026	2026-03-09 20:15:46.58+00	2026-03-09 20:20:12.297+00
81	5EME	SVT	Structural	1.50	2026	2026-03-09 20:15:46.58+00	2026-03-09 20:20:12.298+00
82	5EME	Physique-Chimie	Structural	1.50	2026	2026-03-09 20:15:46.581+00	2026-03-09 20:20:12.298+00
83	5EME	Technologie	Structural	1.50	2026	2026-03-09 20:15:46.581+00	2026-03-09 20:20:12.298+00
84	5EME	Anglais	Structural	3.00	2026	2026-03-09 20:15:46.581+00	2026-03-09 20:20:12.298+00
85	5EME	Arabe	Structural	3.00	2026	2026-03-09 20:15:46.582+00	2026-03-09 20:20:12.299+00
86	5EME	Arts Plastiques	Structural	1.00	2026	2026-03-09 20:15:46.582+00	2026-03-09 20:20:12.299+00
87	5EME	Education Musicale	Structural	1.00	2026	2026-03-09 20:15:46.582+00	2026-03-09 20:20:12.299+00
88	5EME	EPS	Structural	3.00	2026	2026-03-09 20:15:46.583+00	2026-03-09 20:20:12.3+00
89	5EME	Espagnol	Structural	2.50	2026	2026-03-09 20:15:46.583+00	2026-03-09 20:20:12.3+00
90	4EME	Francais	Structural	4.50	2026	2026-03-09 20:15:46.583+00	2026-03-09 20:20:12.3+00
1	PS	Mobiliser le langage	Structural	6.00	2026	2026-03-09 20:15:46.551+00	2026-03-09 20:20:12.27+00
12	GS	Construire les premiers outils	Structural	5.50	2026	2026-03-09 20:15:46.556+00	2026-03-09 20:20:12.275+00
41	CM2	Sciences et Technologie	Structural	2.00	2026	2026-03-09 20:15:46.566+00	2026-03-09 20:20:12.285+00
68	6EME	Mathematiques	Structural	4.50	2026	2026-03-09 20:15:46.576+00	2026-03-09 20:20:12.294+00
91	4EME	Mathematiques	Structural	3.50	2026	2026-03-09 20:15:46.584+00	2026-03-09 20:20:12.3+00
92	4EME	Histoire-Geographie-EMC	Structural	3.00	2026	2026-03-09 20:15:46.584+00	2026-03-09 20:20:12.301+00
93	4EME	SVT	Structural	1.50	2026	2026-03-09 20:15:46.585+00	2026-03-09 20:20:12.301+00
94	4EME	Physique-Chimie	Structural	1.50	2026	2026-03-09 20:15:46.585+00	2026-03-09 20:20:12.301+00
95	4EME	Technologie	Structural	1.50	2026	2026-03-09 20:15:46.585+00	2026-03-09 20:20:12.302+00
96	4EME	Anglais	Structural	3.00	2026	2026-03-09 20:15:46.586+00	2026-03-09 20:20:12.302+00
97	4EME	Arabe	Structural	3.00	2026	2026-03-09 20:15:46.586+00	2026-03-09 20:20:12.302+00
98	4EME	Espagnol	Structural	2.50	2026	2026-03-09 20:15:46.586+00	2026-03-09 20:20:12.303+00
99	4EME	Arts Plastiques	Structural	1.00	2026	2026-03-09 20:15:46.587+00	2026-03-09 20:20:12.303+00
100	4EME	Education Musicale	Structural	1.00	2026	2026-03-09 20:15:46.587+00	2026-03-09 20:20:12.303+00
101	4EME	EPS	Structural	3.00	2026	2026-03-09 20:15:46.588+00	2026-03-09 20:20:12.304+00
102	3EME	Francais	Structural	4.00	2026	2026-03-09 20:15:46.588+00	2026-03-09 20:20:12.304+00
103	3EME	Mathematiques	Structural	3.50	2026	2026-03-09 20:15:46.588+00	2026-03-09 20:20:12.304+00
104	3EME	Histoire-Geographie-EMC	Structural	3.50	2026	2026-03-09 20:15:46.589+00	2026-03-09 20:20:12.304+00
105	3EME	SVT	Structural	1.50	2026	2026-03-09 20:15:46.589+00	2026-03-09 20:20:12.305+00
106	3EME	Physique-Chimie	Structural	1.50	2026	2026-03-09 20:15:46.589+00	2026-03-09 20:20:12.305+00
107	3EME	Technologie	Structural	1.50	2026	2026-03-09 20:15:46.59+00	2026-03-09 20:20:12.305+00
108	3EME	Anglais	Structural	3.00	2026	2026-03-09 20:15:46.59+00	2026-03-09 20:20:12.306+00
109	3EME	Arabe	Structural	3.00	2026	2026-03-09 20:15:46.59+00	2026-03-09 20:20:12.306+00
110	3EME	Espagnol	Structural	2.50	2026	2026-03-09 20:15:46.591+00	2026-03-09 20:20:12.306+00
111	3EME	Arts Plastiques	Structural	1.00	2026	2026-03-09 20:15:46.591+00	2026-03-09 20:20:12.306+00
112	3EME	Education Musicale	Structural	1.00	2026	2026-03-09 20:15:46.591+00	2026-03-09 20:20:12.307+00
113	3EME	EPS	Structural	3.00	2026	2026-03-09 20:15:46.592+00	2026-03-09 20:20:12.307+00
114	2NDE	Francais	Structural	4.00	2026	2026-03-09 20:15:46.592+00	2026-03-09 20:20:12.307+00
115	2NDE	Mathematiques	Structural	4.00	2026	2026-03-09 20:15:46.592+00	2026-03-09 20:20:12.308+00
116	2NDE	Histoire-Geographie	Structural	3.00	2026	2026-03-09 20:15:46.593+00	2026-03-09 20:20:12.308+00
117	2NDE	SVT	Structural	1.50	2026	2026-03-09 20:15:46.593+00	2026-03-09 20:20:12.308+00
118	2NDE	Physique-Chimie	Structural	3.00	2026	2026-03-09 20:15:46.594+00	2026-03-09 20:20:12.309+00
119	2NDE	SES	Structural	1.50	2026	2026-03-09 20:15:46.594+00	2026-03-09 20:20:12.309+00
120	2NDE	Anglais	Structural	3.00	2026	2026-03-09 20:15:46.594+00	2026-03-09 20:20:12.309+00
121	2NDE	Arabe	Structural	3.00	2026	2026-03-09 20:15:46.595+00	2026-03-09 20:20:12.309+00
122	2NDE	Espagnol	Structural	2.50	2026	2026-03-09 20:15:46.595+00	2026-03-09 20:20:12.31+00
123	2NDE	EPS	Structural	2.00	2026	2026-03-09 20:15:46.595+00	2026-03-09 20:20:12.31+00
124	2NDE	SNT	Structural	1.50	2026	2026-03-09 20:15:46.596+00	2026-03-09 20:20:12.31+00
125	2NDE	EMC	Structural	0.50	2026	2026-03-09 20:15:46.596+00	2026-03-09 20:20:12.311+00
126	1ERE	Francais	Structural	4.00	2026	2026-03-09 20:15:46.596+00	2026-03-09 20:20:12.311+00
127	1ERE	Mathematiques	Structural	4.00	2026	2026-03-09 20:15:46.597+00	2026-03-09 20:20:12.311+00
128	1ERE	Histoire-Geographie	Structural	3.00	2026	2026-03-09 20:15:46.597+00	2026-03-09 20:20:12.312+00
129	1ERE	Specialite 1	Structural	4.00	2026	2026-03-09 20:15:46.598+00	2026-03-09 20:20:12.312+00
130	1ERE	Specialite 2	Structural	4.00	2026	2026-03-09 20:15:46.598+00	2026-03-09 20:20:12.312+00
131	1ERE	Specialite 3	Structural	4.00	2026	2026-03-09 20:15:46.598+00	2026-03-09 20:20:12.313+00
132	1ERE	Anglais	Structural	2.50	2026	2026-03-09 20:15:46.599+00	2026-03-09 20:20:12.313+00
133	1ERE	Arabe	Structural	2.50	2026	2026-03-09 20:15:46.599+00	2026-03-09 20:20:12.313+00
134	1ERE	Espagnol	Structural	2.00	2026	2026-03-09 20:15:46.599+00	2026-03-09 20:20:12.313+00
135	1ERE	EPS	Structural	2.00	2026	2026-03-09 20:15:46.6+00	2026-03-09 20:20:12.314+00
136	1ERE	EMC	Structural	0.50	2026	2026-03-09 20:15:46.6+00	2026-03-09 20:20:12.314+00
137	1ERE	Enseignement Scientifique	Structural	2.00	2026	2026-03-09 20:15:46.6+00	2026-03-09 20:20:12.314+00
138	TERM	Philosophie	Structural	4.00	2026	2026-03-09 20:15:46.601+00	2026-03-09 20:20:12.314+00
139	TERM	Mathematiques	Structural	3.50	2026	2026-03-09 20:15:46.601+00	2026-03-09 20:20:12.315+00
140	TERM	Histoire-Geographie	Structural	3.00	2026	2026-03-09 20:15:46.601+00	2026-03-09 20:20:12.315+00
141	TERM	Specialite 1	Structural	6.00	2026	2026-03-09 20:15:46.602+00	2026-03-09 20:20:12.315+00
142	TERM	Specialite 2	Structural	6.00	2026	2026-03-09 20:15:46.602+00	2026-03-09 20:20:12.316+00
143	TERM	Anglais	Structural	2.00	2026	2026-03-09 20:15:46.602+00	2026-03-09 20:20:12.316+00
144	TERM	Arabe	Structural	2.00	2026	2026-03-09 20:15:46.603+00	2026-03-09 20:20:12.316+00
145	TERM	Espagnol	Structural	2.00	2026	2026-03-09 20:15:46.603+00	2026-03-09 20:20:12.316+00
146	TERM	EPS	Structural	2.00	2026	2026-03-09 20:15:46.603+00	2026-03-09 20:20:12.317+00
147	TERM	EMC	Structural	0.50	2026	2026-03-09 20:15:46.604+00	2026-03-09 20:20:12.317+00
148	TERM	Enseignement Scientifique	Structural	2.00	2026	2026-03-09 20:15:46.604+00	2026-03-09 20:20:12.317+00
\.


--
-- Data for Name: dhg_requirements; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.dhg_requirements (id, version_id, academic_period, grade_level, headcount, max_class_size, sections_needed, utilization, alert, recruitment_slots, created_at, updated_at, total_weekly_hours, total_annual_hours, fte) FROM stdin;
\.


--
-- Data for Name: discount_policies; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.discount_policies (id, version_id, tariff, nationality, discount_rate, created_at, updated_at, created_by, updated_by) FROM stdin;
4	8	PLEIN	\N	0.000000	2026-03-09 20:20:12.255+00	2026-03-09 20:20:12.255+00	2	\N
5	8	RP	\N	0.250000	2026-03-09 20:20:12.257+00	2026-03-09 20:20:12.257+00	2	\N
6	8	R3P	\N	0.100000	2026-03-09 20:20:12.258+00	2026-03-09 20:20:12.258+00	2	\N
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.employees (id, version_id, employee_code, name, function_role, department, status, joining_date, payment_method, is_saudi, is_ajeer, is_teaching, hourly_percentage, base_salary, housing_allowance, transport_allowance, responsibility_premium, hsa_amount, augmentation, augmentation_effective_date, ajeer_annual_levy, ajeer_monthly_fee, created_at, updated_at, created_by, updated_by) FROM stdin;
1	8	EMP0001	Jean Martin	Proviseur	MGMT	ACTIVE	2020-03-01	MONTHLY	f	f	f	1.0000	\\xc30d0407030288a2553848da42367cd23b013363f27ebf52d408e34709bc184bff493b85e28955cf6965bee632e88ca843ccc534e21bc57df0b0057efcb737c93d28d7bc3ae23889dfe0e2d1	\\xc30d04070302bde36642e2e8bb8f60d23a0147005c8908849d68b79496becd3fc390876fe058836fefd760d826983449e82898d38df69c1f6775670ee9c66c38b7e1e23fe2c3b768de7633	\\xc30d04070302c9ccccbd16d9668372d239012f90330258b7ff09ac981c43bdc855d707a996e8395f96c1280555f3baf6d9bfc5be084044a87bd306bcea13d05a2b4f94e94d1a25777802	\\xc30d040703022754fff3730cbbc361d23a0174592523ef1415b1d799f132fe0ee6fa3da5d199310e3d97cb7285c3c3fba0965c8f782a6b2a989764759b3cf924d987393ce9536b7b04f2ec	\\xc30d04070302d518560f1c0b897b7bd23701c5689a4ed0e5074dacad3405e05b210921a62958ad6b11b4e14d1f78962152eb9b42e9e877f19ef3c6b9ecdceaa74831b15eaf8b0d7d	\\xc30d040703027f7eb61fd9919c9f63d237012a767971df7603084e1081184efc41a36cef19719aa9ed146f8a22de2d9e39619d9d823fec8346438dbcb1039dac666754cb074daa87	\N	0.0000	0.0000	2026-03-09 20:20:12.344725+00	2026-03-09 20:20:12.344725+00	2	\N
2	8	EMP0002	Sophie Al-Rashid	Proviseur Adjoint	MGMT	ACTIVE	2021-04-01	MONTHLY	f	f	f	1.0000	\\xc30d040703029c8b62bcfc43fdf27cd23b01b2b83675f73fd0abf07fdedae35ff338cc573f50b20bfc753a7991d2ce8334f30d1224895120acbe34706827d8de6ef2dc5c88e08fdd7bc4a28a	\\xc30d040703028eaf0bfacba73f7066d23a01819f0c9025b61caaff77f8a269b2dadae4ed2ea4093fec157ae3f5796cd90947121c8b89a3dd7c6e10221f950c44bb6dd3f59b8b1a6c506364	\\xc30d040703025756b75ae5f8dc2d75d239012196e1b6b0b9a6aad9d04298f75ff51a017a6e69a7c5f612c85549b335d7a7cf9f5fcf70ebe99c6fbfc87da961de59810eab7242378257a9	\\xc30d04070302d83b129b396601bb6bd23a0192dd8df831d074babcdf39120bf23d9e00f1284eb0158ba7225a144dc73e453677ce716bb37f56a41593dc946cbac30bcb6902f865c28020e8	\\xc30d04070302d4f88481b4af027d68d23701b24e8b8c116a97f832e4816518d0c06fc48badc7d423862f07131b7b3d1b7d784fe28e262c10a030ddc04c442adfbf7eec32c6896407	\\xc30d040703028e0409fe2c6bfe376ad2370181814eeeefe2b0bff8929471c48e1e713fbe652e3c64c54eb521d226aad59d25ca0ce1ca5bab173ffa374249e0e6df79131a05901150	\N	0.0000	0.0000	2026-03-09 20:20:12.346515+00	2026-03-09 20:20:12.346515+00	2	\N
3	8	EMP0003	Pierre Benali	Directeur Primaire	MGMT	ACTIVE	2022-05-01	MONTHLY	f	f	f	1.0000	\\xc30d040703022490cb12a3f6e48370d23b01717ea52144c605307dda9f2e689bb2f3daa4234de696c1491a31ffbaffa6cd7c9e42ded06da72ceb957a71ea5dec50d17a45163c94e13414dc41	\\xc30d04070302836606c48cf8043269d23a012e881ae3bd2aedf5be048300ddbdcbe8071dac94a96d090b63447f46cfa4bca0324f73960054461af80391ffbff665b5b4b4144687fcdadf77	\\xc30d0407030205f193591d55c76964d2390120d105bd25fe1385c65ae89d375f32d8c74acb54c670e74f10b3099238ace7d42201f67313141997050c4b02e4b64ec006e2bdb9c5410979	\\xc30d0407030216bc2e9b6dbd15fe7ad23a01eb3e1a10247d845597ab05a262d11b093ce03f0b9286ea63ec562631b625e0232aaa048872d44796d33d9bde744e72442f781ae5d9354b61c9	\\xc30d040703029e390340f55aba4176d23701c3a2aaf7c5d8649c82f5b26ce7650bd4eadfd86db7b4d71babff322421da700e34921e5604e31c770cf0436ccde009ff62ae5d335375	\\xc30d040703022f5918cb15931b6777d23701aaf53a84dd687d4d52e2ac09e3b85cb00dd7f5d7fb2929fbeb455b0c55fb9666be2cdbc13a6e13bf2a6966733f1715f2be5d326d93dc	\N	0.0000	0.0000	2026-03-09 20:20:12.347316+00	2026-03-09 20:20:12.347316+00	2	\N
4	8	EMP0004	Fatima Laurent	Directeur Maternelle	MGMT	ACTIVE	2023-06-01	MONTHLY	f	f	f	1.0000	\\xc30d0407030236befc49c7c4a87164d23b01b7c0cf5f8456d0fc9633dc7b83fdd7891e6fdb23286600239c51c5b2f3be4d7ecd58daefecf1b784e04d6b8ead95a7090e91dfed9e8a22e7d325	\\xc30d040703021f1a65358b72688c6dd23a017919eb3c723b99827c9f28be6d2b63cb2384419b412e7ce94900b658873d47fc7f3ff33c32d228320bf5dc2144cd7dc0b74447b1a6429bc6ad	\\xc30d040703020ff3aa92fee170cb62d2390195b897f3a52edf2938a6039e6614f28c4a6a98ffab6e0d2a3e8c0b1bec1539ba4d5df75dc56fe0ebe12a28296850cb37916c71c2413fc6bd	\\xc30d0407030258091238ac2c90eb6ed23a01b3eb4db229fdacc855364e1f9d15880bfca844a6c92aa9675e93eb44ff2b88bd26e50447e5ca99fa83b3f76d0c6b4ac92762d53c41436d5149	\\xc30d04070302fa7b2871aae8c6257bd237018962e0556dcd50c3732c04fa8b39d11d54b7c21dda3b3c60566c99343760c55677840ee737883bd1144b5de0566d354f473d14d0c6ad	\\xc30d04070302ab64ce66d76fa2e96bd23701f9b4cc4788c0f6d8c3c04c01fdd984699db3f88c1d934270ac1f3a23e2472a99cbbea2893593be7690a68a96531212486b3787c2002c	\N	0.0000	0.0000	2026-03-09 20:20:12.348154+00	2026-03-09 20:20:12.348154+00	2	\N
5	8	EMP0005	Ahmed Al-Saud	DAF	MGMT	ACTIVE	2024-07-01	MONTHLY	f	f	f	1.0000	\\xc30d040703023a6212466c1a054869d23b011ab48cbc376e54718ac50aed96911e8deb7a5db1e08f030a78e86123056a27743baf04d9ac51e3148583ee0d585ef3809af3525bb446cd4575bf	\\xc30d04070302bf4c6881286b160378d23a0105f36eb44a3da20a0b95bb2825e8594b97f503791a9b773315dc7670e6dbc25fda438a78cd70a9eeb83c4ec5189fcf802631c8fb6b4386ed94	\\xc30d04070302bc6f8bb70bb8ce6768d23901e9622a8a077792ba4e797dab1cdba9c0672ee9dd9286432d7158e71dc6d6c2d58fdd11793f726ed88abbe1981a1fc92c78648ddd13dba726	\\xc30d040703027f2a38550ba3066870d23a01c2af28b764fbaca4f0e8bf3c8bda6d100088b5bb279b17d0f17ab378cf49f65aa11bf62c6d89190255b42a87798ccf793fab608500aeea19c7	\\xc30d04070302f8802f3826ecc20268d237017bbe134f1ff6478ff041ead9bffc5c2910b64bdfa9d734b937942bcce8cfdd8d193d5c92906e056019f8d7016ca549c9e2876b2769d8	\\xc30d04070302aa5bf1c21d92627770d2370104114eb519c0c2db0b34a6b2eb9f47d493c0163e40711b10884118b484a1c45bb11962baaac2d4cd3c76b3e7f145aff22bd01525e2da	\N	0.0000	0.0000	2026-03-09 20:20:12.348861+00	2026-03-09 20:20:12.348861+00	2	\N
6	8	EMP0006	Nour Al-Harbi	Secretaire	ADMIN	ACTIVE	2018-08-01	MONTHLY	t	f	f	1.0000	\\xc30d04070302a62df857e473f1ed6cd23a01d3c9a571caadeac9b209921f9d8ac26994f533c1d2cb6563e131b31f6fcd68f338f7a2727d57b5faf4a542aea89de1b438ff34fd63ad15cff2	\\xc30d04070302a807a272b3063e1579d23a01b086d21754fcc82b9f6c871ea20b56e4663ff0a1a6d32eb15a8a14b23e69e1f3adb712b48a0312832ee9269ca26ef6280777fc02c0a181deb6	\\xc30d04070302c6163e67e940ba597dd2390114283e506fdb959808c0b1bf36d238fe0920dc722b229df254b89d3f32d391f820f67aa3a46c7e324c3fa43978b5c61c9d4d8188ea9ff15c	\\xc30d0407030231607ee9adc0059460d23701918747e44e06a9c8884eb14858e64949bdc0f71b3eba4f64c2f4eada52e7fdb86c40c54a749c94e2a3e6a841534cc37149460f81f6fd	\\xc30d0407030279dbb8e02be42b0a75d23701deab77349ea11fd5aa031f1970171c634f87dfee5af496a37da759d47c7d3896df0d6a6e030cde4c739391f515f47d1fd58e18d5a9e6	\\xc30d04070302cbcd794d90e6d7bb7fd23701c7c423b9ee9f070a4c7c662db386a98f51c66205452fcdd33d258d08902c2d223495105baae0cd61ee66d4f93cd3e56095d601ae9c84	\N	0.0000	0.0000	2026-03-09 20:20:12.349582+00	2026-03-09 20:20:12.349582+00	2	\N
7	8	EMP0007	Khalid Moreau	Secretaire	ADMIN	ACTIVE	2019-09-01	MONTHLY	t	f	f	1.0000	\\xc30d04070302bd94681949670d8561d23a01aa1c2d7612b09360d3289cb724fc80fda348a8f99470f52fa91709da6eb4fde44379bc3292ac93f2894cf5fe06b481269e344c234c73792b56	\\xc30d04070302a7153200c3c5b60767d23a01d27c816ee254e2d0463b617b93ca664dd1afd8c42c88406f9d26eb0bb0ba13e7a4b7d4cb48fbaf0bfad60918319c5654fdf7ab00d270d26f1a	\\xc30d04070302aabd48479015d91c69d239014dd4656cb1bd8d69c31230b2da6d484f1c63c13676c1414c57bc24cd7ea68167a7825e46741c93af98b91c86025d2b23ec60ccc572fd44c7	\\xc30d04070302c10080e41b66a33e62d2370147bc9202a7d2cab495de7b903e7f129510b4d55f1c127d809984b81a6e70f2cff9b55e64025c88a249029998a0ff79c72ef9414c061c	\\xc30d040703027a8b1dfd945670a06cd23701e5e9e38d1e48a3f8fc74f0e9dc713891ac2f45c6d486c8f621e9c4f8f5b20643d9c9543e5315614c00427b780e030f94f2d66429fb45	\\xc30d040703026cb697bbf5a71d4576d23701f3357ee5b75fd8b3d2fd9e672d7413286c7df794b16bbbe103205fac61fe23733fb0de706567ffa8e4d3fef587903ab2da1c9cfb991b	\N	0.0000	0.0000	2026-03-09 20:20:12.350453+00	2026-03-09 20:20:12.350453+00	2	\N
8	8	EMP0008	Layla Khoury	Secretaire	ADMIN	ACTIVE	2020-01-01	MONTHLY	f	f	f	1.0000	\\xc30d04070302eb63d956722f66f97cd23a017913ea7d4b062be7c205f607daf9cc592f79c2f25964f712d93f33e9428a5cd1e93a7aeaf160fa4a1f304884e076033c3dd98c70ff6ae50d55	\\xc30d04070302334093747700fc4863d23a01d69a44394b481460d28a960413bd806394a4dd29a44a9ce9b49690091494aa0a9851238a5336d3a1919b6ac285fef7c22c3d7df41f8f4185e7	\\xc30d0407030250bf6fa124dcbe427fd23901502ef5bec2c21b4ad3b8a7ac321c577660d14c929ad865f62f111e386502c60893cf7e4183e3ba0f357555c2f4bfaece5715d65e58089963	\\xc30d04070302da9a5c42c11caf346bd237018aa97aecfe4418fd89e1d93be55b22fa35b5fb4c19587c43415bec1bed3282bedddac76e1e65879734c1639f36b9ef98269523a9a9ab	\\xc30d0407030280e9eaaecde06d646ed23701e303d22c6a6377748ccad67c681d78afdf164306460d5888cf336951f8cb33500c03001e96ca7cda3a9475898cb86fcbf98fd6ef5f68	\\xc30d040703025556b76b78fb9bb566d237013320f9f9ba98111441d2ba5e0980b56ede8c447d58306e1704931c00e565c330d52255bcb444dc04e5f6a375fd476780dce419cebcd5	\N	0.0000	0.0000	2026-03-09 20:20:12.351123+00	2026-03-09 20:20:12.351123+00	2	\N
9	8	EMP0009	Omar Dubois	Secretaire	ADMIN	ACTIVE	2021-02-01	MONTHLY	f	f	f	1.0000	\\xc30d040703029904187d83ab64737bd23a01d5b1f363764f82fb60db5ab8a408f8e6363467475cdef68ec2b8877889a313f916f019a5b4c99461f274b9394e413626218d7b9b4ae1d181c5	\\xc30d040703023e3630d71e0974db64d23a018dccad7aed41e9e9baa475d2912d6c14cf4ffc9a5f96e1f23f3a7d707e2e17d216c8b81f62c42eb387d240ae189fc4d926f5c8333f33c2ae6f	\\xc30d040703022624f0d106eee87763d239018a54c3f8672575aed8042005ad1493c3ae55999624ce447f93a395b7cb76524015ace1583124ee8bd30f587e2d11d0f00c7399eebd070729	\\xc30d040703027a44a66ee63b8f296fd23701b78c9fe956adfccb802d0d4b9cdc4c154ebf15f0ce9ca754444ae1b651d0d6651262321dc78110c965710093a4ef7e24843db2083717	\\xc30d04070302c32b39baa4b7a1d961d237012e1f497bb8997ace4bf848544a2b0611c6adc82ec7dca61692df8efe57e720aa351e0c80b0c4f22f44c93f9de1b18dd4e0acdbbbcbeb	\\xc30d0407030250bd9c51d889d5097ed2370190987b447d53f629463ef8b749a7d564bd2f047c855c4b35b7b653279b7d8b64894f74e634c72070f7e4109814b9a2679170bafdc581	\N	0.0000	0.0000	2026-03-09 20:20:12.351881+00	2026-03-09 20:20:12.351881+00	2	\N
10	8	EMP0010	Sarah Mansouri	Comptable	ADMIN	ACTIVE	2022-03-01	MONTHLY	t	f	f	1.0000	\\xc30d0407030243cf4fcfb41acd5f62d23a0187871cd8685f575c14eedcc968faa6cfcc9c3b7b29f439b83af75b2a0676edc62591df1ed28e845974470f785a1842fba77339d636a82085c0	\\xc30d04070302e6142c5f0cdd7ff57dd23a01de9913df00091e3c58e7fb2983d7da2997d66b530bbac6e4ff2c6b3482ba2eccc5a1126735d03b914e602a303bf1cf37272d0010f21c473a0a	\\xc30d04070302b854d9be4237fa1779d239017edba398aabb58bb88d1746317c56bc688cd7942a465a931228d5b93daf8ec3016bac7414807fb335bd0db265bda34ee25b56fb53791497b	\\xc30d04070302b04c038cf94fde2f7dd23701d9f10d75fbcd4f986c1f83b0f53dbcb6d02ba20ce7c572d3f36473a16401221ba8afa7a09f87efb8125b7f6e89878e2dde1e4fcecc14	\\xc30d04070302aaa2c231af104f8066d237011fa93dc803787b721e1dd247fe193840ff2107a16d334e9bb97097bd1a85c62013608f0696e55be7c4db98ddf76ad2e70eb731e7ef41	\\xc30d04070302e14f72f16cca50e173d237019abeeae80396fd66413a340f2ef74b974cc36f54ce6f0eb18714e815ec8610c673ae7c9205b4bac00d5f1f75b11aa917d2b9a35015ab	\N	0.0000	0.0000	2026-03-09 20:20:12.352631+00	2026-03-09 20:20:12.352631+00	2	\N
11	8	EMP0011	Youssef Petit	Comptable	ADMIN	ACTIVE	2023-04-01	MONTHLY	t	f	f	1.0000	\\xc30d04070302d8d2813b3c5fccc179d23a01820bf69fa9d721e293ed2855b89e9d7b72c4a110e1de779b2ac68ba2908162f8881a7a30f8c135f494b9fa1885666e9a55bcdfd04d05f26179	\\xc30d04070302e37095f53fc19af07ed23a0180ca04ce8340765a51b91eb1fbb1e6f450a09a680aca0a3593044b126e990c7000c352f3b957ce6ccf6294d3285015f8c073fb249ff3d4bf54	\\xc30d04070302f05ac13a1a7ff1e763d239010b80d9caa96768724d30928312be1caa004d61c2b081853985e2be651d69f5531744af9c9f3f7cfc7b909378be7b2448e98328a9968fd7f9	\\xc30d04070302e7dc6b260855e0f862d23701d5705ecd02fdd18dfe72ded1e46d326f0581fdaf822d812c32d864913f366df5f18a01f7e71e66dba345860931eb7d1220eb29afa7cc	\\xc30d040703020707790e453c362665d237015dd5672ef5e80306fa88ffcaabc6c4d7e94d9905f322d00bc09e8dc513c4ff4a1ebfc15f0f95cf9c6c12b015e88273df728f4fba2752	\\xc30d0407030270366024fca90bbe75d23701aaf716973524b25313402783d1bd705cefad61517f59d2cca07c6b4421554927e003e5940c364f600ea42ab82de1f2647438dc738406	\N	0.0000	0.0000	2026-03-09 20:20:12.353428+00	2026-03-09 20:20:12.353428+00	2	\N
12	8	EMP0012	Amina Roux	RH Manager	ADMIN	ACTIVE	2024-05-01	MONTHLY	f	f	f	1.0000	\\xc30d04070302db29910b11d7d48972d23b012ac4bac002d084f2299173d8dcb251f6482db133ea66c0b3cddd3f11b49ec24cf9131ad1e492b684f99c8dc6afe9b8c95661efa02afc48f960aa	\\xc30d040703022da8d9b841a16a9363d23a01ca4213c9ad23bd401c21cbb6a19d5afd935df956fd3fe7152b4146e68ebb80b0403d3a0ae0df16582ad64aa04641b655203ec5d7b037e559fd	\\xc30d04070302d171c930660a52927cd23901f84d58e083afee2e54b238a350b6f4b78fedb4d20e029960d9e5f4d37b2fb28a0510df1598b62fea8d3a3279b54e01f307a70e963adc663e	\\xc30d040703020f37673594dd179a66d237013afa58de5989b5083f16480f512bc9f93a5429dbdc28a695ce5e460e60e4fc0d92e8bb95d3d7429f727ed14f895d004333fcdb56fdd8	\\xc30d0407030253b86f6bea1355566ed237013dcbaf06a8d28227f00fd09e4676cb536e55a8d91d49f10ff9a2a1ac1b69eba0ac900582ffa3c051eeb4dcb3246acab4f979891e45a1	\\xc30d0407030283cd0573fdd5dbc87cd23701fcd403de609ab1aa67b105d8c454d36e6889dab5333191def94e077a49d4d99c00343b602e15faec142bbe79250300123028a81ab968	\N	0.0000	0.0000	2026-03-09 20:20:12.35418+00	2026-03-09 20:20:12.35418+00	2	\N
13	8	EMP0013	Hassan Al-Qahtani	RH Assistant	ADMIN	ACTIVE	2018-06-01	MONTHLY	t	f	f	1.0000	\\xc30d0407030284215e6941ec5e7464d23a015b401b4746ed7c2351e444415eb3ddf8fe57bfdbfde896028e40bdc605ba21dc200b7a8fb585dd8ca863a9801ea5cf7a847c78009075ce7ae2	\\xc30d04070302d741af377b7a781678d23a016710f41d7ff96d1f86efc525d8d440774888241a21e0017db6ef6f6ddb776cd55fbcbd575b603713d2cd7d8d5a6de9c59d761cbb94f6ab6a81	\\xc30d04070302bb44e2f7e8e2268f74d239017a87f40822b8a573940cc82083869aeafc5b0dc0dc14b6d54eb84b592c377a7a59578d8c57a3ace6df6f0fd5f98618788a7f5cb1bf8ebbe1	\\xc30d04070302431242bf7d0b96107fd23701828919e781264bbafdc874eefa0db3a7cff51859c469e89cc5d4042369231d0e1279138d2efe8e76ec6ac326b7960c728eb7d76e228e	\\xc30d040703026d86db7f34c272ae7ed23701e30b06b26f5f24b6099a5a8eeb4618d44eb3a65db9401dfe37bbe06de457d1f60b7a220a6de5ef036a239b8a8aabe21b89f3ba21449b	\\xc30d04070302463335234284429367d23701cdeaa244e6b87a43e114f8b35d47056334035e227e0dcb8e9e442338130a0fbecb04b313fc0134c452ea9505b0cfe2283d4e7f38ea5f	\N	0.0000	0.0000	2026-03-09 20:20:12.354936+00	2026-03-09 20:20:12.354936+00	2	\N
14	8	EMP0014	Claire Bernard	Responsable Inscriptions	ADMIN	ACTIVE	2019-07-01	MONTHLY	f	f	f	1.0000	\\xc30d0407030256f89ccdd55b5e1268d23a01bb5ca5131cff31f8091e0abe37c501d04b74aad60c46a39bdc7115f78bf1b1a32e3ecbe49bf99dc176c510213e7f8d800d12c3c5e3fb9e064a	\\xc30d04070302e1321540fbbf7d4a7fd23a0187655846945a4884a259953fe0bff0345fa94eb33642c586ad61a6c4a3f173e7f7474d7e9526e44c709799850e9bc77ac7b4d4fa360b95a1c4	\\xc30d04070302a53437608040909b6ed2390129782fd1bad78c04f9324024c6f53f589f4afca2e970c4f4d5d90b96cf584e4314b50d8da4018fabef6dd3408980781ce3acfda5fab2ca8a	\\xc30d04070302b15497a22152cf2361d23701a01f62aec665d112b5a0d7b36e8fdca5dc2c5dbb5d2be4193ce6aa4fa131debbbc90a7a1b13f5f15633742d8376757eb615036aac879	\\xc30d040703022fa53b0dbd502d0174d237014ddea1b5db5f7facd784b3e2c9c549891862e6d38f51702c5d5c1c0dfdad9637733e516dee720b3873dde6aba58bda5c73e402471b26	\\xc30d040703023a3ac3059a0b56cb74d23701284cd34aee11f2c1e54c2429facf9ed323a80be4d218357a4aa572d06e0718cab4aa091207b48a510973bf5d3b5bcf8d31eedd1922f8	\N	0.0000	0.0000	2026-03-09 20:20:12.355936+00	2026-03-09 20:20:12.355936+00	2	\N
15	8	EMP0015	Thomas Al-Dosari	Assistant Inscriptions	ADMIN	ACTIVE	2020-08-01	MONTHLY	t	f	f	1.0000	\\xc30d04070302170574202919812a73d23a01062ca28dcc2b5082148f99c7b797a70e7865cc4904a0fb9d182041f6c72d17fc5d5f71c0bd62a01791f37b8e976460ac8751eb5f1d07aa45f3	\\xc30d040703024766636ba98b71126ed23a0181d0b35c853946c20b7eadbdb354d33e77b5b95b06774f9df1ab13280dd199d15e15344deee254f7f4f12e715a52cb7e1171860925c6055c0d	\\xc30d040703023ecc26c519187b9869d239014711d25d263c77b93f9f99ce9c02e845298cd3312476f1bf45db85d7148953dc6567b58ebcf0aed577053624f2c39f90f84dd92349bd53db	\\xc30d0407030289bed2f03b41c67c7dd237018d7b16c0306c739714e5d05d7a30ab943bc8a52f5f42e24df752ccff1a73c268a147012e02f7fa042277d9e9aa151c8d5f883b153068	\\xc30d040703029ad200a606f6f12262d237010e0cb8cdc53b16155d978894c5af134dba8088df04a143e75c6d69bd7b022ed48769191b1318d3473f7ca826c7fca0e015361e608733	\\xc30d0407030252c39a7b9c9f235961d23701390b224fbfdd0816284ec813a3ba7845554957895ba1ba2b88636f81b238969cb8e0b7fd11e8c2a0113a75dcf139328791c137b54552	\N	0.0000	0.0000	2026-03-09 20:20:12.356885+00	2026-03-09 20:20:12.356885+00	2	\N
16	8	EMP0016	Leila Leroy	Responsable Communication	ADMIN	ACTIVE	2021-09-01	MONTHLY	f	f	f	1.0000	\\xc30d0407030273e2371135c126287dd23a017acdaf0bb485f5e93dce2ed4369a71a01bc1badec64291fd39af158740386b73e281c1bdf4280298e86b00cba59cfef27220201727a652d084	\\xc30d04070302719d30a3fa6204d063d23a01b9cf8413e5a5617849080ff7c12ef86f40da721e356ee2874550878dae3f73dc6d9d4ab917edbf35928c1f2ae5aa3add2c4729f1f3d1ea738e	\\xc30d040703022cea5691acfa987a62d23901a54a2049bb7de0ad2fe07a4c6a0ccd6658bb17b29068662c7545998f7a2fa5cccfd2f738a61bf4fd5e0d494566bd7cd0ae4266c8adf36354	\\xc30d04070302e7640862d9d0826770d237010526769e213e376c8e2a6a75f49d61c2bfabee62a90bc530103e8d391a29479e6bd7e0c953e35980928b743973b197f6b96373f8101c	\\xc30d0407030278e6ddac1db6773c71d23701274653cc103c1bdf87bafd5379e8dcb83548334309ee7bd2db6b32f02a58e1d52304a3b907a4e102a2d08276f73055ea304c2dfaac7d	\\xc30d04070302412733215d3b7ffd7bd2370101ab4338463c496e90af22a91296146f7fc57db94e69c0f5a158fbce299480f4019fb38d4c7ba6d690993f2bf07b618ffe14f0a7c098	\N	0.0000	0.0000	2026-03-09 20:20:12.357582+00	2026-03-09 20:20:12.357582+00	2	\N
17	8	EMP0017	Mohamed Al-Shehri	Infirmiere	ADMIN	ACTIVE	2022-01-01	MONTHLY	f	f	f	1.0000	\\xc30d040703020c34cff33f8c06a163d23a017b9efe74c42617f7a56c3ca0e0ff094dabd0185c098b5db998f7c7c322d8f13df84ce9277f0188c5024b70b5b3cf88323d8144a5f43544fbb5	\\xc30d040703022ca07f92237192f675d23a0115b5ed6eb4324f9b7306ac7a739c34825b286720753e2a3f638fd6a9e0e5929bb65149f5c9861a333462b51bd30b9ca4ec093b71fa10713a17	\\xc30d04070302c22659de86a935b570d23901104fd5cf47420a6f96b1097ec5458ba3569ed7390f373def6ed310664a32741ac918ddaae0e19c45bfeb0123c4d8d6a8e57dad7781698fdb	\\xc30d04070302ba3320375d6044207fd2370132a3fb60a9e0bcefd2e26e4c03173cf70d22d0cd5310c8a097c71a945bb75224bb0277bc28fa507079472c79f917ff04d9b8767bce2a	\\xc30d04070302b05fbdebcd5083be75d23701b6e7003c17e5aee8e59f51e178cc6a5fc522d143b2674235e7fbc692a77828b71380cd23e18559a3ce04cf545eb3a063eefe99d9c0b3	\\xc30d040703026e6ca91725ed457f62d237017f1ba40b529926e2a796d0d3ab811aa897b60902d37df70a159b945aefeb0c10acc75fa97e09bfbde4655a755a08b8ce91a8b05c7de8	\N	0.0000	0.0000	2026-03-09 20:20:12.358361+00	2026-03-09 20:20:12.358361+00	2	\N
18	8	EMP0018	Julie David	Enseignant Maternelle	TEACHING	ACTIVE	2023-02-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302e562802529dd008674d23b016d4573cd2583ab90da06da5588a91bb4e05a797893f02a6a2de507fea5f98dff4457db51d09b5131a7b8cbd6431bf9fb6f22bc0bf7dd84240d70	\\xc30d04070302f963111df6709f9163d23a019238daebf584e29bb0e00ee584946a3c64f1c0cce5a7566d7b6f5a8a9764a82ca38203514487918b6afc033cb230571e5cfe50bab5d37b54e8	\\xc30d04070302b2920cd17f833fdc68d2390119c850be8ff11cd761d4674a92e32f0c3441d8ea44f2f932149a35b3b0fec97ff35eb4bcbb1a922871e474b2cee7fc3d85f05101359ab48e	\\xc30d040703023e9cff49e50b158764d23701a34d2570c0931f437a44cdc4874e760e26034ab18b89bf3f7726f73d9d72f40582ef156b1df91c985cdb00c8cfad5eb2072e0fe028b5	\\xc30d040703028350a011d1c8563b69d23a019f90c4ec80cb5c6810e8be5bde894f046de14b736f40f6ca149d6ad5ea341590954dcb5ab6f777de98ae545dc4c99344194ab1c61ee02fcb1d	\\xc30d040703024188f83ac578dc3f7ad2370172284d5c4e9cd1614402754649bf41ee730a49945c222250bb7fa192cfadea3b47131352d12009a5902e7bcb8d194dd322d7349121f6	\N	0.0000	0.0000	2026-03-09 20:20:12.359122+00	2026-03-09 20:20:12.359122+00	2	\N
19	8	EMP0019	Ali Al-Malki	Enseignant Maternelle	TEACHING	ACTIVE	2024-03-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302ce5cf41bdcc8f13a6ed23b01d223b871bbf0c54142fc5ce374af654cdaee90f6f22d775f62cb0b228ba1924aa485c32d5a31edb56043f58d98877b8d82fc74ac4462ff3e01de	\\xc30d04070302dfd6f55d2ab833756dd23a013bbca017730619745e4601456a7d5c75d240dba94bf91fc0ad82f8fa75a682e1c193c2bdabaa9db245f15fd47a45f100c8c3c4d685c00fa8d6	\\xc30d040703024c76790fd986da1a77d239010da5cd050711e72cf7ff68c50fd066c59b11602c8897e76b99e3f0852186b9717bc88e4206c003b7d4826b86602a479eac1d3db45608b4ee	\\xc30d040703020ec0cb870170ff2262d23701bb40a4dbc8bffa42a73aa07cab688e45aa4814ca5c0c1d8dd18d0f6345a631fd7e85090b1d6bdb09aaac7fd511b3c095d56afa5d5a49	\\xc30d04070302b72923f17f17cfbb7fd23a01f0668e072a36d20aeaf0bc753123d275a5550170ae1b4404f28f52f9f5a33009bad1d4ce662efb61e0b68e4727f97d678c43291bfadf17a425	\\xc30d04070302d3eb4a7df5ea305f68d237014a8bdb04e5f0306671bfb3954965e3f83a100c931a63cfedb310aed7cc0e584e63e91bdd4d51201c50e33b8e15de2addd88b2f48c801	\N	0.0000	0.0000	2026-03-09 20:20:12.359799+00	2026-03-09 20:20:12.359799+00	2	\N
20	8	EMP0020	Rania Simon	Enseignant Maternelle	TEACHING	ACTIVE	2018-04-01	MONTHLY	f	f	t	1.0000	\\xc30d040703022e971b68c4b21f4574d23b015efb4000daaa7a5b9560774afa55aec3a43a096b7352a5d16b2445f38d541960e2f58dbed488b2c0acafe6eac7a1849f345303b98fac6f1533e7	\\xc30d04070302ff7b024d53c68f866dd23a0194556ed8703153216bc839d9dfe1ef02bea59560b34ee46db700b00a3163c06d87bfe38fb0d5ef6f038a66b2b2927a5568daf835d7f3ae680a	\\xc30d04070302d2990580960c6d7e7bd2390157b7cb7f78174abb9bce16e9a7c5244d0b72e0a45e405adfa05208e632bb72cb548f586f002b622bdce4342805b7b8ccb809cbac035eac0a	\\xc30d0407030202387ba0916d66ee70d23701baee527f4423e3951bc9d885ecfb1ce6c0077d2ef0ed2074f65bdbe28efedcf68339bd28325f31dfab0fa7cdb13ad8b3905c39f8ee2d	\\xc30d040703026a355dc91343558276d23a01e2e1f0d80f49a0e521e394ffa35e4caa4ec0a1751abca6775d5042cba6591b01ebf38dfb632aa569d0372714bc2a77028aa05165a414270857	\\xc30d040703022e59c9445ba445496ed237019895a85dba8b21fbbae88c0e829625e05c6fda3da5f37437b64ac8426481715c3355b410b40a9a51ffadfc9215584dd1ea75b25da83c	\N	0.0000	0.0000	2026-03-09 20:20:12.360536+00	2026-03-09 20:20:12.360536+00	2	\N
21	8	EMP0021	Karim Boulanger	Enseignant Maternelle	TEACHING	ACTIVE	2019-05-01	MONTHLY	f	f	t	1.0000	\\xc30d0407030274399c4832f9440c79d23b01cf31d3d22dc6308aeef1205bdeab7d55302704a2f7b28dd0f3507870890d27ff3181e1b82ba13f78a6614ddb402120163808e4c50c3a02ee6042	\\xc30d04070302695cccc35f9079556dd23a01a802a7f53c4466f37dcee30b21a0a4f53a384bc4d260a601cbbf432a146d32e6d90ebf95924eca58c5160d5f5f0e4784046be568af33615283	\\xc30d0407030211dc1f2435c6470f65d2390172f4e74da4bccc9e1e1face865635fd701875984ded587249362fccfe20ccff9e6801c66a7db4a6238af956c3e8f677f4d97affdb6b23eab	\\xc30d040703027da0979a85d6612a69d237016b9b3e7b0f1cd8a947203183f30f10405dd021e41d7085d523f5a841caf27dddbf6ac56791c2fbef7e5c74e4741c085bd3380964b8b9	\\xc30d0407030203f8ebd00612eb0463d23701e4343470fe302e7338da427ee8eb0077acd6e7738bf7ad4c7062d6c0ad0e8c20ff7535ed2f65ec3d099e2a2a71253304715f4bd63f01	\\xc30d04070302c8fbd504b48888b86ed2370115f749109d44f6dfcca92c81656297d34206fccfaf606346e1802e31e6cb047b631ae1624fb862b816d772299f016fee6d81903b0ee6	\N	0.0000	0.0000	2026-03-09 20:20:12.361262+00	2026-03-09 20:20:12.361262+00	2	\N
22	8	EMP0022	Isabelle Chevalier	Enseignant Maternelle	TEACHING	ACTIVE	2020-06-01	MONTHLY	f	f	t	1.0000	\\xc30d040703022b2e907757ad34ba7ed23b012024e4f795677709f1a8fdf7f3a53bf78ef23a5cb8122dbb38fe5a3f62621d0c96dc8455928c93d6d6a270e46c901095494bf742e737436f55bb	\\xc30d04070302012605039c0bb34f71d23a012b81453be1739e0428cfc818459a7fd1331211d097f45e2b21d9635f6d58b390f1aebf7398c0642cb9eb1cb276d25062aa01f947bdc2ca2757	\\xc30d04070302a254e4c038ac13f07ed239010a3757a988ab27c4ae46efe95b78759ce0bb5bf94362f954d232f34f8655e6a28f8571bf67eb22ce7bfdd00b65a66d40fb361b91cb25a3eb	\\xc30d040703020342f7dd72fe5f7374d23701e55f9038857ae1f7aa6dbbb2e18d8bc13738c0c4f0a281ed9bb7729e5edea1eb5529ca1eb6933d23aebf47101318bb4698a742d69fcc	\\xc30d04070302032261c841f4c2696fd23701ef0e2f8693622588e83523c5bb02dbcbbd30d641a4d34fef75899c3b366d76c420725aeacf4edcf3dc3723306c4fec173a0fbaf09f71	\\xc30d0407030226bf99f0eaef159d7fd23701bbe391405c25c13262f9d564d20c6c7004f8a155584c9229a32c34aac8a0dfd1bb7b2782f09849d660a881855b55140265afe71693fd	\N	0.0000	0.0000	2026-03-09 20:20:12.361913+00	2026-03-09 20:20:12.361913+00	2	\N
23	8	EMP0023	Samir Al-Ghamdi	Enseignant Maternelle	TEACHING	ACTIVE	2021-07-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302e70b808c4593cfb870d23b01bb43646a71de2ca203c973f8dc06ef2ebcb42f421c067bf8727b31dcc959771f9937af55a7185904ce699e7b602f551a45702c32a26f6eebe20f	\\xc30d04070302b5858e9077dad60c64d23a01e06022c483c43dc5f5d9a3790741f8a3a1c287b5a5afa3340da768bd4cdfabf1bc51bb805d3dfae4a24717e9598e927e53f73eb20a8dfe5dea	\\xc30d04070302e791eb0bd58665346cd239011fc72034965908d5ce7da61b5cb8a7961fe916835e65cf86f80bb834668f22b8309deb0a1dfc263c3215a94adbffdc6a4d253160023fe26f	\\xc30d0407030297187da04032ff736fd237011c37c48263a877f1e6e0a811a3ffe425ecbce57233eaa88d1b2cefa065bfaa35063730dd50cfc236fd35c9b55ebf5b512fd7a41f234d	\\xc30d0407030247d694603849eb6b6bd23701ed19dbfadadb21b80f5a456a9d537e91e5b72c24e347e7ebd1b4a50fe41038ccb22c305c089095f365a7a3f5a7d150701b8cb9de4633	\\xc30d040703029b946baba8eaf09b6dd23701bf311d88756e7c8917c6bbb397faeae772efce2cc78d5a55f9ea48b4c696096cf153c6a40d78f1d8d6e354eb177d30ae8b078c799259	\N	0.0000	0.0000	2026-03-09 20:20:12.362782+00	2026-03-09 20:20:12.362782+00	2	\N
24	8	EMP0024	Nadine Fournier	Enseignant Maternelle	TEACHING	ACTIVE	2022-08-01	MONTHLY	f	f	t	1.0000	\\xc30d040703025ef9c45ecbcc56457ed23b0177229a305d9abaa85ec8e21588aacac436ca2078cd60779ce26c80a8a5cb7e4b6321ee70cb4ba623e9592d1a34cf93bbe4ab634c7cd1b6a900fa	\\xc30d040703024bada4ef833e323971d23a01dd2cab2367849a14c5d14a1186e7296bff184e1e7eef80291704bb94f368470ff3e1e07d49dc0956e960fd3149023a4cedd3a27562e6430249	\\xc30d040703027373664676bf3aab63d23901c992a718d463f5ae3bf3b515101740cda2b168bd96237e1e482c48bc53bf4af9f9e28b757f95f94dd3fd8502a275c1e20761ff06ceff6d03	\\xc30d040703023bc4e64f9a47768474d237018caf37a233006cfba87c29ff9ebda51c4273e88efbf4afc37f6e519963c9006ebd2688e8deed91bb085f93259588341272161cbff38e	\\xc30d040703020624d6741bf5c3fe7bd23701e682902c040a6880ea19099d6f8d3a798da9645623e6ace40b07ab179b126111fad7dd3e53e788150461006064545ea46913028cb834	\\xc30d040703027af030c2a566fe827dd2370149953e28419f7924ff4139f36b5b0ec1bea51ea44c5acb006efaf61e0ae32e6df9975aa29ba7492c5a2d8db265d33f54b03131e676fb	\N	0.0000	0.0000	2026-03-09 20:20:12.363416+00	2026-03-09 20:20:12.363416+00	2	\N
25	8	EMP0025	Rachid Al-Zahrani	Enseignant Maternelle	TEACHING	ACTIVE	2023-09-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302ff61b789d0654a8161d23b01a7c1d8f99820a6812489a61dcc9b68ed41144f7fcc2d40492f78b0297b5bdda425ab8f44273816e91d9736c4f6520e0577f36139e8015963a96d	\\xc30d0407030266ad08cc9b6775e467d23a018b6fcaa9e78ba08e902f824867f61584dbed08e50ea336fb2aaf815d94647d4440d45680ba0f79929c263262f379335c6d398a2a15946ad6a0	\\xc30d040703028d64fd61ae676c7279d23901d9527b5fdf38bf57609a49905bc40435db879f25bb8a8e3e709a2b96b0d9e3f926044a5cc9ffeba2e10f66908ee3d585a39c30d29eb3779e	\\xc30d040703028477956dab7cb2786dd23701c1cb7232933ed45b398270ee5ef151e04042345a693113b1495d0024facefd20c3fc528a2e848daed1373788b0a0c614ca33047e57a4	\\xc30d040703024df2259f62acef396dd23701483ba85ceb2f42652bd90cec3fdf03fa6105c86f4afdd545c2a317cb98273f30f010114de8c09d6d060795f3c847cfa7b5d44f6925d3	\\xc30d04070302547ef47717ee50ec68d237013799aac5074435dd44b8efdf3106f8b5df8e56317387f6c9f1e99d3a0901ee621d2c12386b91a6dabf725ed55457af25f1ca5f73112a	\N	0.0000	0.0000	2026-03-09 20:20:12.364337+00	2026-03-09 20:20:12.364337+00	2	\N
26	8	EMP0026	Camille Girard	Enseignant Maternelle	TEACHING	ACTIVE	2024-01-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302d58b676da89398bb63d23b01f527d10c2bf469a42ec8c90ef555a8f106e8fff40bad9f1a058eb710daab650089ebdd432609e4571801371744709484b5eb7bb7af0b672b9f5a	\\xc30d04070302e566c673d37fbcf266d23a012b419d2529f75a053b44cac0a99804a14eaa9a7e2b2ba53d941acbfec879342da4210ae63665bc6eba08b39a8b4b9ac6826caf1a2449eedcc6	\\xc30d0407030265fabe2cda691e436bd23901b010b03410bf81cae01a79d02f6a2946c9317d92420b718475ebdf10b8e60cd0e9a4d107fecac663c425b2a78c6893c7bbf77e6f828b9dab	\\xc30d040703020da8a13d7a58f26267d237014d5a80f91c1ed776c610d929319b3b08feea0d1ae699dc4e146e109840e26851eb9cd2d8015b92130b6f66473810e1037c1ccc6c7764	\\xc30d04070302b7cdf683cd3ac5d970d2370164df0619041f81ed3de07af31f9d73a2aacf619bbc47f5e5602a2f4aaedd252789f4c537f92066819e31e517e85f1d41d565898f03df	\\xc30d040703027eccbe181435cdf279d23701a919d1bbcbdf6500cc81e2016aa2f956d5bc9c0f83dba24fe8dc743ab5e57851c4e138e1222ce7f4e93b9e1a027db19d5cddbf43ad59	\N	0.0000	0.0000	2026-03-09 20:20:12.365463+00	2026-03-09 20:20:12.365463+00	2	\N
27	8	EMP0027	Mehdi Al-Otaibi	ASEM	TEACHING	ACTIVE	2018-02-01	MONTHLY	t	f	t	1.0000	\\xc30d040703024e82cb15ccff9b9778d23a01d2ea721428171015677ed32ade4067f6d200dcf3dd38e74a0b4279d52d440f4a470e5d358e9f5ffc4701416d89f53367b5cc62c25a103bef7a	\\xc30d04070302bad10a643bf9dca96bd23a01554fe9fae77d4e67add61a90fafd4277a7ad78fb835f6c139d95799fb331d6ded70ac3f5a420a59e488fd7d1d1f0e89c83b74fad1c2afc2eec	\\xc30d0407030284b0c2200606e14b76d23901a2ce9ef816dd62884e54784b5164078c68324785aa2306da25c7b1647f2e0a45ab8afb1e7cb94fa5d5563ea294637bdb0920d3ad18828363	\\xc30d04070302c4904a2ac2eb3aac78d237019c2e5b0bcee8aaffced059f03df341858bc8227b9a0fa1ff537a5d630eba78a473c97bd4cd475b140122330b19b743e36a7647c6e19b	\\xc30d04070302006ce78acda5464b68d237013081e0cae91f7c6c159c76cd01d47070cac86725af0b44569e9f4f6349c63d5150d4a1be929311ffe8ff3318da7eb15f885b2f2b2021	\\xc30d040703022f27dcd7707efd5c71d23701495a326c1ada2308d19b02be0c5187b0f34fd98d3f5f3a6d11d27a15334a0818836dbf5289784279b3f1b90688d8c53ceb5194ff4603	\N	0.0000	0.0000	2026-03-09 20:20:12.366376+00	2026-03-09 20:20:12.366376+00	2	\N
28	8	EMP0028	Patricia Andre	ASEM	TEACHING	ACTIVE	2019-03-01	MONTHLY	t	f	t	1.0000	\\xc30d040703025df415cc301efa9a65d23a01c792fb96f3b26295a72b10fb7d76896b673b19106d99adaa2e480268d9d4ae5bcb075ba5570ae518d42ff3d2d904b09003292e316cff773e53	\\xc30d0407030221b56b4e93f5941463d23a0148fb803d7b35a991c1104e454d02e0d51cf20e7f7c0a92cf7ce15f33a841dbb85049cedf3cb422c5a50cc56e188d478a56683574f9ce685c5d	\\xc30d04070302be49262f92a2d7dd6ed23901a685aa330a3f310fee3355047ae0c33af908cafb43ff702ab12d4bf1d8563001535db3ca11c1c783035ec34d681c3464551f011e376e3704	\\xc30d0407030287c751c1e88fe2c466d23701673f39229510e39ccde89729658c711c653d3543a2619ec11722e7f901409b74b5b17906398d394f78ca76cf8b2195b2876c868ff861	\\xc30d040703028248c87d066332027ed237017e8fdf1417705371cba6e50a8cd9362a33c8d1ad984c3d42dbc1beb4e4969076aaf8c2f92746b8b66a5e1905f37b8b3c13212e6a2ce5	\\xc30d040703027d95a4da6e5dc55678d237018d579d0f1a72cddf66742e9a045c781de709f6487d29308983d0ec8d46bde1f19120b2fc87e8f8e4d42306e61a6a0bfa4ae28d2231c7	\N	0.0000	0.0000	2026-03-09 20:20:12.367295+00	2026-03-09 20:20:12.367295+00	2	\N
29	8	EMP0029	Amine Al-Tamimi	ASEM	TEACHING	ACTIVE	2020-04-01	MONTHLY	t	f	t	1.0000	\\xc30d040703024ba73c20a213015669d23a0175342b710f48f583aed9ff5dadd37ab97054f90fd8fe0470a31be275ffb157b6d200f7f8199dd6960ca718f782c76bcf7630efedbd23cf0b1c	\\xc30d040703028e4dfca848e2856b7ed23a01151d9c38222027ae0a742472baaba452b62f01b2bf1d056842102c1e99d0f1a0b44ec665ee4f79c622938e3032b55a7198cb090020da5e3d3f	\\xc30d04070302aa24a4101684ca6863d23901bf303d986f7586f6f3a93130cf992862b8529dfb159ebef2e4056bcc6e2c296162e5ee5156094247c7e5fd00cf19717ea2ed006f89fe7322	\\xc30d040703023c6f4a067b43c0777ed2370104a5d95eed9931e243e5b3f4d6ee1e73f87e67799e9347e74a01bdfb6dec548d6ff6a14563a2b1d1228520d470affdd79441b703af6d	\\xc30d04070302f4929a93ef22915877d237019efe8cbeca5c6df4cfc2f6e4c659b297e15845403fad4cb2d295a04f2e109a6abf418f996d48a055efa5d479cdd106bc80bda8d28e17	\\xc30d04070302cea8fc83ef91f8ee6cd23701986324beaac2c37582b9bfe104105471c653db98b31bd74386613e92b85057bb0084abcff2eb04b1244ef6161127133293a584ef60da	\N	0.0000	0.0000	2026-03-09 20:20:12.368389+00	2026-03-09 20:20:12.368389+00	2	\N
30	8	EMP0030	Maryam Dupont	Enseignant Elementaire	TEACHING	ACTIVE	2021-05-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302236a98ab4ba7f85468d23b012b595ea3662c387d5fd76d73a87ef9c964fa9ba8f732f390eea38a0728f48de93bd6ecd0e3731f56a7ff703c642b141a86276bc85a9038497916	\\xc30d0407030237837ea1f631d8146bd23a019dee4d99866b43022ca67d2c0e2d6b150a40677b5b921a4c20f29ab8585beb233a27b1e9a4d114ca99cf8cb7d7b024f4082cf5892f37657b19	\\xc30d04070302e6e44f59cdc1482075d23901257969137c03d2e60db8ea43eb5f1a17087f90b11a3eab2fe1274332801b8a1a283a47e85aca5525897da7d4249561c15c84f1724527a0a2	\\xc30d0407030218373d63380dd7ac7fd2370183e17d82170a8f2c3c070f1a7084c9142564b5e9a78888c115e42a1938ab45f139291cced65cb102e060788ffb1f5d88fe5fe304207a	\\xc30d040703023ea3ef6e593de73778d23a0139cbcffac81a50f2766a30dd67d372a202b6b8a7dcb94035adf8e31c3cff7eecfa01c04b13f8ba79310b1dec66995f5b0742341f2804a51e40	\\xc30d040703020a064ba94286b4ac71d239014ab1b594234b9563434206ae88915bf7aa8a0eaaad98137ef152763bd955f07cfd9c8b8b54137e1cdd2b665c580128990909d7ec0fe408de	2026-01-01	0.0000	0.0000	2026-03-09 20:20:12.369447+00	2026-03-09 20:20:12.369447+00	2	\N
31	8	EMP0031	Tariq Martin	Enseignant Elementaire	TEACHING	ACTIVE	2022-06-01	MONTHLY	f	f	t	1.0000	\\xc30d040703027bbf88d588f4f0d271d23b01d69f1f81bbc2629ff3f6d9e9ab63d23d29d34446a83b85821dad49028731ffbfbd83e4b0267cba000cc5e45d878d87fff1c74492caa66ced8d7c	\\xc30d04070302c33cab15fdccc1a87bd23a019305d9fd206d98812368b5fa0247c82d389467d663300cd9238aec0b40d9b13ee5c4e54bbdcbe38d18d38f87315c9f02c6582c1ed4450ff91a	\\xc30d0407030229eb2958975c313863d239019b5d06e11c1a22488aada2738422da708414b186384fc2c8869c88bb92fd7c49a787deb0c591d174f6654068e63d6c04b0c7ae785c7c093c	\\xc30d0407030282f603fbeec6942b7ed23701104599e8c6a2381b13071c0dd6b157b4b16eb93500d1d1db2a0cfa450371babf0fe71f4506e30959abfd51135bb02b812f3b0b83a6fe	\\xc30d040703020ba3ad6a74e2f57470d23a0181a3722a41a39c71b7ef72caa5dcacf577a70a5477a97793191056688ea233d5743680b27056ab6f415215b4e7aa9ce140cfe993e4afd8d7ca	\\xc30d04070302d16b1d85253f91a064d239019ec3b3412481889870a6c91e57767faadf6f256203d1af306959e10924cdabf325d76714d4382e9fb317f04f5605696c46a7d7ae71600d96	2026-01-01	0.0000	0.0000	2026-03-09 20:20:12.370291+00	2026-03-09 20:20:12.370291+00	2	\N
32	8	EMP0032	Elise Al-Rashid	Enseignant Elementaire	TEACHING	ACTIVE	2023-07-01	MONTHLY	f	f	t	1.0000	\\xc30d040703020c1859a1be9f2b266ed23b012c3fe37c238afe34a0a6695102e11ef3f7935b1d8842f83bb5fbdf02b743366cf49b1ec17526687a686d8e1628c440530f71f7eecc99393ba6e5	\\xc30d0407030222e5ade909c82f6966d23a0184148ee940b618b589431704a91be123002f455970631f8c98e1e8903682de8cc888ff82416f3c6552d166b81dfc55b67583598729b32770cc	\\xc30d0407030282381a914fa0519962d239014e5e52eee87f8e4f571f472d15530f6732b7ffdce91a18a8e4f56bc68b67238f738a873e523ae1c44bfb2eaa32bbabe348dc4868fd5e162f	\\xc30d04070302e180a67f6920474f71d23701acb67128f154ccf324237012300ea3d8221ec79977576c320cf7171c4ab0085a24a1555080a9f420ede01178de1f94e1aceb8d3e4965	\\xc30d0407030237c62f41a14a37d160d23a01f39a33327ddd9623ddb50f579e8c5ab151bfbd009c40ea623ed4ac0ef086a27c320606917a88bd6210c51c5755b6c4a4ea397d855aef0bdd7d	\\xc30d04070302c5ea9f5cfd0ee9047cd239014d0b4b6d20f7f5acdcfd7b7631049340ee8950147f2df6c10a6d0ecccd3ca06c732c161d8f160a7ad8c41a1c8ecea19aebc064399cc0f26c	2026-01-01	0.0000	0.0000	2026-03-09 20:20:12.371104+00	2026-03-09 20:20:12.371104+00	2	\N
33	8	EMP0033	Walid Benali	Enseignant Elementaire	TEACHING	ACTIVE	2024-08-01	MONTHLY	f	f	t	1.0000	\\xc30d040703027f6aa5857fd5678b65d23b016d4ca26be1ed963e073d055f6c3e55a989eb69d10160c7b3dd3f81a916568930908186002b6b3569e0603d7b85ae353573a028f1d1a7d0b18ff6	\\xc30d04070302f6ce833bc0962d9b6fd23a010ff1e324da8fe6ecbad658b81ec734aa3bc497db14916499b6d351fea5bb1bba5bd12261b793bb9cb15a8ac21e3f28d8f942bc5221d2b5d3c7	\\xc30d0407030266aa4e090fd3d9c665d23901eb4a7aeb4b6bda03d30c6e1b8453660f467010d0becafd83fb2e3f034616594b51770c825151173d8da887ac7009d23b43be9d82c94728dc	\\xc30d0407030262eb28fddfee697972d2370181b468f8e9d229748ca60fa7b9b2e75d23cb338fb00c5f4c2a06f18b17afb07d73b73611246fdb5293e855835bc2a4fd392f42dfb0ab	\\xc30d040703023057b143e5fcd82f75d23a015ca16ee545d0c4746c62fb8a3246937fc77da9b455b5f6aa8ce0559fd9e6d8ef8b1cd27d49ba9f5b4879c702ffaf6137a211f0f32fde2d46b9	\\xc30d04070302d26dd0ce987e54ff61d237019adde0f7d67842bdca2dde3b73529ddb3241f6fdc51070ae2124b88bec66facb35ea800a31dccadef447e1a5f8776f963323cad071d2	\N	0.0000	0.0000	2026-03-09 20:20:12.371815+00	2026-03-09 20:20:12.371815+00	2	\N
34	8	EMP0034	Hana Laurent	Enseignant Elementaire	TEACHING	ACTIVE	2018-09-01	MONTHLY	f	f	t	1.0000	\\xc30d0407030297007c9e8298921475d23b01d14dd100dc2f3801397f236e667bb71db1b973308a8d45adccb833ecb161e510c5efa79cf5ae7d9759e2f348af2d2f54c2464c2c0eca385d33aa	\\xc30d04070302b5577e55126caca26ad23a0197747efc8e0a19623f3d5c9ff13ce8a7056f4128f59b141059b18e8811fa127cb826ba836b9dde661d7542ce6a376410ecc64e3cc85ad007a7	\\xc30d04070302a62f8d6dfda5d41460d23901330e2c6a93f612577c697f903d5c27a467a315feeebf59b212af59019e5a8a51c8213437e4f5718d05d14314e67b5282ced79a41dc376d86	\\xc30d040703022a170a6c623fb7106ed23701de72f390ba9148f24eb7c6fbd2925caa737b6433a85580eca77d2774cb7695966df926cc27c5f7b046bcd1a1dabb10c5810841efd43c	\\xc30d040703023e216be5f76d54ae77d23a015377f25309d9a478f0aad90db1c4d87e809c7fac44e698ecedbe47bb84bc0e33a98dee6f8f8c4e8edffbefb08624c699ebd0b9de435071c4de	\\xc30d04070302c64c84fae0c2a72378d2370126bfb5a362537d669a7243dcb17caa09152a12f855d0f9d6b5d990d17fadb19fe1fc9e78ea1db99c44ec4abd842c48f3eff41e07f12c	\N	0.0000	0.0000	2026-03-09 20:20:12.372469+00	2026-03-09 20:20:12.372469+00	2	\N
35	8	EMP0035	Bilal Al-Saud	Enseignant Elementaire	TEACHING	ACTIVE	2019-01-01	MONTHLY	f	f	t	1.0000	\\xc30d0407030257c2155716824d5061d23b01686da4c6d620b01ecd00f55049da2f2d083c47991af02888b2f963881335c0dbc21f01a5c37afe1c9309d569d6351ebad194495977b3b44c737b	\\xc30d04070302edd9495d3c012f1773d23a0142c4c6333bcb493308ff5b6353e14b6e9db49c7d76f7de41abb38daafdee6aae58225ead553be460b731d918e667a71845ff95e85406eacfd1	\\xc30d04070302cd109a03cc9e0f7879d23901d4e2fc2aff9409977b4eecf8753acbfe21a9c9a804ac774d2c5e49589dfa4578410f8767e94e2962b99cdcb6b37336b066f34018550f3879	\\xc30d04070302741cbe2820e2e7987cd237016476d3c3911cdbfe9db46e000b07b94a375809d64bff79ee831819fce02a16e2669d28184f55b8ddcbcca544c86cb6495292a7f6359a	\\xc30d04070302f53a2ff5d9a580e961d237013468b20258e0e14821e599b101da5e670ca4d1022976a14c9e6c4d5b876bbf03a572cd03ec5c94f6667aa02fb834504994a93edb7df7	\\xc30d04070302ff299c24bd8686ad63d2370149390cefb22b06f53a4e339c4ae62bc0ea528b89c63f9d20d6cb0e23c57e5118f8b184e59e9ed40e0373449874f517d73afcd097139e	\N	0.0000	0.0000	2026-03-09 20:20:12.373196+00	2026-03-09 20:20:12.373196+00	2	\N
36	8	EMP0036	Lina Al-Harbi	Enseignant Elementaire	TEACHING	ACTIVE	2020-02-01	MONTHLY	f	f	t	1.0000	\\xc30d040703028684d8fc3e3001da75d23b010981f55d1342987db9e9f493010e1b02f6390c74ea47ab123a06206af9378cc124b74291ce046a0eb416da59c8b338eb4288f4de7265c689162e	\\xc30d0407030288085bba6d9c3db07fd23a0193532819ae42b5ec4a9c09ebffef5328b523a7cb3dcc68b513cd3933805daa8a0d41a4d86bee8ccc52716cafd3cdab082414ccf59935e39a6c	\\xc30d040703026087e603197bc4d569d23901518efb7102f696fc8b4486cd9084af96494b28f531ebe1be4478cc41fc19988d8dfe1e28a3d39b3371b759b442fbcf72454043b27d9d3fa1	\\xc30d04070302f69f471271f614d17dd237012fef26f17ecb8f1a8cac34769bcedfe07c9944c7a69947ede1b09825aa2e9ece1effd38e7510e7df1578a4cf582132c0827c3304e325	\\xc30d0407030268fda5a6d568396777d23701038fc87d441d50d86360e6de07e0361db32caaef7d70df0a087c773fde6d904e522e3b593521464bc88b900d127f1f1c1a8f8722999b	\\xc30d04070302ba141cd548d57c5c75d237013e8f80018b2995d377b67b165f5c81df4767ca879a414a7ae8a6e1d4bff2462a6f69950696b51deabfedeba082503f16937cef176222	\N	0.0000	0.0000	2026-03-09 20:20:12.374244+00	2026-03-09 20:20:12.374244+00	2	\N
37	8	EMP0037	Hamza Moreau	Enseignant Elementaire	TEACHING	ACTIVE	2021-03-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302ee70fef699b1689362d23b01f4cecc52278c51883f7071dff6607e2992ad1a03c97e0b2389715d9ae69eca53953dad9c42f6e4650e194886a2cf8ff44c1d9c7b7db887ffa892	\\xc30d04070302385cf88914de733f6fd23a01e2da144a2c122999e57724b0059ee7071e59c5786a7729761abe7b2bb1c37f8394cf5615b1147b063d0c097829dfa65e26051702de10cde4b2	\\xc30d04070302e99d64598d0d796577d23901f0baaec9bf325adff395569aafc0d7587b4e6a42a66e9e8985a847432dc4f3f0fe7345a121410d619413619504b444218168b6c9acb12564	\\xc30d04070302c015196d0484633963d237019be856ee9ddba106e62ffcaed0f27838d80ad0e07bb48c8add9b4865a020e6a1651dad70168222dbd2caf94cc8dfbcc3f63d617c1c3f	\\xc30d04070302179c235e2ba8f9a373d2370148edfbbb06f56e88b133c467042a8fed4c2957296306455a9d7207e588db65f189196b5fb858fca1366642dc8a7aac19401a136c5fcd	\\xc30d040703025df6e81f0e7d251364d23701077033bf6a937c2c9c150357591a5a3a8bb4c300118ee4e6e80b25de3c87b166e73621ba8c7035c0cd2681e313e66bd4aa4d45d75736	\N	0.0000	0.0000	2026-03-09 20:20:12.375132+00	2026-03-09 20:20:12.375132+00	2	\N
38	8	EMP0038	Chloe Khoury	Enseignant Elementaire	TEACHING	ACTIVE	2022-04-01	MONTHLY	f	f	t	1.0000	\\xc30d040703022138d63d8578fc6372d23b010453fe8710dd170e254ee3a7cffa7ed9f7b499a01949a08e5c7485661ab5e7436f515683325bed7d7e16216296c64bd743f52047436b8907f11b	\\xc30d040703025381629b256a5eae60d23a01ddfeb1c6c77e22ee68fcdde58c432a37383df2053d7c169736a9c1ec1b426260c0ee8302485b4e79bef8a92c07e5fe0617729c472d34fbea5f	\\xc30d04070302581e94d16988ba7f70d2390169bdc326ac8863cef02d8ab869c9d56e391e0f182304c0f13e03d443b4585f4509a12903c2faa1998ee73fde48d8206b94ed4091ee6c35e2	\\xc30d0407030282fb863176782b597fd23701d3094bfebcfd27443bc8281964fe3d39843ddaa74a89b6fea2b6bdbc28599e9217e721f983ae2bd813f52b437d1f52033123dc68394a	\\xc30d04070302ced68e1dbde96c7f60d23701c2f91b025b5b8f135f187ec13307898f1c9398c1a5249425e75493fb82434ca934b485efa52759322d7e50e18535d3e852f9a4548a8e	\\xc30d040703027c99bb433aa403f276d23701cf567d2b1a57fa37187fbbb75abcb69a5c1d7a688b73ec7dc688accc5272f21260758a0a1c703fc5e37a09072e8218ed4b0f2c5e2893	\N	0.0000	0.0000	2026-03-09 20:20:12.375805+00	2026-03-09 20:20:12.375805+00	2	\N
39	8	EMP0039	Faisal Dubois	Enseignant Elementaire	TEACHING	ACTIVE	2023-05-01	MONTHLY	f	f	t	1.0000	\\xc30d040703026793145d0eda7a4876d23b0184ffedfe57b61f1eb723886118a30bc89be3cd6a950cb7fd59a41c15def25fb9eafa6d800c5703fb1823de5c5dad5e65b8538c691338ee52b4ad	\\xc30d040703029a3e71a06b30a66a64d23a018adbe4e66f78ff4a933c2f4014087ab1cfbb6290f649ed067b66b02ed52538c2b9951d89a86a3d3dc20ff4a522ef20b6cef96585019035fc64	\\xc30d04070302ea4298ea4fd6a95367d239013677b20197ecff6788de1a3e6bcaf82048e18f18b5897ac810b22f6cc45dd266e554e07a7cc3db2c5e886477ca878306c457398dd399e811	\\xc30d04070302faafd24ae2a1f43067d237018176a5438361ba4088bd0b08b041491bea7164b1a17a830650122bf25ae3dba33dec53d38ea0ae3942d266ee811cb90d92f2b03a185b	\\xc30d04070302f606e2b6bb05c69c66d237014e0639ac1bc38d65a9a8858197727c39c0b840945cf8c3f7b875cb4520f778fb446ff0cde120e27312f80fe726557a0472fdfc32b640	\\xc30d040703020f9f775253ff648c62d237017d6f798d46f788c9f252dd36ababad3828e31def679f94ba7669508052a50b123ccab4d0e0abc78f87d6f01529360bd44be50e7e7ec7	\N	0.0000	0.0000	2026-03-09 20:20:12.376555+00	2026-03-09 20:20:12.376555+00	2	\N
40	8	EMP0040	Marie Mansouri	Enseignant Elementaire	TEACHING	ACTIVE	2024-06-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302c0b83d14c2a5479471d23b01ae9f290011f6821a522adff041b4202fc94ca81f1d25da2fd46199a426de2620e3b2172e3395dd81bbe6f0a0212db749707aa5cbc981cdec6cb8	\\xc30d040703021bf83d079240f2c861d23a016e18cd058f436c2499679314852b98508b44585e231d36d28e5823a722e3247e5c9851d4c280caa1e62506648c77a3523e0194ab8eee5aa4c9	\\xc30d040703023259635fbcffaa067ad239013a5e25cdb8f0f0a8302b68d1ca93aa74a84eb8e4bdfdfb2f9ef56ead00c324925cda5c4dc759e5bebe377cba9c4f5417691141154ba334c8	\\xc30d04070302885ecde8dedd39ce69d237011800ec1569134523e3a417dd5299dd9fb84f91641e69c91b56ea5bd71e43eceea15d4a9ecaec9b1551c8bfd875446a8397084ee254e3	\\xc30d04070302367d71df9cd6c6ef6cd2370184e20ae9cb4fd54f6a867d4ffb4c92983a762e2a31c15293b410de9d48d33b23c2420ea0fd27c0cc626f8dcf691e9db5476455fddde3	\\xc30d040703028cae3f40d9deb0bf7dd23701bbeb3e60d9d972895681f9d792e3dfceea47cf14deb4cbf88ee3423bb6d2d5183a6776373d6f01b08e94d020b78a1d9d7a8ae10a9dd7	\N	0.0000	0.0000	2026-03-09 20:20:12.377206+00	2026-03-09 20:20:12.377206+00	2	\N
41	8	EMP0041	Jean Petit	Enseignant Elementaire	TEACHING	ACTIVE	2018-07-01	MONTHLY	f	f	t	1.0000	\\xc30d0407030221dcad0c98cac4d56dd23b011f643eb416b9c551cfc42cbc9b7cb2cd0f2d4c9e98e2849752b9ea7f025225b0a4beff2633553a825fe2ee6ba9da34c02d49977f2574207648cd	\\xc30d040703023af1c2b2390636026dd23a013f447af28e1c7d99f385803492c1c03fbf2261924b7b64213fed9ea9b457805174f8949bb9cc1b2c885d0d5c3ddc26e07a2eab5992fea34acd	\\xc30d040703028e811cf2711e49797ad2390100139decd956b357a73ea8d70d8d99311fe52d60038732c4004a324afb2499b923cffdad9bf588b2597993c69ec692f4373348c0c98f0eb7	\\xc30d04070302f399687170cf9f4d6cd23701044d1d197c48d31051b60606a707b14e2ebbe20566a7c036bdbd32098fc4eecf9adb4afedc42c8f9281b47d8f5dbbc3a4114afe8ab08	\\xc30d04070302f8e0cd350d51d24269d237014f6703edfca1c3626d40a5c9641dffc28eba5c34dde10c7feb6596f28b3b7914ae809dc6f597a0c1ee7d2aa642208346059fab42699b	\\xc30d0407030264bba017f9a1f11079d23701368975460fe2dfe7884030caea7a049edb99f94785160b14c9706d716146657169477714f77577e8de1d915898fb761bd8725a9f399c	\N	0.0000	0.0000	2026-03-09 20:20:12.377955+00	2026-03-09 20:20:12.377955+00	2	\N
42	8	EMP0042	Sophie Roux	Enseignant Elementaire	TEACHING	ACTIVE	2019-08-01	MONTHLY	f	f	t	1.0000	\\xc30d040703026ccae7746465c5876ed23b0133dc345180913b9081f71bc7f9a7085d3a9eddda17601add2e22c496cf0368056d625519886b42ff6a463bd6bdcb1ddbab5c4700ddad7f0f5816	\\xc30d04070302d2ee5c1a63ce875660d23a01d62c9728711ba7bcb1b26ac102b419d988daa6f5be84b9b7727cf61686f9d1a88a481370a6224c6db0ffe992218838d6431c7788a24d050ccb	\\xc30d040703029cba7763463845287dd23901a27a5e52444db035afd828ed58c0628e0a8fd7f3214e84de6322134325552c964d2b18fdb989ac5412a8da4b19a7f5260fec0f467bcdb881	\\xc30d04070302dc7344b22cf9eb1662d23701ea8aae58307bfa020927743bd12e4a53f9c1bd24f5845e90471531c8e6b22f37af7c100d821805c759efa1d454b356c504c623391b93	\\xc30d040703028c1f07aa3918189a69d237014982cb8b4740e3e4499c569e8b7562c69f8497257fce62282c776d4a667ac1e74dddf4a8104dd0000039b159b4a6e25e0a92a98e5c92	\\xc30d04070302a3f501fa28a0132277d2370145b777a0afeaef1c126e837711625d454682be48668bf9bc932d91632b73782efdaa55c166518429988b222189ad03e242e3e7b387d7	\N	0.0000	0.0000	2026-03-09 20:20:12.37868+00	2026-03-09 20:20:12.37868+00	2	\N
43	8	EMP0043	Pierre Al-Qahtani	Enseignant Elementaire	TEACHING	ACTIVE	2020-09-01	MONTHLY	f	f	t	1.0000	\\xc30d040703025adf07e39cc0f9b666d23b01c273fbfcfede5aed64a1d42ebc0ad6bf5944d161a770b894874e4588e48958f193f043a92ca2a5957f399c1ef56c90ee396efd67717ed3f8c976	\\xc30d0407030229212e90e92d5fda72d23a018d170fd2069793cd1d793e68db57e91e0025bcffa35a075dbabbdfaa3d7a440c3459de0e78fa3d4671864ec588a76675e9ae65129334045f5a	\\xc30d04070302d8e9e82a318ad2e965d2390184ba495444125d960f28941c163df56e5af7307b2c4b868869cf1cf7a7cebbfec1012d022246382355b86bf8be218e90c9cc007e17ac9f55	\\xc30d04070302290f68647caf1e4077d23701155ff683ccb451bcd929aa633f7e2e3d8c0e7adc0326cff542e5747a1741e5d2690300bba96fcacc6d2a0e140462c444ab805708a258	\\xc30d0407030257a525ea21f80b1365d23701d6d913be5c296a3e8638ff78883f899892396e33999c48719f7ef56de14b17abd7cbf242eb30acd4ca135bca8e496f2ec051244dbec6	\\xc30d04070302ae017813d551b1356ed2370199003ffb57712c0e37f312c9ce2334bfa641daa63548fd85989e51d78e5830a3f7b39e313e3d3343ea60f20d7903117a72fd05074714	\N	0.0000	0.0000	2026-03-09 20:20:12.379516+00	2026-03-09 20:20:12.379516+00	2	\N
44	8	EMP0044	Fatima Bernard	Enseignant Elementaire	TEACHING	ACTIVE	2021-01-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302cdf2a3b451b749eb6cd23b016d2fae0a89cd744bfdcbd3e11382f960e759a3d6b4d9b6abb0314d559326e6a4dc763b2db074c5f4a018ae667d114461a495ef5083d99760c92a	\\xc30d04070302450deacd43b8d0546bd23a011147e6f406bb12445de6beddef82e11afcdf04d7240a32bbc12611ee561b55dfde3c3fe356762caa00f11e578f286e21480f0a6104a655f6ea	\\xc30d04070302bbb38d7a21d97f2e61d239013b800f741f3034f1fd4786b762b45298a4d6d8abba0468d2956ab811b60180793b6f6bd28c964eaf90dee914d1ce96c09a5e1c4be9e9e834	\\xc30d04070302857f330d8690b76669d23701021068e03003d7f1cc6b027eeabb1f8cb3df50d0e387d1f781605eae3b179b7ec0e257db055302a5362f002869470d3d39d69d32a82f	\\xc30d04070302ca25aa32363edae76ed23701fce762acde2928f72effeb748a8956145a11ab00685e98bb2427199a4052bbeeff6a98ce599401079ddd5cb9b33739b67658fed537cd	\\xc30d04070302f8e536301011a9616dd23701e9a61a8c3cc7a7448bd945fe9c3ba58c17fb5aa72ef4b27db0f9a4a982f9e65860e008f93954ee81ebbf3539540d71271bb6fec24a0a	\N	0.0000	0.0000	2026-03-09 20:20:12.380202+00	2026-03-09 20:20:12.380202+00	2	\N
45	8	EMP0045	Ahmed Al-Dosari	Professeur Anglais Elem	TEACHING	ACTIVE	2022-02-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302636865f109d909987cd23b01533027fab5f3069ecf5d0832daec7df420243bc06feb57dd655f37a42fa215853de82faaa3cb606d55e7bbe22e57ead68c715ce8f16ed18f4c4b	\\xc30d04070302a0150335280e5dca60d23a01205fec8c40d98a3e75f3e47a0a2d1e7a9b29e6665e8647c1675cf11fc19ec8c553c80a04de5b4de8b345c643dfb5ad0bbb9d52558a99e84f84	\\xc30d04070302d071c8528bb4595a74d2390153d1141a9b5021a9ace94f89fa2bcd593fa8a5b2b79350ae26e908ba15c8cf748f338035e2e891d4dd89874f7579a12291e1d830c86330d6	\\xc30d040703028f9c07931f1067e166d23701f9dcdfbfc2b4f4d06218081d5a08122c30aea3c87c914f2b75f2c2337000d25009b9f10fd0c4e4f4c8dee8a9fe591fc165d27c9f57e5	\\xc30d040703021fa3904ffc7702eb7cd23701c9b5e5e9e4b46a73d54d1b805300639b989ee8ff42d8d2152d77c2c699bd86aec908744bb8d124249dd3158f66e07bfe4e71e9812393	\\xc30d04070302ab3284f618e354d069d237013d579a89afc797cb4a77fa45c6a08cc27ce8a83c223d30053ed8597dabf07b17e55b21766f4e696c47cfa9c2dfd5d1bd79f17d6e459a	\N	0.0000	0.0000	2026-03-09 20:20:12.380812+00	2026-03-09 20:20:12.380812+00	2	\N
46	8	EMP0046	Nour Leroy	Professeur Anglais Elem	TEACHING	ACTIVE	2023-03-01	MONTHLY	f	f	t	1.0000	\\xc30d040703023d14b75282ac5e4871d23b010ba147fae54d1061495bcb90f74f1880307ff99c448ff4496e9922fa8e61c6b7b80a294c0022de319d9b92053b1a6cd35b20b17ccb57452754b7	\\xc30d04070302099152545717d67878d23a01c152dc6ba69cca755a83f8ee59e76c70e5e43a4e1e77ff4e52838b7bd0a5512d09820bd0277fa30b9549314aa24ecdd99209e100c16db2a5fb	\\xc30d0407030239a345f91604fc2b6fd239017edd9cc462803f94883945d3860ce64acfac70cb14ec3c097f5ec3cc530ead5c2bcc7bb73d7c5a6d10b2896aad095e22a9df143f3b1d103f	\\xc30d0407030269768cde54ec077e71d23701821119c60488e8481f7c6fdd374617f9fbc9b695436fd7cf3513fc05e864c0de94d08583e91ac270838297a40ca040f4f0566113daa7	\\xc30d040703023c2c758d435a041f6dd23701067f0a897d2442432e7b829ad5257bd2ae13b71a42a148a448361f0b557361967e15f9b9bf44cf7eab43f464b7ee17ee6f3e043b4fe7	\\xc30d0407030263890f04a81e016274d2370194b22605acf4e22e54627d0da2fa1f473b3af2770ebdb829b6c6c9c07c0e4ba08b41d30f01fb08cdc0683e01a811e454fe45273b4934	\N	0.0000	0.0000	2026-03-09 20:20:12.381542+00	2026-03-09 20:20:12.381542+00	2	\N
47	8	EMP0047	Khalid Al-Shehri	Professeur Anglais Elem	TEACHING	ACTIVE	2024-04-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302abc683ee870869d17dd23b011695be78db4f5f88115c9094a434a418ba128b5108e6b1d99c96d30f92ce3981819a89a79049e92c672db1354fbd193f33cc9c1f8af7576e1f22	\\xc30d04070302de817367c88f781367d23a0136f112cb645ddfb34e04a05bf28006ad1a543dc5381c1bb98e630cb415bd0a53569ef5d6d2ae23eaa4df65cb14f97d3d3b5b5e84783941de22	\\xc30d04070302e71259e6e3a08a3464d23901078295f541fa3ff4cab406e49175cb7b42969c72248d5be75b82f5e98773e80531a27bfdf23da251e11787200da21eda892375182bed408f	\\xc30d040703028635b31795beedc36bd23701f030b0af75e9cc77449a55b89b7bc8ca715e387921a9c733f5c4825dd3b659785bee7b2d7ba4ad4a924c2dd015db7965f73a72c692e3	\\xc30d04070302a4acdd4992d421db70d23701a92c5d9622b988dc4733fd3003089d7d1e264f67c6ac4ca60a9ad6cf3bd41211a336bd3385bdb4c5c88207e7fd8ee973af1e657b011d	\\xc30d04070302c13ca882bc4d938275d2370173805d49285dc8e0f269104b1c18c3762d46d2e5033f77443e7909cfa2a93df9bc27608897f973403a152e23cd8c83c4a2e34aba5fab	\N	0.0000	0.0000	2026-03-09 20:20:12.382265+00	2026-03-09 20:20:12.382265+00	2	\N
48	8	EMP0048	Layla David	Professeur Francais College	TEACHING	ACTIVE	2018-05-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302673fd3ec2960fe9d6dd23b01822251fe435d755f4a866689ff0e4c60d1e935f884148f8b5b8f14fa6b3309837fd5af220bf5c5510586d0cf921f312b4860ff7db7f409325c07	\\xc30d0407030211d584beb8cbfbc574d23a0188a148c835dcc16db9e1e8122fff228a697873fea988f63dd94a1b9187b2a33f6c2d54c5712e08684d77dab7f0fe11dbd43b3b86973b96f1e4	\\xc30d04070302e4a3732a6fc6e03562d23901e6b9502ba54f8b64eec75bdfc48e889ffe3963cc491dd8caad38317c15987e97c8409c9624b940ed73ba6d1a143ef108a12ad8cdc5e402fa	\\xc30d04070302f5bc3f0ec68246587ad2370141d9a63c1712daeb6d741c80eef0ceead6d7d4a0710e345fc7033274159be7bcc7007ffa0423e45d82da1581d0f6e5eb767c69ff98a4	\\xc30d04070302c31e378d3573b77a7cd23a012265cf5e8d8408b4d1732a1dd3b9cb5d6409f7f6578953e4ed52a2f8bab9b792b81e011bf709b8c0425170e27fedfcaa2bd5d67098b9fa663f	\\xc30d04070302021c52ac8ddea1f274d237011592b4aa874be6ea3ab89dff4e8c0439edee3d7d3cb4945747866078996077ec00ffc7cedb89faa09f162ffce36bf610837d1a188639	\N	0.0000	0.0000	2026-03-09 20:20:12.382967+00	2026-03-09 20:20:12.382967+00	2	\N
49	8	EMP0049	Omar Al-Malki	Professeur Francais College	TEACHING	ACTIVE	2019-06-01	MONTHLY	f	f	t	1.0000	\\xc30d040703020d5361d3498470b175d23b01e461b91f72d101826675bf209d95e688e9efcfba22063731efb661fc76187988184b2a848a74b7edc102a7f38917e868b7994dae2d44e250c337	\\xc30d040703024649604d6b80df686ed23a010050a795ae726f73130c155ba3f4e0d0c3201a12813a0e3b2c34a4bbd2c956b3a8edfbba13bec3e154e6353076f2783ded807f2856b9057f07	\\xc30d04070302534f3366015e69d364d2390159c4626799e19c3d1fcd77b0f1f9817df176594cc703d996458d115a2aae9dfaee2be1299f1b72ce57e9ec9e8fa2f7a387babf24f27d7c46	\\xc30d040703029cc3c07f9ce529636cd2370176dddce67aebdabbf7ff27b9247f198475d82876df6fd73311de06d694f380ee9430a1d81cbc21ab9bdb402ac99dc1adebeb3db83299	\\xc30d04070302cb52ff7faaee248c71d23a014b27ef7eeb80aa12221a422d72224f6e27d7a0b1449bd5a2f6d07d48ac8be5474a7212cd50c28fbd054a4ba8274a6ade56363796025f80b657	\\xc30d040703023373ade3a173002a67d23701bd04ed39a1eeff5742075fe30d74b2f09af7fa261033566c98d5737046efe7c9ff1ad4580c45b25ade8442a791782a2f50278decf864	\N	0.0000	0.0000	2026-03-09 20:20:12.383719+00	2026-03-09 20:20:12.383719+00	2	\N
50	8	EMP0050	Sarah Simon	Professeur Francais College	TEACHING	ACTIVE	2020-07-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302ee2fbf4da799381861d23b01a0db5bb579294f12f47b9254ff1cab84eaa0d08a2463542eab04de2f9402e40b46068e9137617f8dad6ca189dc3b1009698d587fedc9c64dea7f	\\xc30d04070302be30cb8ce3d104b870d23a015d613157cd0a5476f79d6847204f620ea1b08a3cadd997a28aba3634621df48962073b18a507e55e839862267dbaaa96d0a49b156a9e47a2e0	\\xc30d04070302d554c5420613c51669d23901c47888ab4c3e0eed5a8f114d66b2bd0c85eb20cec172182bc3a2e3a7ca1e55ed8976400e1d1d79c4d893dfe45f628390e47b35d308e57dae	\\xc30d040703029a3d9bc4469d288476d2370130898f7bc5cb6342d4ad25e8ab0acbf3393427c6b1b52b67d17554ac6853c8bb2f9c26ad757cae52bae40918958af7367c27479dced5	\\xc30d0407030207837ae735d68c857cd23701418c14d02a9378259dea6b1d9bae1ab55ca2ffc347fad0258ce4f004066ac55b7a2bfd133d5795868d9e51e32fc7580098eb9bc49363	\\xc30d04070302c0e9bf5a7c64a5c870d2370158f8bc4e1c821ea1776933a55357d7fb7fbe2fea7f939d130a3dfea6f4ace4b5fef09cd673c5e0901be57f8dca65ec79a09f80c80794	\N	0.0000	0.0000	2026-03-09 20:20:12.384383+00	2026-03-09 20:20:12.384383+00	2	\N
51	8	EMP0051	Youssef Boulanger	Professeur Francais College	TEACHING	ACTIVE	2021-08-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302281db2e69a7b027271d23b01f2adeba64b31be5cb826e2f32823dee5ccdf998bf9dce164e50604d6554b1319c1e6bb3447f0662be57268eb390b809038d89249e9d8e6fdefeb	\\xc30d040703023bfed4a1671a5a436dd23a01938d8570b132a33d657f02c3402875d6ce1cb244d946f9264c3f2d72f6e0b4614f3282e7be8f5d6486c75831a54078da6dab6543050f4c7907	\\xc30d04070302a1027908b03468717cd23901618fd98701115cf801e9bc9c87aee6084e646ab7fbf5e6262442707317748feca66e7a27f45cfb41b657257bc633dd7c48d5fe8d3bf12b30	\\xc30d0407030245c4428fdc485f0077d2370184fa81de35912a66962d11e78e636ca9d231f97fdb15e6c3966c18572830b8c6fa70f8bfb1a60cdfc8cfbac6c9bcd3ac61ae80279854	\\xc30d04070302c853768d5a0ef18570d237012a91592493311bb0035d194059620eb31150b492c14a132882db01feb396f6feacc03a971b9b37528e696ab78ef6c79f7a01b928d6f8	\\xc30d04070302378cfa1ee5b280c171d2370191211a7614d78156c216c62d53cc9209b300c87e3439b785574683241ae1754308656ce0534db58025235b8ce6a1f7b884f767ab8bda	\N	0.0000	0.0000	2026-03-09 20:20:12.385102+00	2026-03-09 20:20:12.385102+00	2	\N
52	8	EMP0052	Amina Chevalier	Professeur Francais College	TEACHING	ACTIVE	2022-09-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302a94ac68928d1e1c47ed23b01f4930320f21c21edfef43f33a15356cbc4795b2d7776d12d70244ab494caf751938bc7fb20ee96c604632267192db13fb3fc3372bf8c714decd9	\\xc30d0407030267d7d2cd9a1727a77fd23a01391fafade0bf83423b5e9f79a863cbf28d2cd538f033ab3fd7781c97db9e53af572ba5d91f7f37b0e500bbd52ff0b847c0976d7c911c646e98	\\xc30d0407030287b8f0ec4a1ec5dc60d239012ed33adcdd05c4d2ba6a7106340836eb40e3c0d3e615b8aaa7e2d3d491576c291fea3d0ac2983e9d6cbae1d1704908cf6e8c2a83ae1ebfd9	\\xc30d040703021aedafd4cd79024562d2370195ee99ebb5fa99bcbbe57c11f66e27b5511ed40ca33524d658dbd3f7f27ce9075e48ba2f9940b7e48ca79cedb1f26cfe13ef1e0353e0	\\xc30d040703021d20690278b8505f79d237011370f5526d5ef14d2c982b189d6827cbccf4c1edad1949901202da946a39ab69d5a67774362aeb538022aa68868c115810ead3d598ac	\\xc30d04070302c683c4034b18cd617dd237013f5bb74c4d9265cf58149e14df915c030f109f6f5bd9b22e40916335f34c53a8249f648c0fbd725c3f5c7470313ac15cadfbb425213d	\N	0.0000	0.0000	2026-03-09 20:20:12.385871+00	2026-03-09 20:20:12.385871+00	2	\N
53	8	EMP0053	Hassan Al-Ghamdi	Professeur Maths College	TEACHING	ACTIVE	2023-01-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302280e0a3a6d6d6ab974d23b011b6f55f532fb6c23f783c18cb22d16b39ecc09b8e42048d11680f346dd19a0c31f2c0464cf17563adda94981af02e4c1e698d7801a287e7fe320	\\xc30d040703028dfe6bca9c7fc19262d23a016a3ea0de8934277bbfbf9cca89f4d4bf61544898b8de3e69f5c114beaeb2c6594b58e5e2cae477970e24e751896d2124035f03ba709af77177	\\xc30d04070302c1c76d54f0c4bd5973d239012e520dbf6dc395849cf704bc1b381043d64783b7a8811962643bbde7470dd23cd9408d13798b1801e64b37f835d152c21dec8580569d54cf	\\xc30d040703023487093d03c613457ad23701a75f9e5789942a9e8f91e6971c385d848c5119e6cbc7838d9ac57b1ae44319926598725b462a2ee11850f74d4fb784115bc493caa33a	\\xc30d0407030275574dd34a3fd8646ad237017dcbfa61c3cd1ce618185af3730011c15d6adde12078cd3a87e1eaba2bbaac29a593d8a120225f824c3f5c183fdced3bdc8e514da595	\\xc30d04070302bce59931003213277fd2370149c468bc9824864fe05fa26a297539f095e8213988a9b1f2029aa731aed3a886da43241563f63034b101ba5c9de4d9ddc9d1b9e3ee77	\N	0.0000	0.0000	2026-03-09 20:20:12.386673+00	2026-03-09 20:20:12.386673+00	2	\N
54	8	EMP0054	Claire Fournier	Professeur Maths College	TEACHING	ACTIVE	2024-02-01	MONTHLY	f	f	t	1.0000	\\xc30d040703023873d42ac4cb6c7864d23b010990039665be988ffdc40db11a851b93b25c35df2e8fcc03e74493464f8175c454b24bab3608eaa4c661ec46d1272c50e9c8156aa4d5d4f4e121	\\xc30d04070302d2431b9c2461d3c669d23a019d71564f9e3943bb5e4d6c5fd50eadfdd57205963d246f3651b55f25b3de8a39b636fbd1dcd297f10130d6ec1481528f9855f37bbb22960e51	\\xc30d040703020ac20cc020ec0b6475d2390193e3509a3c5220ffd94f6ccdbc8ce89b51a5bb0a33332a1ad6a37dd424cc6ef5908d4bbc5ab2d5799da802c2e7982c26eb2a4cf321402370	\\xc30d04070302ae602c825fa42ee667d23701cec7f396f80302ca85b466ba5c101c03b5f2e4872f599d9c60a45869d9d1711264278d92a4f94f67ca7719fa22964abc0db830cbd17c	\\xc30d040703021f4ae262b418079b74d237015833f3dd60bcb755c013f55865fd6f1819a03bdf7db36341f237ecfe8d50ea636218d5c2f58d0b46301832fd26d0761fddff261bc911	\\xc30d040703021f33776f141f3db375d237017bea0096ea40908169cad890dc5906e61c2929ad10d3c90e2271d5df505b30ec16bcad47af7534d5f82cb752bbfe3f78ef280e3f5363	\N	0.0000	0.0000	2026-03-09 20:20:12.387458+00	2026-03-09 20:20:12.387458+00	2	\N
55	8	EMP0055	Thomas Al-Zahrani	Professeur Maths College	TEACHING	ACTIVE	2018-03-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302008c5b168ceb0c407bd23b019fa992f058601607da2643a1b36460adaddc47016e8674fd69807cac5007ba290db59c5c01ddb57f8cabe5c907f74c6641549eb50c583c27c682	\\xc30d04070302ac26ee091a077c0c61d23a019e1837193117a916ae070a199ae2b70f84e26fe18d158f542955b6dc3dad83e7e1438b1a70b03485059262fe7fcb92079f050fbd5ef063c664	\\xc30d04070302a498f24bbb841c1b68d23901a531d62f6927353589de08f708b4f6516ffe1f23b0dd8d3df915fa4d9133c4103454255f55f4928e6ad993e1809883f345d8a6ddee9fe300	\\xc30d040703020f1bfb2151c2233d78d237015d9646cb8832c996b7e4a2638aa48c1e523d54bf7341064987820e4422b1bd26cb295bce84b5bbe95f9832878bc0c4ab2896af1ef2ea	\\xc30d04070302ea104cf088aa319a6ed237015c7bb524001caf31aa5fd88c40c45ed487b9d3f3c4dfb4a0151a2adfa14985796d8c5ee23b25d5f7c0030a27b62bf58842614919605a	\\xc30d0407030266344f127294171971d237019361ed5ce7e0ba200a85071c032429e58745dec1bac7fb2933c91dd25839140a652451681fb5a308fbd1e81353636ecdcc1d21e99145	\N	0.0000	0.0000	2026-03-09 20:20:12.388144+00	2026-03-09 20:20:12.388144+00	2	\N
56	8	EMP0056	Leila Girard	Professeur Maths College	TEACHING	ACTIVE	2019-04-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302a06f22d25018681170d23b018664a51843d03c09e3d81a84e187c849a8894bb383a55582b8387894633acadf9e2ea8be8adc798d2a5ea64b6e48bf890202f95d834c65f3991e	\\xc30d0407030211a8e64175cd00a563d23a01b11dc46f428062241182f37cf5fd7f675a375fa9c936375eeb430569e4a63059eebe40224f2c43f0be41cfe4182bd09e33fa345b4b52553610	\\xc30d04070302d7e5b2646c55f29d63d23901747ba717e5317ede2c3a6adae6136fc824c21614b2833fd5a2f3095af67cf355b09149ecbaa698e0711a4c26a6b41105664b425173f96600	\\xc30d04070302eb40e4b0ec36e77262d23701a3c0fc07f30476ffe8301e60652022a7859e4e083ff3dcaf7ec0c8b46a351c4a1db5c9b1df787feb5c4ba0a9c40f6ace884f5db11ccd	\\xc30d04070302420051a6dc52097b69d23701c0e3966e25b986b0a862a97e5603dc2e33b1588df8eccb62e5ac3dd88eb963cf8bca6b433177f936e959ded1f05ac55dd59046b67e79	\\xc30d04070302d9025deae179f30078d23701fc830cc628bf66fa3223f38898001a026e74d580610658be8b00d9758570d915c3f19f9e77d2b9b28b81f4a9b80a677ca5772db25b4f	\N	0.0000	0.0000	2026-03-09 20:20:12.388865+00	2026-03-09 20:20:12.388865+00	2	\N
57	8	EMP0057	Mohamed Al-Otaibi	Professeur Maths College	TEACHING	ACTIVE	2020-05-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302e0ee51a4be2ea1d26fd23b01668d09cdd33be9dae9f12b2b056f576a5d774a79b385e1d4cff8a6a550b37afbb78f004777ddcbf6a9d1813925b522445dba7428cd321eb722eb	\\xc30d04070302b417f848279663c47fd23a019ea51acc51cc456bac1d5aa986bf9b8cadd204e6c90d44b46453482b3d69233e2817b20afe2e1494eb12aee2237df3bef8a52c2b71375092a1	\\xc30d04070302f71e5706788dc1576fd23901efbb503a370612fb89126c484e2ce79f1418c84d010d6476704a5b6dd71a4125f795c5bf1fe7a8ab6ba24f32ac35d751791d66edd2078f98	\\xc30d04070302633acda5c3739c6468d23701426a2b585cc80525ec72a5a3c73f1b759f78386ea3dd503e8880444293c9c3f99977a48d1a94d04a3ef9155f51bc8ef5e24e6f3a9d2b	\\xc30d040703020e5be53cfa5598746fd23701b8fc594b15d57cc9c24d1bce6aa56041740c9d3f98622681f75fa526b593e7fd79c67665fc91782de504d50a1c3da8cc419fb71b3315	\\xc30d04070302102d9c25c29bc21073d237018ee1fc6050cecf165afb899eb8b7097c90264e742a06e5b0cba4728eacae7835a34fc4dd3e82606af87fe1343352db8ca56670ee3cec	\N	0.0000	0.0000	2026-03-09 20:20:12.38964+00	2026-03-09 20:20:12.38964+00	2	\N
58	8	EMP0058	Julie Andre	Professeur HG College	TEACHING	ACTIVE	2021-06-01	MONTHLY	f	f	t	1.0000	\\xc30d0407030240ae659448692ea96dd23b01f873fb9f2817a1a38018300715bd01491053b56d96124565ed355117627f5b42ed9e292d28153fa8b0587203ab0cce2811ea1f8757513c035262	\\xc30d04070302909993c75e65483374d23a01ec31a28116d8144e41c91d53fd3b03757d015bdb75d8b5a704245b12639415bc72e0273b534ee29a96c599f6348e6990e8744e5e04922aa392	\\xc30d0407030219820bbfe086ec027bd239010f51b0c2f0636e9603a047e53ad07259307c1bec7455dd1b6d85e3068dc5c3b734924f9dfcad7b0c0c68a82c2e0a345eef73cb59476d19d7	\\xc30d0407030227c5ad8acff848796dd23701f0bf83822cae470179b106f38555ab680990ff6d12fb334be3b360068d1ddfe21bf201bd46616403f24044c6c0bfa3d9267d1c7920fc	\\xc30d040703023080e8526e41b4ea6cd2370163be56d809f5c00f3d8a9b6a474f815de360e9402185c284cd62d4b7dc5d828b006428bd07279a7d90efc157e529e60b61d1a1182f9f	\\xc30d0407030251f322485a8ce7e064d23701d0ea1b61340c4a3c4bc40be2c1a20d48a8ce537a6b65eb32af79dbfb490f46a53f0b4e7354c827c239620f672496aa21fdf4fceab165	\N	0.0000	0.0000	2026-03-09 20:20:12.390351+00	2026-03-09 20:20:12.390351+00	2	\N
59	8	EMP0059	Ali Al-Tamimi	Professeur HG College	TEACHING	ACTIVE	2022-07-01	MONTHLY	f	f	t	1.0000	\\xc30d040703025a843e1b2fc42fe27bd23b01514dce53b4967fce5da4612d96d8c6d97b5355e3400179f43e72960593b3f9786e9457e12cd15467d37589bc2f423b9086445bbca0a248ac7827	\\xc30d0407030230fd5db4ac7506b273d23a01d5340378acd90f19a5d0e1a52e13cc02a8a929a951b2660c646617021dfb09d91a92bb9641cb6f5efeb92f0d6ab556952c7a74e545541ff380	\\xc30d04070302198b9a39abd798d97fd23901d91ef01d2b296e8150633458eaed7a47a624c7d68f2c719278ede6f4b37d1baf05e982ff31e0366072391733934670c34df55bef19818ed2	\\xc30d040703020f45319d295f6e3875d23701f0b154da87fd178da3a6bea54199555bb33a7d9f146091da63b1ae6b2da8aad58e9ecdf8b8613a79a9cdcc811ec8634b282b77ad3df2	\\xc30d0407030277915ff0f446b48470d23701632b357dc055c7d743bbd0e630a01cbff9cb92ebb73f4346d971e9059f220ce8420db7f795af35c22dc942f5bb4eae51c130212f0fcc	\\xc30d04070302ea3a703c430eb86f7bd23701b5ac67ec252f00b5af3bee7b057366a67b762a5ef742fb7165012f32da2f755e69f3ba7c38fecdf53991472e069712f0be3512eedbc0	\N	0.0000	0.0000	2026-03-09 20:20:12.391077+00	2026-03-09 20:20:12.391077+00	2	\N
60	8	EMP0060	Rania Dupont	Professeur HG College	TEACHING	ACTIVE	2023-08-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302a909232ef262944870d23b01009ef566bb8a5df1b20889c6b14439bf4fc195d4026640c80d925dec084199b6a9b3c7a0c5cbf0b5199fecad180b19c8314c6ac6eef4785602bd	\\xc30d04070302cb9829e34d49612561d23a01dc87a99845eb419a1326372f2a060624b3333e154c1d1debc4cea0c29eb0018f78b500b619084a0c51abfe91ba97110154bceb91eb61bdc981	\\xc30d04070302ea0d3c7bf23e6a1972d239012bc1a704f9d3a2b38cc2e15db6ae6f644843a029b49fb5ef78c526faf0451e712ec72436d432b616593404b644a177bf2b0ea4e7c67a2cce	\\xc30d04070302d0473e1c69d6c76d73d23701fc3d268ead5eec320ad1f3e48ad979ea295fd1be3be8824cdb1f849a19ba68f10168898e185202b3b444b6d4c978aa49e3ac74d4d797	\\xc30d040703023b0ab173e0d8bc387bd23701f0c939886f47fb996e3a32c5b8516cfdca07a27c3b272f75a2fcb1553ed884bccd291c3888b59b11ccbc3aa95654358bdf52c0be8b48	\\xc30d04070302b73fe23ccbb6324d63d237011adc634fbfb737342da5c9be5dd32a56455ea469dffcf4f2e170fbbfaf8ad38b78fffefb6753b8e47ba5d5a46f489973bc9b39346e27	\N	0.0000	0.0000	2026-03-09 20:20:12.39198+00	2026-03-09 20:20:12.39198+00	2	\N
61	8	EMP0061	Karim Martin	Professeur SVT	TEACHING	ACTIVE	2024-09-01	MONTHLY	f	f	t	1.0000	\\xc30d0407030205b2654cb4a6a9b274d23b01d6097e164dd30db4ee2b43e3cf12cc67427124314d5bea89b47c0f2815b55d7e076e7064abf85c26a6401be3505df50b3cf340c8c81d094ddb21	\\xc30d04070302323bdb36c0e5c5287bd23a0125d6786d4dc82789ec47ecaa1c3073ebe544889488b16f4f1c6add5f4d986192a1b85403d8b8cf609663e2e3822ea23d3a6c08e01306625767	\\xc30d0407030218976fa3e5df718c6cd239014a3f8afbb1239f1a9188300f5c7b0b31ab3f16f716dbc5091a263dd1c2d0b6ab0e79304312f3f3c59895526981cd6e75a9cb85b866af3234	\\xc30d04070302cabd2a67549c7e876dd2370138e24d0b3f70607ffaa24a39a85af68b1f02575380a0c5cba02b84e6ed4a0a6971cda77d740c67bee36fa1033fe9aae23652e4f634ef	\\xc30d04070302c58e8b7a8d99874f66d23701b27ae8b7c34301d493ef10070cc58bba26cfa105a7ee13600a8c3880893c1bf65bc9e232e295c29cb1100119771c0d34ab83f81db24c	\\xc30d04070302ed54b9e41918e2e27fd23701fb8218a002ca78a91244e0939886b00d4864969913623450096affdb691d49498ed9f6ab15639f948a530412ca496e31b27a096b1e63	\N	0.0000	0.0000	2026-03-09 20:20:12.392673+00	2026-03-09 20:20:12.392673+00	2	\N
62	8	EMP0062	Isabelle Al-Rashid	Professeur SVT	TEACHING	ACTIVE	2018-01-01	MONTHLY	f	f	t	1.0000	\\xc30d040703026a249e0f0b230a6a74d23b01ee6cdbdf33bff09674259767ad213cd147598e1b99386f5ce1b8b557da73ef376266064d4d9ef275e85ad814fd91729cc7088277cf79f33dcfb8	\\xc30d04070302d6248050d4eb506574d23a019318f7932b635b504602bf7c27293597cd8462d71fdbcae8586ae707711b956fa3ee1a98ee7855260695912c34e302c653452acfe4e56d4487	\\xc30d040703023dd2bad241c1cb3a70d239017acfb218cfd465a88cc815e0d641a668c6cebe7e7056836f02faa38d60179c1cb386e8fe698ba8adf1d5e7c820ccaa0345bc065cca69b2dc	\\xc30d04070302cdb532c2fac9633f7cd23701a655121408475461af10ae4316e5e7082de85e9e845befc9f4ea536b4b01c6aa996adbae52d6055cf4014554aae71705d0d4683f92c0	\\xc30d0407030246728ae9c61e8dda70d237012f256866d8074bed83fcfeb4ab1be3da1cbea5e9a13435b4015bae1205fd16e513b6b56f341b8d641aa2362b17e81d2fc298f18670d8	\\xc30d040703029eb7ac679575025462d23701991d102343fb699b8e0656be0344e2aa225875fa3f218b40b4a3a2e1d82282fff8d180890ee11d10ac0b212ed58225ca28a8276ea044	\N	0.0000	0.0000	2026-03-09 20:20:12.393468+00	2026-03-09 20:20:12.393468+00	2	\N
63	8	EMP0063	Samir Benali	Professeur Physique-Chimie	TEACHING	ACTIVE	2019-02-01	MONTHLY	f	f	t	1.0000	\\xc30d0407030251cf78a66763e11c6bd23b01d3e825c708b098e3a7f48ea7b7db3da2746e496627ac778a6878cd7b1e422576195f5f254d11d61d66553de522dbe1712904cdad781f7168f458	\\xc30d0407030204d637796afb4bca65d23a010b982d07cf4aa830d6bddec983aaf5c0dc28267ff8b46fdc2a9028416c02f2c93de988feda73a5c052c659b6e859ed1186b9c434e779d62426	\\xc30d04070302623610f1c00beaff6ad23901706d7569e95325570ebfd5888187f979756cf59089e49edff9cc36979e07b249f2649d0c0fad20e96c0c42eb0efb0c5cf7caa57286b1f7c1	\\xc30d04070302c4df2c4303f692e562d23701cc222815ef318d9b33503cbb03ebba859ea35b088c88510aad0383ca5ed72b749c07b567fb292ae7e8950e252622da984ca31d4e8160	\\xc30d040703028aac287903fb4f586dd237019fc6382fb9a6da207483f183b4fc6ce892c9d241b9a65f2437cee583c886ba6d28930b1b4d7c3854eca411ea9a14604e97c1e23be13b	\\xc30d040703027b46a5985a58907d75d23701b1db65a9282f4e420aac868b24cc1a292f8ca3f7c451d35e61dfb8554520395ee9a21aa8dfd95cfc80f7ae8bae80b8ab66198c0d2982	\N	0.0000	0.0000	2026-03-09 20:20:12.394205+00	2026-03-09 20:20:12.394205+00	2	\N
64	8	EMP0064	Nadine Laurent	Professeur Physique-Chimie	TEACHING	ACTIVE	2020-03-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302db39679a0fe1cde967d23b01f4e4a8fee54a87a0687427ef8ed55f9dc33a13161f5b0bc35edc0acf0c9d01eca499debce328ffdf30110867abc905d20e18f7e9bb6eba52b7d5	\\xc30d040703022f5af28686495fb864d23a01fa77492138acb88b4e3ce452c978bb0673352f06d4ca19a9634950def7c47a8265244c38587f2d865096a95c4747bfb654a9ce3f2b204c875d	\\xc30d04070302070182da8de1eed076d2390143f5f262e280a3cab9bfaa18fb447f8bcf17ef2b71d0e92abdcd54995fc75e877de55fe9a20e503916cc25f62cc39db516e2c579a8dd5287	\\xc30d040703021de23934091947316dd237010cd58fbeea145f1276ea2c92dcc1ab51964c37f9f3349b0aa534ec33f1ac4dd40a24c472f2b48dcd4e753cb8f72922c2cb723d5c5c17	\\xc30d0407030275b6c9ebe7d63d8d69d237016e1e755b6675a3b900799626e8c9f0f434619a7390c5fb735d8554b0949d2c0d0c9f26ac9dc8ada1324a1e1c19bbf59a05214f78d815	\\xc30d04070302748b4637390e487c62d237015e8ba12210c874c81c92720510d5ef8dfcd22ce58b15b821d915ab65cfbb942b10a2c6265b21da2db068d08fbd3f01315d9d905ae682	\N	0.0000	0.0000	2026-03-09 20:20:12.394859+00	2026-03-09 20:20:12.394859+00	2	\N
65	8	EMP0065	Rachid Al-Saud	Professeur Technologie	TEACHING	ACTIVE	2021-04-01	MONTHLY	f	f	t	1.0000	\\xc30d0407030231c906edae1b5d3376d23b017bc884bab403965960f7f466e42e31743e60c2cae9a1771f4b093b3041e2899992ae69ee54642745a8c4d52a0eb1c4a01f5a7a98566131adeee1	\\xc30d0407030291971461ade6d8d977d23a01444845eafd55402d04cacefd4b5a1f4bf08c6f780a2c336a08a491035494c453bd7535b15cb6bc66b073800e53d0956aaa6047af9f4f1c961d	\\xc30d04070302d5b7278ba3e89a1d6bd239013acde9511ee5211ffe941f17bddf5e1605dac209b18828421f866e48cf5ed6d15537a67115daf8d718d19908d4545e74f72ac0d0ed030f86	\\xc30d040703024ae7aa707a1b08de64d237011b6c61b292b53cf9fa2b5f156cc6a38cdcaf81e11d89682dc1e485d1a3cdd52cd0283360ab1e725f26cb79fd7ab9dd56f7308a47467b	\\xc30d040703026f789fd1562081c07dd237012a3e634aedbd36012b9f56b761a5dde4d67bab02046b25f4f4c2d2e69a5986cd67d7416ba5f22128384e32b38dcfa04680921e8397b6	\\xc30d04070302efa83e6d421011b17ad237012ce4e3838f93bdf619018d20aa76d76e2d0745bb459e571df4f96a0680bcb90c5e563d24761628f1e26c06adad9828a58168302b2bce	\N	0.0000	0.0000	2026-03-09 20:20:12.395477+00	2026-03-09 20:20:12.395477+00	2	\N
66	8	EMP0066	Camille Al-Harbi	Professeur Arts Plastiques	TEACHING	ACTIVE	2022-05-01	MONTHLY	f	f	t	1.0000	\\xc30d040703022a650252790663b778d23b01ae3376a19048a19a25399c19a2a0ee113a93b5bf96a021846c6d02707325b9944702a2d6115e7dba7d347553f589f565e0fa62d7dbd2561c5bca	\\xc30d04070302b5958a2cfe6bed3172d23a01f7dfcfa1a6925bc812c5a9775f5e79c74fc036c88b7ba29f9985e1dd999b58b65f0a38ba19ae58816640dc5e16441967553393b5f298e70a25	\\xc30d0407030203b542caa5c8fab36fd23901a8d370723bda308bc470595ccb8f8198e45c7605b00a6b476fb720e55a1da0acc5324c7d4049397a2557cfbce4538e49f3e2b3ddcd7f622b	\\xc30d040703026886b31503f7248a76d237017f6761e1ad29b8b1472cde0d1f341255f935f24aca5c9014f3c3633eee8acfac2a85be85285ab33e8a34d2141469d6e0b714894f006f	\\xc30d040703027e0f1d9daa1c742865d23701dcbe1e55717b886345fb042bb1158266b8263499d344c6ca85d66b4d4ce05d52ebc21fb81220e4a3e11fd4d7aaa13566fe6bc86c38ba	\\xc30d040703024ed0e55ab17ae30574d23701eb2da6b44fbabbe9e9b9145e7a4225bbbd4599ea7cee81900657008a96b2091a434753135f8e1a26e0b9429b5e423eadf8c1e81e8693	\N	0.0000	0.0000	2026-03-09 20:20:12.396707+00	2026-03-09 20:20:12.396707+00	2	\N
67	8	EMP0067	Mehdi Moreau	Professeur Musique	TEACHING	ACTIVE	2023-06-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302a9fdef6e9f57a4f46ed23b015764f8403c7f667110c761372d029655ed37327e9e8f14b9adc706a16e36e1f0d33e3282ec4ac0c7e1d20a64d62ad5c3658696f4cc2d1855bf4e	\\xc30d040703020c4bdb7635cbae5275d23a017052416aac24d275c7704936842d2aa11ebbf9718c60ef45bf7408567b892565425662e2924780a8d14e0ab1c329305f750a893987d6593582	\\xc30d040703021b78fe6035e7b4a86ad23901df783925206905e5b94f318d275afa7a6db5c96be06ff9a960e2040b388096c039bed6f77554f09dc08899a03d5c3e2673fa3cf048740975	\\xc30d0407030208fad4a8889be03b6ed23701db967e104fa57e51441147546a88db5ca2ff30e2f284f9b11bd6a15cc07dba7f8551bd66f6b5cf8ac2df46c13a6635d213f690a07c0f	\\xc30d040703026d7629240fe87bc277d237015bd43b88578bcac36a537a0004e083dfc91848bbb92090a781a2035f5503f4669541de48d993b3653663357931d0f466a08d67cff8c2	\\xc30d040703020991f947e1f9d41265d23701b5431bc3cde5c7d6509d8284f78df5f782f01e22b45317760ee6bad0e067fb783721ded56c1ff07040fc0461a4c19b9d2ed26562ef04	\N	0.0000	0.0000	2026-03-09 20:20:12.397654+00	2026-03-09 20:20:12.397654+00	2	\N
68	8	EMP0068	Patricia Khoury	Professeur EPS	TEACHING	ACTIVE	2024-07-01	MONTHLY	f	f	t	1.0000	\\xc30d0407030220f970fecdf43dac7ad23b01d73ba0cb253738f1de3bff696006c2746474bca95b96b1dc38059201d41ab0b88174420580cd5a993dcb13fda2164e13787adcb198f4f3e880e6	\\xc30d040703027628e00ee5a0a65777d23a01369b1ff3e0cd52b32120d502354e5de0238f83a33a4f514575cbd44d4d5dcbe955ca22854fcb98afca773d2437eb987c7963a4363d778934a0	\\xc30d040703028afc7b1e9df358477cd239014772708a19efac2129ebebbcd215a9dd53d4e0330d881de4823b6aadbd4469629bf370b9344c96de8d97ad315fda3f1c50da48523354b3d5	\\xc30d04070302e069ac116b3a6c3079d237014fb39f8956e655d328963c3f47c16c538b94f87ad2774a23195aea974caee711789da822586c191dd7a47b22896a4d5545041b89ffc3	\\xc30d0407030291d0361f7c8c645f61d23701526fb00f10e6babcd413e708bf0bfcb102de032f2a9a8c3274736e80bd861115da73718982b5fed7e9a0678eb97ae54e28f85e55dc4f	\\xc30d04070302909c4a9a05db11cf6ad23701623b62de1043e038028370b62859a730b0274e8d95619c79a64e4c28a583b6d8c3c0efdb07aff70c9afc82831862003ec2beefe9e7fd	\N	0.0000	0.0000	2026-03-09 20:20:12.398364+00	2026-03-09 20:20:12.398364+00	2	\N
69	8	EMP0069	Amine Dubois	Professeur EPS	TEACHING	ACTIVE	2018-08-01	MONTHLY	f	f	t	1.0000	\\xc30d040703029e9091bc26fa40796dd23b013399d1d88abe70db4b842d5c9d2898ba1bd4b638816cc93f3bd34d892125f5a3564af7cb78a69937a039b5ce76d881487acca7fec09884c28017	\\xc30d04070302b98962348a642ac370d23a014977bc97800fa46c59d6d48fe9f88043e3a65ac57c91b73c5dd880309dc131c7c23209dd0360305cfbc37ed73757c8c6f5705f23608bb46ea6	\\xc30d0407030222c3dbae383a560868d23901f71c41e57f56d4776e20a915307ff16c1649631dd90a973c9123a1176817a0ac33fdee6c0a57ee014f40899fce17db6368e93328bf55c7ae	\\xc30d04070302c8caac474813c8d77bd23701fcb1663035d0cd1c5fcb7ef403f7f7b7dc66a2235452e71368a8e357d797bfd9e1f9a9333d7b20fb9013dcb321d3c5f3f681636afd57	\\xc30d0407030260fe8a12ef951ba379d237019d34835c8b8005042844a3fee3e6440ef28be244f42cfba5a22bc9d5adf8b49f9b85c2f15725e0b27fc5e1f80f256cb5f1223a7b7a8f	\\xc30d04070302c216e2ad70a9a99371d23701b511bdcee26e736e55d90ed2c6ebf169df5ce306bb1bfac776ad697b7df29c1f0b7d70d420f44d2df06309e6c8f1752b344ba57e862d	\N	0.0000	0.0000	2026-03-09 20:20:12.399242+00	2026-03-09 20:20:12.399242+00	2	\N
70	8	EMP0070	Maryam Mansouri	Professeur Francais Lycee	TEACHING	ACTIVE	2019-09-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302f437e2deacc87cff77d23b01798c5de349979afc2f1ba5fe05e7eb5375eeff0bfcddfcc09028cf38ce355c45b8ebf4daa3f7e0ef952d60e731b6a7c72fee1166b5667705eccb	\\xc30d040703025b676981bfefa7a36bd23a014c9409890d290eb1e04b7665e50535c599913a082cede135388054e4544f072c84ea4530e84fc883492b2d5bf614a055b89057b50749c29140	\\xc30d0407030280bf514381dee22f60d23901b340c69614a8a65e5a118c8423661eacf6e1f29e780af0e9a673d4c3d7b432b74c69f704f62cd7131febac4ebfef8d343287fe834fdf5c74	\\xc30d040703029d9ad4b0258ee43c66d23a01ec8ba0e31a5b0f809e8e7f56dc214f59c41782a28c8749ea66d453bdeec8861da4d5a14806cecad01ece96a8feb606028275d9e1bbd3a92d8c	\\xc30d040703027d2be2d6ca0ad8de69d23a01edd2fe1af988ceab59dba6bc3c78ba97eb083139f8a986f18e9c67ad23a2bd582c4db1af7af953b5f0ea7ffad8b676b26f5604c25a2008990e	\\xc30d04070302f95d873ef67777fe60d2370184c6d0c4ca3a9168f254d2273898cd06ca2857c5fb33f138650fea2701fa3c42bb51a934ecd130c9e0cd3e6471515c631adfa8824324	\N	0.0000	0.0000	2026-03-09 20:20:12.400025+00	2026-03-09 20:20:12.400025+00	2	\N
71	8	EMP0071	Tariq Petit	Professeur Francais Lycee	TEACHING	ACTIVE	2020-01-01	MONTHLY	f	f	t	1.0000	\\xc30d0407030239bd037022e1f3387cd23b0134de03e00acd5bd42e16c655c6115a9e10acb862739195414d7621f71d4088c00a806854258c3a6db0442b9d517fddaed7d57071c8d224cb02b3	\\xc30d04070302e627e1256e67115672d23a01e329a0b7e57d14ec9d00eefe7bdd8a636626e5a4866f1637f3bee9bd1930f9128d3c50059eb8b271eafdd6420d6c3ffb10ac2d34370b452119	\\xc30d04070302966eccefda687f9d67d239015e96d2b18dc72a312299c6639f2d983e27fcc4e97acc060631c8418a9cf5e96ffcb79e68584ea3a672018b752c24c76aeea4e39b9f6a5192	\\xc30d04070302abcb308d731c4f6b7cd23701e3342eb1c12ecfc848131e0d1b8ccab4bdf07f1da7bd9928b6d4ab72a5739aa1ebe96eeee53e6ec0b1ba9c7a1d3181f07fa1796af5d3	\\xc30d04070302ce279e884be084c374d23a011a3bcd4b35f1e540dfc00559560a4465dd9580762ae0aeec6d3fb84df1b81e957d84acf673415c9bbf94a852bc07376171ac838e508ffb304a	\\xc30d04070302252848e759d00b0770d237016c9c450e7477e896f2b6e4d6a5a117e5bce78be73c043289fe33111a99d3d621cbd424c794486d96590474aa9bed6fe2281071691b2e	\N	0.0000	0.0000	2026-03-09 20:20:12.400775+00	2026-03-09 20:20:12.400775+00	2	\N
72	8	EMP0072	Elise Roux	Professeur Francais Lycee	TEACHING	ACTIVE	2021-02-01	MONTHLY	f	f	t	1.0000	\\xc30d040703020581e2c2ca3cb66e62d23b01c45e2e96ef81d761bc5714acfa5c927885d4a47e761a7593f3fc7c3d76f8e72d3ec79ac9252051e21960544f058e286b8273a01872222169be70	\\xc30d04070302dc459934aaf8ef8a64d23a013ce11b096260094b21020519fb5dc5cbadc9052629f4cc6addc15cac202711243eea420a167ede11b749f051233ad383339d707ecd7ab37841	\\xc30d040703025396ea0b742d0f3a62d23901748ad080d84bbfe3e22f3a971a497bd3ef8cba20e1aa615662422cff9b4cf030b02beded240543b591c23e701b16a518a230e6e3ea6b2239	\\xc30d04070302dea1158c9aeed1126bd2370134724cfc066c83c643b772d8bb9e4729652a4b71cf834fa93ad008d16bbee1322183e8e4e1e01e2c439828d44fa7397ba22c3bd2b292	\\xc30d040703025ff06ee12ee37e6c7ad23a01536c690efa12d67049036c3035f647fa3749aff0b234531b15ac6afa23d776795e8963cf90b558be6d76ba7a0a2dd66dfa623a8b7074878afa	\\xc30d040703021eed6690cd5c60b769d2370129db51db513fb9570e1f501855548d65a42e39cae87e557080f8b3f4f945a7aea3600fc726aa438c2bb493af058855efbbb5d9a43715	\N	0.0000	0.0000	2026-03-09 20:20:12.401546+00	2026-03-09 20:20:12.401546+00	2	\N
73	8	EMP0073	Walid Al-Qahtani	Professeur Maths Lycee	TEACHING	ACTIVE	2022-03-01	MONTHLY	f	f	t	1.0000	\\xc30d040703029dd234e95d374ae36cd23b010355da0152ffde97ead7072a0c11bd08336aeec4f6986363650715d632337b33e7528d6b01db129b3180ab53e122f41bfb09568fd9d868899dc3	\\xc30d04070302abe77d51e77fcb5163d23a01c65733b33930dd81f3713bec3bcfb919ca0bb9df36cc5e5a05e058185958f5749a3a39f3dca287045dd179f341666acefb85c6c7d174f087a0	\\xc30d040703026ee53b183d4ea2f572d23901053259d57a88cf7f8d9a17e93fa20d3eb004d43126e63a8ac46af4f098590d203cb810f5723f68e120fb7953bc4fdf1e9bbd463542803b6e	\\xc30d040703023c1b13cd619f658869d23701c28926d94f7149b881123062d7eb4f0f8d8fc951760d808ab55ead17871c37b4531b7bd91428f101000ccb5d048d59025289dae28436	\\xc30d04070302f43f81b4ccfddcff7cd23a01651ca4c8fbb4a1dac1fad3a9db146ef9f2b34613baada81ffab244037b0a086f6ebafc8ac9ea1162bb784e9af6e5d633ff259a4f891c8778e9	\\xc30d040703026b12b44bff6856e874d2370119ca603f04820e10cad4e6b765008aab6e5e97f2600ca70775e9c09d0db669c31d29f985338a5a7a05f0b1df9dde6afae85bb2fe0da7	\N	0.0000	0.0000	2026-03-09 20:20:12.402185+00	2026-03-09 20:20:12.402185+00	2	\N
74	8	EMP0074	Hana Bernard	Professeur Maths Lycee	TEACHING	ACTIVE	2023-04-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302d2cfcde9ffa8ff1d73d23b0151384b4424bde34268e517749092951450fccb5cf8e55efadfc6ed1d461750f671f0175c5cd9e4212908453cf3c1af6e2d017c400d54d4684a0f	\\xc30d040703024361f9cf973fefeb60d23a01ce76d6fc5b157e36b5ca034595d511ec4957c86842243e59874add2985acf9b12dda530a92f3a03fb349cd57b132adfa67f9f3543a1da8345b	\\xc30d040703021395fe29440f3c1064d239014ce91486fc9ecad61b11710281de447dec0e04ba142d1af664d3694aba102a34d2b2495bf32fdb706ec7f739c8703e67592b57ca7bf6e815	\\xc30d04070302dd9e244c17caff2466d23701329905c6fe882a8ecf574ba62525cb60f2f30f16ac277deaceceaf1978efe5d015dc03d85e06c548c742dc7fc0fa9db7baf1e7fb48fb	\\xc30d04070302ba80751cbbab142d62d23a01519c9df28a20768900dda2d242d84d803ca8a2bf083bf7dde02a9c970245dcc0f456e477f3fc55c330643101510ce239497239b0d3aa0f182f	\\xc30d04070302768ebbcf5473757a6bd2370139655999a33eb686fba4c18a1c7810dff0c82e64c6ccf69a40f868af9e11f761b2df72b665ea188b21f2d4b2d50af6d1f6e913a97932	\N	0.0000	0.0000	2026-03-09 20:20:12.402891+00	2026-03-09 20:20:12.402891+00	2	\N
75	8	EMP0075	Bilal Al-Dosari	Professeur Maths Lycee	TEACHING	ACTIVE	2024-05-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302d7303d7efa9226336cd23b01a7b341c30aab364b72d68d0756afcf08215886f3d30b85fdb1d585b7e8cc618c1b7c8cd07a3f4739a94e9534b206fd5a62b2dec3c2d7a2c1bc03	\\xc30d04070302224cacb59d551c8675d23a0107c9fc805b492935f2508c6f1611f825ea3f7bf502c37f27293263b717f6274bfa2259f37033d2b5ddf0134834a5874cd30c0772e6cb0b2b68	\\xc30d0407030235840bb7276399986ed23901c3a1f1aef9b25c9605414e725c27d0b02dc69567035224e256c5523b928a88876bc53d5727b835d3e1c1e2147abac4a819d68ac45c0808d1	\\xc30d0407030207c29aababd9df4a6dd237010b52d1f4616b9d058caada06c1ce8ae7335a23933bdd0abe8715b67cdcef20744745f454e4e7524aa9273fde00fbdb4b32ba0605feb5	\\xc30d040703020b140ac71e0aa08e67d23a0151413b92f2d2784c3870a568b7978d9b922aef3af51bb32743b6277e96ce4ec57d9ab20c85f68ff94422283bdb61826fee8333f5530ac69b09	\\xc30d04070302822f54f99d20b63d6fd23701a9bf0dc3f3a0fbad2048675552a3b30e4352c726f4bb5e75e343a7bd9ef810dd080c279636f3e98681959ab000ed54bade998931fcd7	\N	0.0000	0.0000	2026-03-09 20:20:12.403481+00	2026-03-09 20:20:12.403481+00	2	\N
76	8	EMP0076	Lina Leroy	Professeur Philosophie	TEACHING	ACTIVE	2018-06-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302c4b475e596ca09177dd23b01411302d97c108265ac8a352fcbd21b2070631156c6b8e69078a55e4f1ecc458ddf7d1d868c1ef8d79c2a249ef4d5ab96de18e682a52b7023198c	\\xc30d04070302d9bae2626748ac8860d23a0110dcfb4e83bbb1fbcc051a709f1b3a10c3b5f78e629423bb2156afa6120e07f31ced8a1f080b08046be1de1c7d615aedbcfaa4edd30d9d8614	\\xc30d04070302d8cb6179fe6640e26fd2390163122440f913d957660641c7f37e53333d2655b0d20478b0f59ea6f5425b0f17ea524826d81859025763763128828fa9d1a84e4b8c3bd179	\\xc30d040703025a10f66ea4d4c8376ad237015caf9910cf74aeeb8ba7a8ceedf5fe4758432d6ac879f9bcdbad5673c355f5e856ffccc2200612e126467a8d84906c69941073ac8fc7	\\xc30d04070302beb12ce5d2ef2e7a77d23701045cb1b023072c86bdd873166c2310fa0f97d99e5fc9ba997fb6ecfe94358492da2786764e98c1e66dd6c00d6c87ca1b26eaf3fb1270	\\xc30d04070302c336323717e0159366d237016b244f7e2c7528e901320c2477fc9af38c0c716c47aa7ff6dfcf852af475a8465f3e35a3842a22efccf48e5b3e1c0d4eae59fdf0666a	\N	0.0000	0.0000	2026-03-09 20:20:12.404163+00	2026-03-09 20:20:12.404163+00	2	\N
77	8	EMP0077	Hamza Al-Shehri	Professeur Philosophie	TEACHING	ACTIVE	2019-07-01	MONTHLY	f	f	t	1.0000	\\xc30d040703029ca6bf01c1b57f197fd23b0155839c5efd4e59604d8413546abde0bfe5cc74db263f316a75c90f57aa20d339f0a4c2ea36acb1ef58d98ecbcd892445a1b76243bd2331416739	\\xc30d0407030239b9ad07fad74d8d76d23a01572379974a7555f26601290ef79e8f5c42ec0e34be21ac6aa14787be293a116dbdb7ffc2ded75e512a09bcce67fa4571df49066ba5819b0efc	\\xc30d0407030249d6975d20b9c5776ad23901a6d21a61c47c2f02de01d7eb3b7a278cca8e2b8c9cf7e59acaa504448aea739dfb6ebba542ff41a0151031881de32f6c533050472c75f51c	\\xc30d04070302121442470ae0861c7ed23701c8223d5afcff2d6a1d8f5a06405ec1e7b5925942bf9194c223efc26d1990a4685ec60a56dc21bd4c4816f424ce6fcbd525ea6fef42bf	\\xc30d040703025573d4a0cad746986fd23701fb70e15f7eb2f59eec8ac2e2fe693130133aaec0297972acb5511b6f1369c1b8677b833589c6beb602a85f3664c0338c0c723714d2d8	\\xc30d040703025c8b4c4ee390844272d23701d5aac56579e51aae7f857fac2404cfef749b6bd454a4e43037438b6177e8deb372d11d5af79ae2c240267c6602c59e1e11ad4ef9805c	\N	0.0000	0.0000	2026-03-09 20:20:12.404907+00	2026-03-09 20:20:12.404907+00	2	\N
78	8	EMP0078	Chloe David	Professeur SES	TEACHING	ACTIVE	2020-08-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302b6196e0891caeb4162d23b0115f90de59eb6bf890ab5ba6ba66c696b954f20de27d72df085d6e90cbb2a32381bdf394a0b54e500a3b97ca24dfb8bd4dc517b9930412ce3f239	\\xc30d04070302e1481bec8b74078f78d23a012dd10e98dfc42a1892e34cf574bc18db56f2f7008b5387ab8f6f4150a765c19f834ea119f9d2c2d6e6b44d71fdd7c9a5f5a48f49d191766892	\\xc30d0407030275d73e973424dba272d23901fd5925086beb7ce7c93a150847d227b5c849d6122f2cc6751110f44e6404ea94f6b7d97de2682ea780b2db69c3c4babd118383218ea3d018	\\xc30d04070302889f588d11e0fc4463d23701c0d6276844eab8cb9f96e6ed3ae00092bb31020845e0693cfe3714fa22f4bf6062786b44da930799d3a1f84486426ab726217dde08ea	\\xc30d04070302c89df3d40ad7659a75d2370108aa18de039a455176808c0be0997c08f188e8248e705b3338f721d00dd11b5d6857471b2529c467236b1b930d2dbbf09d7ed15f74d2	\\xc30d040703021b836330cf96078d6fd23701cffb63c8de7f11aefe594eccbc0a53bfd7e88347b49ddfcc60e9eae03999a6dc67134066fd48e6c95ff45825b5a8f9bf7f2bcd510327	\N	0.0000	0.0000	2026-03-09 20:20:12.4057+00	2026-03-09 20:20:12.4057+00	2	\N
79	8	EMP0079	Faisal Al-Malki	Professeur SES	TEACHING	ACTIVE	2021-09-01	MONTHLY	f	f	t	1.0000	\\xc30d040703021ed758cb5306150660d23b01e4602cbac3d97ff41dcd2fc0f009af376fd4e79e9f3b2e9647122f2c53ff6a0967566b593c126229bb9714d5c65c733a80fa05828e3c953b927b	\\xc30d04070302b8226533f29f579765d23a01368485d9a80aa075d5ae1cc06a451125db5ef132ef466024e30d27fd98f160e5f772ea1cb40dbcff877de21167dcd9cd758652cac02fec27c4	\\xc30d040703028e8a276d6f09d82f7dd239011d25a1a6e83803629c6c46efd9948779d042ec92d6725d83306fd75af2de2776058a440d4df9331e051b3fa3459e40b99d4dc44840af93c1	\\xc30d040703021499942b25c3b39d67d23701c584d691703f1060cf110816e7cc43102d6c2eab25f8dccb0e703b485c7e9715db192f18af0874284054ea66f1cb60a566e911dc13e8	\\xc30d04070302a5c131229f6ad02c77d23701464be526b610d6882e9bdc9f1ca651f8825b4978b1855be5d755b76339fbcd25cb03762f11bac413e506e53fa659a190fe511a8f8116	\\xc30d04070302343c21fcd62eb9cc6fd2370184b59e3f2a4f873feff4ddbedb9392082660ac6f44f20b0003b4e0e5a477c5a746dca11e2be6b3ca658c8b437c0a637bb9b3cddc31f0	\N	0.0000	0.0000	2026-03-09 20:20:12.406397+00	2026-03-09 20:20:12.406397+00	2	\N
80	8	EMP0080	Marie Simon	Professeur SVT Lycee	TEACHING	ACTIVE	2022-01-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302d0294fe4294f1a136ad23b01277be5878c80e4d50cf2e931cc952d53533060e11518e4bf75370cd214aa8374b560a84fcd4c8e2bc3abe018f2f050d1e327a1f747c0402f80e1	\\xc30d0407030240291b2dbb5339837fd23a01d413855dcd3e6145df041d63c73a85f77b619fc8f9507b34dada96d85ee4b953a2ebd3cb5daa1fd3143971239c3372d12e2d5c213920475ed9	\\xc30d0407030252b33e18b2169e3a74d2390166b3185ea4a29b029a8c3d1cc42c4cae8ae827bea0034942ef08c498fb22a22e3b18eee43af293f387d378aabd69d7ae55d8f1973955b78e	\\xc30d040703029d0474d87e0307ce73d237012a5d1882ae5675d6a28e5c743d9befa2a6f0a58786b0f8dffea347f48d9aab094dbb44be4dc097c92bef724382c90d98df63dc1c22cc	\\xc30d040703020a51ad48b4e2540173d23701b431898e16d04db3e8d0405228ae833ea9f1524f378f74613f722e215028c3ba03e60731acef7d482135fd0cd2493fdf684de821d738	\\xc30d040703022023c08f7569b9bc7bd237014b4f3304816f7dd5cbcc9496a9326272ffe5e7771faa8934fb15cb8f64efe5e43aa6859a500a55bb697a152bb2687d9b6987c21bb4c4	\N	0.0000	0.0000	2026-03-09 20:20:12.407115+00	2026-03-09 20:20:12.407115+00	2	\N
81	8	EMP0081	Jean Boulanger	Professeur SVT Lycee	TEACHING	ACTIVE	2023-02-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302850f864e373f121c6dd23b018278adbf4c26e7d1de5ef00afebc5073b5497ff0aad12aa69fd29afbef2caaf10e09635a82666f1763908be3132766b6e0352411653509747918	\\xc30d0407030273584c805d14a7a570d23a01ca0efad165adba28bc05642fbe3c4f150b7aa95a54ab5ae8069fe8bc2ec88743bc0897abfa1bf0b860c7d8c4c9905318a5df1b538fbcb19e74	\\xc30d040703029473872af3f3ea7c64d23901829406d5199bc3812f314bf73843fdcc747f4c2f3b02b6dbb86c830a50e85e156d79006360572d7ed5c7b970f15d1b62e50bb327f8eeb2d2	\\xc30d04070302edab82ec3b1abf9b70d2370115cccc4981101602e9b0717022ca0c14363bb41cef7fb78b4b7f17d53630657d23c583213443bc017b5914a96613d283e859bd026fef	\\xc30d04070302f82934cb8747dd376bd23701fcb18c92612b01bf918830da66ec5af26a40709e5647eaa9ee28c2b1ab7058dcf8ef04df8922c8d0bc0869ae019fffacf356c65740fd	\\xc30d04070302bf04e34c19171b0375d23701eca348806c1b920d1aabfbe772e21de53518cb8bcc10f701fb01cbe19ebd547e57de9d67ec2818a8ab469d901e3844fc8683e668f4b7	\N	0.0000	0.0000	2026-03-09 20:20:12.407932+00	2026-03-09 20:20:12.407932+00	2	\N
82	8	EMP0082	Sophie Chevalier	Professeur Physique-Chimie Lycee	TEACHING	ACTIVE	2024-03-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302eb15fefade0d9a7374d23b01ad1aab7cf6800601bf2e258c72ebd13fde9fc41bb8f0fa48678a16e2e87f2c03eaa565d8601c2b9a3e26da5e247981af993d19d64844dcd602b0	\\xc30d040703024c2cc16dd64f6bc263d23a01e27b8058006b5212c04698be463318b6f95769c47468fbe514caccd38df3e5c9e4f32775846f4693b542afcf2629d74f95db94caae43e52ad4	\\xc30d0407030206b6486f1788f05e62d23901895793a4c75b06f2568c62aed6abf53b721642c26b9b9423667c1e9d5aa7427258af6e560c4a9828b476c84eb7f6a78cf2bb3730fe24691f	\\xc30d0407030223ce1335e4a9641d63d237011b0cc64575666a1242c2d7afdd3034c6f9899e076618f62288e32b0fd66e303c6481d28a2e59654a2ce18c6881d8f9a9bac3ebb692cf	\\xc30d040703020009f1c5e92144c360d23701bae85e607f812f473462acb8b22d6bcb9e1e3e548b477e4fd791a951966f4ff6ea4877c4778ec055bdf340aaf06760a17e37541fedde	\\xc30d040703026e0920e472c9de9e62d23701d7ff60b5140fb7604ac7fc26fb69016f7a7c4aae832fe8d6e3bea69e07769028e81613d37d54894af8ba99fc47b89242ea4671ee69ba	\N	0.0000	0.0000	2026-03-09 20:20:12.408584+00	2026-03-09 20:20:12.408584+00	2	\N
83	8	EMP0083	Pierre Al-Ghamdi	Professeur Physique-Chimie Lycee	TEACHING	ACTIVE	2018-04-01	MONTHLY	f	f	t	1.0000	\\xc30d040703026809806918ad1cc477d23b0188b6a4f94c0bab613b8d4e0b92a4fc2d7ecd14ce7e7e7bd2180f6e8c2d32e1686e8acc817f96f0bd182fe53eb174986d3caa4b88ee9f1b5d090c	\\xc30d04070302e86d5f04b2b3127e6dd23a01e34bfe027477b5e8c4116daa287ef9bfc84f7642b7cef21f84af32c796a00d57a21cdc5cbdffe4a67e2649b163cf080959b6d66b139f1763d1	\\xc30d0407030295e7c31cc1427c966cd23901d63669e1d327ff732daec6e22cb7f3dfe3d7dde79dd22152cf7c25c1cb91b671605aca277592edd4c3658ac2e42bc570c229c94b4814965a	\\xc30d0407030245c19b2bb36e2dbf7cd23701c8a40f04df2c543e269ece82e6e07811f9c8e9272e78d75cf837048f3199cc79ff05cc2979fa3a4a37b81f51c9b7dbf5e5638279d991	\\xc30d04070302ecbda8e1cb3e479566d23701462a46cc837f7cb6d227ac78bd56f462a9fdf86a0a1f569dba7c75e76278406df82b8d826114d62756c190374c9471959cfd7393aef8	\\xc30d04070302eb34b495041ef38670d23701c3606d71d7296c22d4f8be14b5cabbc968a3605de8b577ee6d1410d4907b98e1889ebbe9dbce74fcf83bef4a10696b7108e5fdabc274	\N	0.0000	0.0000	2026-03-09 20:20:12.409136+00	2026-03-09 20:20:12.409136+00	2	\N
84	8	EMP0084	Fatima Fournier	Professeur HG Lycee	TEACHING	ACTIVE	2019-05-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302d56dcb9d372a035f72d23b01f920fad39d3ebcb3c526171d6b9753f7fc5fc7e9b5a9e945e66ba56dcd4f70bb060cfc79cc26263b90621801eabfd50e13c8e9b034c835dda61a	\\xc30d0407030279a54aa443218dba7cd23a015527245df2315e0765dbfabf2df9e2d3c57892e7356997d5d71e57077fcde39cdd773113570041f0d01fb0c352d1fb0ed3dd5db1fd192ef981	\\xc30d0407030260b89d9aa9c977c86bd23901db328102d1353ed2abcbf8283cb303feee1fd2b3b0670ab2376ed75c443ada88ce5713a40b45215e5414178213130cabab67970bcae15ccb	\\xc30d0407030257e41126b336f71476d23701e47530b29889ef22710c3526f61793ebb09715604e169d5173ac28a1b2f496bf27edfce772ae5bd8d92bf3090ee85d18b92f2ad33dd8	\\xc30d04070302f8b7b7353b64b8ff69d23701ac686f55778d845d7cbca7627d66681b8a5656812d93d21d663134c03eeca2c6227514be15c44689e30faf7ed0ed22b6a21a1d9d3116	\\xc30d0407030243705689cb69241872d2370180190482e05a951a607966ec6fa2b99f3806a996904a95f71755f15783d9aa6989c2bdd9fd227cc34e36ff8d63a513337e987e1886e4	\N	0.0000	0.0000	2026-03-09 20:20:12.410831+00	2026-03-09 20:20:12.410831+00	2	\N
85	8	EMP0085	Ahmed Al-Zahrani	Professeur HG Lycee	TEACHING	ACTIVE	2020-06-01	MONTHLY	f	f	t	1.0000	\\xc30d040703025199b0c4a98dd4be7dd23b0177291d8a39cbb94f49da825a682744c79dd81bce1c61dadcf3cb03561c750979dfecfa15be96af73db036fc44162c484c78f55f56decd7ccda2a	\\xc30d04070302b19e8ec7f9364f8762d23a015e1ef9c4a51e6a700a24af9911693d469378cd632771dd7f2aa9b63acf52cc6bb337c5efac17d620c18c28d994629d4ffc61e28164c1730a6b	\\xc30d040703022ae3d0a9cf364c6a71d23901deb08eb5cb7a5936569aabd63716bf013dca52eafcddb323af74795cf369b562ae103b0b2a2fcae39b685974e7bba6f6455e1d1ee2720823	\\xc30d04070302cda876483df5278576d2370125c18145ac9f52f8cdefb948cb6ce71f5b556fa509e79fe79acb2925ac6fc1786ffb07a3502087fe72fa1460eb10573c8e998308461c	\\xc30d0407030298cdadb2e35d647b70d23701d3ca9960aefc0d2a7eb56617cb664829c79cb6b38bb7f0631fa7045b8b6ddf1336fa391bd1224a018ec221f1eb46b709f65184c61aad	\\xc30d04070302a854df560edb02fa7cd237019fbbee4ba7e892b3a152b045fea101abb6f52c76e28fa6b5e71520b6b3dd884f4b53c12860f1d9a08e58fcd25fb4255b28d604d8b028	\N	0.0000	0.0000	2026-03-09 20:20:12.411547+00	2026-03-09 20:20:12.411547+00	2	\N
86	8	EMP0086	Nour Girard	Professeur Anglais	TEACHING	ACTIVE	2021-07-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302d2681c758941bc6560d23b01cbcf1b9fed196dd3458a4fedd08f2ff891179e6edb8f6cdb6e40962156fb95be244ebe815da9034721a74dc37555fe72ef4deb7766420971848c	\\xc30d04070302b05c803ef64dba857fd23a010c09cbcf415e41710dfb647fb13cc56dfb0f100332389a59ed92e45d20f80e1028843e7b2b5355ddd17b61dc3a97eac94ab94ccb27f4c5a25b	\\xc30d0407030246b301d90c42c3ee68d2390103a91d7f6655ef887745de730984c9501723816224dc405008cdd249885a7e21ac755d5fd58fbba45cbd4141170200a5442af2f75d55c74c	\\xc30d04070302a4aad85013cbbe307fd2370141796e654618bbcef1653a524b1bc35e6d79e334b4bc4bbd57f4add1eb99144250f37b246916b25f18bd3e2028321dee677f891efef4	\\xc30d04070302ea4e190568443a7860d23701780dc104511b4bc8e32289e3a89f865816cad42107c2439b191e8effbd4d142eb027f3241ec767d8c7c98a309391b44546f2fa5e4175	\\xc30d04070302535f6877f1db49be65d23701a7b2d631157c3f0ce23fcd4d4315431d9c49c93bf7f1e0235aded34ce010cdc190448cce8dac842466f8eb705e5c1674df2cfd6372ce	\N	0.0000	0.0000	2026-03-09 20:20:12.412328+00	2026-03-09 20:20:12.412328+00	2	\N
87	8	EMP0087	Khalid Al-Otaibi	Professeur Anglais	TEACHING	ACTIVE	2022-08-01	MONTHLY	f	f	t	1.0000	\\xc30d0407030299656da8af8b0f3d64d23b0130bf4ddc284e5f1339acf75ffb7f1fb3a9f25bf9c83d9643f7951024ea05336d637811fe37f423f80e810e0ff6ecad98ffda00b36d89c3237965	\\xc30d040703029cbbd8817e54802170d23a013f2eb4ada9938a1f098c87b77d1a61522119b7be35bb959929166b8777ab702aa62e4d6ebdd2be3fdf82e7b6847232b2f30320901a2a37ab1b	\\xc30d04070302517913f09e8469ec65d239016a0d5bb32793486408e2bf9533eb6e254b3821bd1c61477e512966eeef245571d9b71bd8d1df0cb7cd45decd908bdcfb544a37341356ff36	\\xc30d04070302a0dd8f5c777a0fb16dd2370139aee380b924f37ddaa177c4fd73d752bd245427d5ca8a401fcdd5d7fd0394528d880674b6167cddeb2c1d251e08f3322ac31d95f9cb	\\xc30d040703025e7fa9c6df5f7cd777d237016f74507f7171723321f88f150c8191d5e531a87f546a2b60d5f27113736c346699faa3c26a9479d2799f5485e899fc077f50b767fd45	\\xc30d040703021a21d681e6e88dfd6ad23701d746b026f79fcde68589134aeb11f4fdfcfbfff6b7fbdb4ad38860322b024e2e8f54946f71b646fcb3f0434b85e49138ab06100eebc4	\N	0.0000	0.0000	2026-03-09 20:20:12.413027+00	2026-03-09 20:20:12.413027+00	2	\N
88	8	EMP0088	Layla Andre	Professeur Anglais	TEACHING	ACTIVE	2023-09-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302aeb8614162e9ec327ad23b016ceffafab4cfa5258fd421f73fac226e77b52f44824808e4bf02093c542e186b269c80142c65f2e183ca1f448633a339ff8136d79c8ebba33d1e	\\xc30d04070302f97abb084b10146571d23a014f23860ccb947212fc70773d2bf37288578b188b1089f315f72e8360ce31d77c6186d281f258e39d9cfa211f0c09a0b7a1e35e46049f6840e5	\\xc30d040703022970e220767cc9d778d239016da22ab375c4553ca0738e4d2b8fcb7521b0c3f4f24a5094954d3e31e188752f45c0598b7e279e03b7cbc1430ef9c51d40e5cdafab4d7bdd	\\xc30d04070302d45d3d5341f7a2fd7bd23701061ca1e5ba74088cd9aa01d5813216f0004bd963713888ae77e5dbcfd4340bb2666dc92c9138ffcf884c42c8549c900c27a3a323bb29	\\xc30d04070302be6a9e58273122886fd23701fa2c1d5e602273a591aaaa6330edb92571f4ed20825ef4fcb566df969ca8e08a304dc506ddc4404ec6ee922b5ae1a6037c86d675f9f8	\\xc30d04070302db1d5be270f8314b6ed23701bc2ba5060e34bb94aec629bb84216ca96e157d2203eeed46d431f16b76f3132d2c0ce2a884c966ded4ccc1c24df1a3de81b276d1e25a	\N	0.0000	0.0000	2026-03-09 20:20:12.413707+00	2026-03-09 20:20:12.413707+00	2	\N
89	8	EMP0089	Omar Al-Tamimi	Professeur Anglais	TEACHING	ACTIVE	2024-01-01	MONTHLY	f	f	t	1.0000	\\xc30d040703026576fdd7983a7c4b66d23b013e688b947c9c1317a6ed1fd85886c0d7914e36c4402519ce5d0580c180855207ce58f55473b6f9c67472dc009a7ecc1bd9bdb160865513018955	\\xc30d040703027cc3dab3708721ee6dd23a01c20d21595ef1fcd4cb1768fca77dcf6c552812a1dea73eaef87b693b055c37aeaeed31c1b5e78ef1d9d5ae6111540e6b026e5a0657c5df2a07	\\xc30d040703022960eab1ae21ab526cd2390122543090fee769c3738621c5fa714dc6dac5cd1be864639b0998714660dcb49acd500c0421b4b3992cb8a677734b67772c7805db4b613763	\\xc30d0407030245b4087f1ee9c4967cd23701e96be394060d6ecb705e7333e970548aec2e40c9e8892bbe14bfa0573ac560f3bf5f17464c0d57cc9ea860d75a7db7b4f0427b1c23b7	\\xc30d04070302b0f0d7996d78562d7ed2370184f0c528fc355a449cb2a6b699b78eda40c9e907545bc442e643f0c97a83ead39b659d2f454779bb8a559565b8d9668b80a4639638c8	\\xc30d04070302f1f9c789c819ded068d2370197f3be349f97f05ca10b9cfed29fc8507d763c6ab4d3e114f08e7e40b9f57cf9aecbdbd1d56a7fb8cda287f1e303d7332597249b33cf	\N	0.0000	0.0000	2026-03-09 20:20:12.414487+00	2026-03-09 20:20:12.414487+00	2	\N
90	8	EMP0090	Sarah Dupont	Professeur Arabe	TEACHING	ACTIVE	2018-02-01	MONTHLY	t	f	t	1.0000	\\xc30d04070302d259cdf3556ee39a7bd23a01508e7023b16588fc60439264d5290d8a897e138c1fa905b59e99a8d681c719d8caca0ffcac00240cd5f8c38621510b2252b3168cbe175b9e32	\\xc30d04070302d1b9c635eb6e024b62d23a01b71ed32674fa2d84563c746869e05d3329d05e300c4141e19e0652c7cacba066fbd1646d2d02d635a42eb5d6ea8c2288c922b769029c623282	\\xc30d04070302f93dd0a26749c6c17ad23901e9c8eee1c87a3061286d8ee56e00ef7c74bec534406ca3e8690e8082d3171279e9d726206b1f38c19f8020c4c222bf455f3d8b70948daaaa	\\xc30d04070302edbc899d5c7e986078d23701fa385a309cf23fa723872fce050caf1d62278b9f3800d01996c6666127e8752b2727411944b70aadac981aa1b63c007baca7e62eab7e	\\xc30d04070302c2ad1afc5969e3c861d23701961745be1e81bd29c0072d42a0f8a20dbc9c45ee99dece17dfa78b2f57a08fde69b6c78e66a243cd29b9c0e255b4e67a9af781b7596b	\\xc30d04070302ab766a4ba69105d760d23701d7829cf5c8ea31d4c5dbe1724c6b5ff188141b976afb084ba05aed0f6decb58f7ef66e210ea1ffcd601584b9e8fdab013ad27e88c371	\N	0.0000	0.0000	2026-03-09 20:20:12.415228+00	2026-03-09 20:20:12.415228+00	2	\N
91	8	EMP0091	Youssef Martin	Professeur Arabe	TEACHING	ACTIVE	2019-03-01	MONTHLY	t	f	t	1.0000	\\xc30d040703029b68d1e3b2caf1367bd23a01cfeb5e0d191b767b9bd9e6ad8a7c1bc2160544064f583ed212c30a787fd8e0fbf27ef8fa43635c58dd5f5d3723249f1a784e15b896e1ced695	\\xc30d0407030216403e8edc38da3376d23a01d940517d5f6b22b2f202984c38b6908ab5fe1802eec4b3d75f9e5dd3c550445befa9dd122a2f4bdc02f8651b7da3da21e7ffe25ed15dbf0a71	\\xc30d04070302e145b988c83f93fb69d23901797409224c31402c1f23ef8e30451671b56bc39323b55fcf741b7f9fe76df0e326fc690c4d343470823604a3e8ec38e0ec5962198b684303	\\xc30d040703026553f886bea8083167d23701ce2c5d9924db4e43144ac1a37e28e6df1ec3069da9d0dcbb8239119819d016c3ff6bef1d0268722c1e4359b7b92b3d670738c749c878	\\xc30d0407030257d332401f4b42206cd237015aab9d92b20ccf26ae7c39cd658ea03a21f7641df34adec72cb725ebc7a32d9d18c613012ab7c722accacd0bbf047fe6465c661e7a9d	\\xc30d0407030295b7c26ba6ead0e475d237013959cb76353eae1dcf53119f403690b43c40e257a6e8030ac5b1bb10df6a633641063f41ef4602a744f9ba19d5f43a89a197f6ea3feb	\N	0.0000	0.0000	2026-03-09 20:20:12.416332+00	2026-03-09 20:20:12.416332+00	2	\N
92	8	EMP0092	Amina Al-Rashid	Professeur Arabe	TEACHING	ACTIVE	2020-04-01	MONTHLY	t	f	t	1.0000	\\xc30d04070302bcdaa517dcf2deda62d23a017be60443f8e74c9aa92583a85c3549f2a02c76a79fb9d4cd68d891e8d345a066b037fc7ae2b24aa0158e7bcdc03dfb2754f7c9cee74ef2dfb1	\\xc30d040703028142e36626ea7f7a63d23a011a6fa56f5a297c6ca85ea11dcec1dc1dbc05e4cf2e1ed036b3921bf2c1fa1df99bf3478b638053367ec68ac8acc33c34eb2f5c8863977c0343	\\xc30d04070302aa6ebdca7475855a75d2390154b7e0b6032e36c6a1c3bd20ab8cbf61f75971be4ce1edd25120432a1cbec0eb8ecfc1f943ddb9e3791179ededbd9bf512c8f0aeb0ba9e4a	\\xc30d040703027786ed96e68efc1666d237012ea25dd88c5babfc31ef281da7e2f9b87ae69480c71a53b9a8d448d9ceeb6e2aaddc06bbefdd8d1ebae19ef8cf3dde383485180e2f53	\\xc30d04070302e2d4faccbb6aff5e61d23701c6459f9ebfc87e746a93ff77c20a96c6022f9bfb4cb338d4bb896d69b30a9bbc186cdd6e03654e5a744b26726a6266028077d855d406	\\xc30d04070302482dfd696c49887c6fd23701e3ba28a7c08fe1c8de9b756480caaa01db765f2ea6bb9e30615b3bfff4e23f5af9ebbe53d93b344bc0d1ebf5976309604bda49bc7c01	\N	0.0000	0.0000	2026-03-09 20:20:12.417051+00	2026-03-09 20:20:12.417051+00	2	\N
93	8	EMP0093	Hassan Benali	Professeur Arabe	TEACHING	ACTIVE	2021-05-01	MONTHLY	t	f	t	1.0000	\\xc30d04070302d8419144730637d67fd23a01ee482faca2ea0d353b3fd776de0fa0b5b26c7490c40a50a3c77864d275fdda3413cabeeea3f2a3999035b355e173642853d1371e6a46d46449	\\xc30d04070302ada283bdb39416a86bd23a01dc00f085333c6739b3ceda88e877692818c431ddde798054fbba902a999cffb0178686d7fd36fb5425cabbd93e309d4302715bdaafcb6640dc	\\xc30d0407030268da32f8fc582c297dd23901d29eb6b4e129e5b8c88f4ab5cb9d841ee6ace41b04e8479cc4a1bc40c14048d702fad5ac5a59d36b79a8c75ceeace80ce3628de26fe2a61b	\\xc30d0407030205c8bad77b68173a7ad23701306527384b25101f58fdad118a7f8bd3f9a57a3d6c1303b01cc0adc94e2e4b69b52e7316fba1973a22b5df2c8b8b5da09096cb6edef1	\\xc30d040703027d75ecb769eca0a978d23701d86dcc9d188c56dc07a25a86d5385c4a40fe1fe7878f0f4e211ed0d743bb4958835659ef78fd05121329f03a8d57b8d9456547909ff5	\\xc30d04070302923abdd781ee9b8a65d23701cc0c53d958d194d0867dd556e928e8e87d3afd6215bcccd3fbde1e65de174b868fdc5063dcbc5db44721172f3657e3f4a1d8ed2c15f6	\N	0.0000	0.0000	2026-03-09 20:20:12.41765+00	2026-03-09 20:20:12.41765+00	2	\N
94	8	EMP0094	Claire Laurent	Professeur Espagnol	TEACHING	ACTIVE	2022-06-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302287bab6e79bf91097ad23b015636c7bb209f3a2ca2320770a1d21f524a8c3528da6e1ed7f8aeb1ffc15cc7e9a1a044f1a5c2e70f2f58ff53132bee260a4f842e0e659c0e5d0a	\\xc30d040703020ac768fd6afc8e9477d23a01d357c714223c474735725d7907138c1d9c3e3cf54da7bee96ef1ffe395a5ce389cfa670b53244da3206bb0d14030935d753f48fb03bd935e2a	\\xc30d0407030218898ba6fb81bf5d63d239012ba291172bc71b47ed7fe6d22eb219e188d5c1078804f4d505e66199e5a70151ecc21235d5114704991a72da7fbaecf03cd78f8aa0ab530c	\\xc30d040703026839b3752163e05672d237012fd513a845c5ae533399eaf002053fd721ff6aace5dabf120f4f4a7e2ed7da2116e1b91691eb5b09380b27d7833c019c0ceb7c63dc7f	\\xc30d04070302f731ecc9636cbd287ad237013b70cdee4bb196e86269997da171ec703456e487812a6b5f47b7d61e697515f3b1fa1f64698ac828b05d19d6c9a4b0252e908690c4f2	\\xc30d04070302f9b582946a99cec967d23701d96c82e6744d7990408545c7ddeefe0a4c09974f7ccecdc8b7f42a83ef2deec180f01d9f19c66c98b1ae15eebb51772fe4dda1818c47	\N	0.0000	0.0000	2026-03-09 20:20:12.418505+00	2026-03-09 20:20:12.418505+00	2	\N
95	8	EMP0095	Thomas Al-Saud	Professeur Espagnol	TEACHING	ACTIVE	2023-07-01	MONTHLY	f	f	t	1.0000	\\xc30d04070302c4d3f812d870942e63d23b01647274f5e7d16525418e44fe1d3fae6ce60ff39b53492b3cb4f38b0d5fed66fc03681af0622b538f4ea7169b7771be1b9c3ef4884a5a0dbcf101	\\xc30d04070302197c9408c66c500162d23a01c34f10a62723e217ca1121b8870ddfe4e89a59c7b4c93b6bde452dcae172247a288f2f9a94244ff25143da5f8c1a31016abf4d34cab503e0e7	\\xc30d04070302952f05ad91c4879272d23901fb7b34da348eef58867a4b27067fb10d046d22e8aacd7385b9bef228cd8abc956d4e5598921c7faf25898d3839ccb235f5fd3f860bfff38b	\\xc30d04070302258e4075f5326fac64d2370118563198b634c079ae04c2a30c35ce7593eccc260cb180a024421574fe23992c0f7b8bcc8a926b7d298124022c7aa8a11659c3596957	\\xc30d040703023da98911edf10edc6fd23701fcce59c38d7fee876743537cfbdb567409fec14b9823d369e7b6b97f14d898bb084c3324bbdb92b9ab9d4646ade1aa0808da1b335ab3	\\xc30d04070302fa0ab314210b19a277d23701d80ef5820cebcbb6e3b3afd1af519bb78aad3bd88d068934b79e148fa57d9fddcdf6411f2de9b3dcb58854045ccd5aac49a6a2e8fb73	\N	0.0000	0.0000	2026-03-09 20:20:12.419307+00	2026-03-09 20:20:12.419307+00	2	\N
96	8	EMP0096	Leila Al-Harbi	CPE	TEACHING	ACTIVE	2024-08-01	MONTHLY	f	f	f	1.0000	\\xc30d040703027582db25f6f8954477d23b0136fb5b8c9b3fe6356868e952fde86e7edf26254eb9d0cec8b01ab4a9d288fafa332863ee6d51c5ffbb3cb07f81e0853e6ff290f7fe17c97a72db	\\xc30d040703023c47b7ad573f3f0569d23a0124c39e0cf74d0918886bfd24bf2166add6077f9ca12a8a4d0b579a1243d52a8358a1ea9419b58716c87d0728c20bcc0bd9da155c622f7a79f2	\\xc30d0407030214002f45b7c842f062d2390106923d412f5df63f370461b5d74670afd23f94f1e7cdda0ac8bc813bbf4a35926476ec039a701c16a46c3f2c71cfcf25b20becfc4a54dc6d	\\xc30d04070302b693518896df6def73d23a016496f9d3b49a96861ec173c2e354fdaf343e4428c584805c531e9dec755d7a0f05f7a92994464026bb15daae4339aede030ab1f003c352235a	\\xc30d040703029896b67ce50bf97b79d237017d72874c13a3e1eeaeb068351d3a90380e7cf9dd935809999f3c7ecaed585a8371f72ff594bbb0c0841534de62b368c48721ee2a101a	\\xc30d04070302a8ed9c954302dd0566d23701c935108fd1af2f96f3242d36612a53c85a88c3f4581f378a1034d7d60e29ef552d7aa3c5635e8c94cf10e98ec2df386b297b866cb86b	\N	0.0000	0.0000	2026-03-09 20:20:12.419952+00	2026-03-09 20:20:12.419952+00	2	\N
97	8	EMP0097	Mohamed Moreau	CPE	TEACHING	ACTIVE	2018-09-01	MONTHLY	f	f	f	1.0000	\\xc30d04070302a9b26920c9ecd5f36bd23b01e86211ad9ef4aa00818b864a030a39e899fad7613a976ff2b8b3856742ad3c3095013f7eb1967b82fa7006c37d34e4c5acf69b42a96d2cb30ac2	\\xc30d04070302d9b7eef2200a737b64d23a0135516b177847a2d46c08ed5361bf31aa5b88a1e88280358d7d0b1d42cbaf5c219182f6b8d7088ca21b55b4f9fb3348c27a5d5030b89ef5a713	\\xc30d04070302d732a5ea45dfc3f26fd23901a6b04c8ba5541b084efeae3d3a3d6112c9b5e1fc14b8c61806024771a6c54cf96e06ba21e321580bf6236f679eb5c13aa689fc1bfb4c4623	\\xc30d0407030209bd4af729cb367266d23a016158121c2cc7838fbb8b0c0c44e1d778d122a7a39571ca14e4a70371e6d3d85df31df3b2db3b68d7c275f38aab68504084127f3f3e008d6485	\\xc30d040703029474d0dfce97e55372d23701bd1756de1f08bd716b56c73830461c49db12c7cb69a53ed9eef775f0a5b6704a317cb1bcab6a6c6fe504ad70e0e572a750ead9f6d3ab	\\xc30d0407030221725367eaba1d2d6ed23701a4cab1dab6abafafe57650ddd60762cca0b9276457c831de99251170c2618ecff9b54f4de81cfdc9f044b4774718684ad4b3841f329a	\N	0.0000	0.0000	2026-03-09 20:20:12.420631+00	2026-03-09 20:20:12.420631+00	2	\N
98	8	EMP0098	Julie Khoury	Surveillant	TEACHING	ACTIVE	2019-01-01	MONTHLY	t	f	f	1.0000	\\xc30d0407030282c75e7f3f3a632f6dd23a014f9fadf7d3f470f1d14108fd019f1193ab7923e6eec72248a9a569c2ee3b92aa9010ec9d2a0f9c9810984b5f673894821305bcc03b837de69c	\\xc30d0407030256c40ede05937e6d6cd23a0132377be5fdbbe57529a488c5b00c9ff5722538e3789b91e5fb1a9f47cb509f89c2bf42b1b8ce1734acad80f714dadde66dac04cc88a7ca824e	\\xc30d04070302cd7c5d1b58d111b57ed239019a0fc81735fd36be4ca936a18b09edce281bc1567c4eed056d9db3a8ef4688d75fde5de4948675fc790cdb95402b91daa0e1641aa65793b8	\\xc30d04070302999ba7a19265dea56ed23701f770176be25a390b542810e9e68ab4fc0290ad11926b1dea1911fa4846b06917d6e54d0092af8393869da23b186360c83445998d53f9	\\xc30d04070302b94db21f4cd1382669d23701636c68ebdaa70f855e91c24d7b672c9aa06baf2b5aee9c33f311470f84cfa1c3f05c6db1acd27283807207542747df5b94ec4632cd2a	\\xc30d0407030278af8bde8c29eced68d23701b656ac30be09605103c6acf656ea9de88b0ec29290d381e1148026e195a3e9925fa5f50571d7830616da304e622765c47155ac3b3b30	\N	0.0000	0.0000	2026-03-09 20:20:12.421405+00	2026-03-09 20:20:12.421405+00	2	\N
99	8	EMP0099	Ali Dubois	Surveillant	TEACHING	ACTIVE	2020-02-01	MONTHLY	t	f	f	1.0000	\\xc30d04070302fa18236c2cf1a22c7ad23a0145c0b67cf5be1951e06885293e36aac8ac0eb1ed475a024e4c7c0c4a8f1c391f2f0db82d15ff8c7f475d02ba6650a337a62305c47bea72fee8	\\xc30d04070302faaaa6296714ec0f74d23a0166293c4170d7c26271c5878d0503dd0dd7671c3e7dec5dd79506702f581ef46a3a8b0491502f7f8aad164a3d6360153c4b82fe6ba5f2abf693	\\xc30d04070302189e27a9c0b6f0746ad23901f267c5809379e37a84b162c1af31f1f5d160ae1834d6776a04f3f3e0bc3ad474a08d6949ca38eb9c4fa2e27d13b3be2d80fecc5b5a36f508	\\xc30d0407030278636483ccd217f37ed23701c066f4c6ff6ca2fc1bb4d32b424c0ee4bb64c78f4245dbd3702d92e27dc92575a1996dea435faac2bc1fba10c725e6c41e30bb2e8c71	\\xc30d040703024d951c92b924872676d237017624666208c1d22ce7b83c7600177137ed79a75ccab5cafe4cadef90a62c0330fd0f1c597d2a022afb3b0b4463027125b0f7ce241810	\\xc30d0407030294e202bbb821a99464d237010ecb7865d14e3ca072f66667c5605ffa8dd0bfa0cbfef3812f9e3c79e173ff18eb7498ec912f6986b4ac0ee4db33c6fe82e009f0f26c	\N	0.0000	0.0000	2026-03-09 20:20:12.422116+00	2026-03-09 20:20:12.422116+00	2	\N
100	8	EMP0100	Rania Mansouri	Surveillant	TEACHING	ACTIVE	2021-03-01	MONTHLY	t	f	f	1.0000	\\xc30d0407030235e9b52227e0853b6bd23a01840e5f6debcccbee52178e55d67e7deda92f1255c80da01b40583594fe7c54d906670d6d5e3a1c1e068daeed2c761cac0a8dc8fc7d9190cc1d	\\xc30d040703022df6f57f9f1c78af63d23a014bcd18181b4d1f9b6b619bcfa4bccf98138d406c4e525f9294029de395b02dda8c1ac8204fc8432051150b4aa6c340597dd69d498d5b506fed	\\xc30d040703028fb71465c7a0223063d23901f3104e04dc079cd60c10ed7a2e0eed57650d5c828566c4f16e26fe561bb81c28ef34b2778971beecc2551a47a10dbe86b05e86e11ae2d51a	\\xc30d040703029f9422aafc8018bf68d237018f87de9b48fb21978d29e47701858ef2cb4f64846a915cc8aa2510cd45d18bcc7cac42270fad1b36b601d1d9c802d264579f2c587c95	\\xc30d040703026f24bf6a48b3b33e7ed2370145e630c484926cb91b6f9ec1ad6b0a759f1eb66704dc142a302402ec2554ade9401810855f29ef10264fb36c97cc02e867ac0dcaff20	\\xc30d040703024d81e9baf4b8849572d23701d14eaaff21e448d975e7e74f1315884a91fd417a8ba889a7a731daaa7fcd0885a6b742edf9a8fe045694344808dcf740428351810f1f	\N	0.0000	0.0000	2026-03-09 20:20:12.422896+00	2026-03-09 20:20:12.422896+00	2	\N
101	8	EMP0101	Karim Petit	Surveillant	TEACHING	ACTIVE	2022-04-01	MONTHLY	t	f	f	1.0000	\\xc30d0407030288eb91c2658f88a86bd23a013159f5e9d69543152cf6fdb69e80783eddca22ed1000cad823d62f703ac5126139ba85358351d8fb6148672812524ac1410cd884b6309a3a3c	\\xc30d040703021d25150b9187259e60d23a01b1796b5c961909fa7587b15b677f705988aad1a125c2694c5fc29aae486857b1763deecd46ee1d682027b6cec6c6f439f0343d5d370fbdb296	\\xc30d04070302030455020ef3a05365d2390150b8bcff48622427ec575579182c1e5c87b05769d0b6cc1a9cedaef7e979c5f319c2b0e11091b4e32c935035d22ecdf1bce0207446167533	\\xc30d0407030239714d43309eec6271d2370154f0757fd926bbe414905540f22130b3d4666e5dc69202d37c35c890bb82172ab10f524a64ddcaa19ef89a8ac2598077e909f3fad2a2	\\xc30d0407030202320e6ded1f903960d237014ec90238a8912eb970465c581b2f4c78c926d2fd158df33aadf377e7a4b170ffe7d3946fb22f7dd0bc12bd4e977cea844d5c344fde3c	\\xc30d04070302a63c0066bd6ce0e968d23701a6af9b8fa70b55897679091e8b180301fac79348eb46b3ca028f9e245060eac7202fe65d4ac8b86d54d119b1279ba2e4e9adb723a5fb	\N	0.0000	0.0000	2026-03-09 20:20:12.423535+00	2026-03-09 20:20:12.423535+00	2	\N
102	8	EMP0102	Isabelle Roux	Responsable IT	SUPPORT	ACTIVE	2023-05-01	MONTHLY	f	f	f	1.0000	\\xc30d0407030278565f6ab1ee95467bd23b0152a8721b06657a7d3473f948251312f14c11ae2c52f4c57385b5e25da7aae26daecceb6d42e8f0a6dd7a4111e5067dc469efa660f7a5fddf1b49	\\xc30d04070302f2cc4b839681014e77d23a0156837d6181bfd74fafcaa2e064c45052bb6bde6bd625bbec2038e7f062b2ad1011ac4c378972c571671e37cb6c46e67e10a8cc727c011cec48	\\xc30d04070302ce541ae2d0f1684179d239015d98b59711e203307a0070654331a90dac684c8861b8118f61feb64825c486f481537910636c84e98925aa08150483479b8449e0eb3f22e3	\\xc30d04070302a945543042cf04c066d2370106ae87513af9bd7ea7ff20cda20fc024a4ee8b5733d643dd5301c0f69cbd8a6db55b42e0c881ae147a5032aa6b9b0ca19ee401175609	\\xc30d04070302a5d0b67131a984797cd2370141618a382490fc92f288bfcf0346fd8f07c1c21ff62135e252f5e541fdf4933fd24937cf0ead8a8603a8e756c2cdd4ce27797581d38e	\\xc30d040703020cfe56b4328981817bd237012361e56be5e5f1e9af80adb714b843dcd374097de5eb7b292a08759d36fa39dab29f7f1f66804f34ea8b21175c27e358a2e713115b77	\N	0.0000	0.0000	2026-03-09 20:20:12.424112+00	2026-03-09 20:20:12.424112+00	2	\N
103	8	EMP0103	Samir Al-Qahtani	Responsable IT	SUPPORT	ACTIVE	2024-06-01	MONTHLY	f	f	f	1.0000	\\xc30d04070302c0998db2848ce3396ed23b010c8d37220fdb1eb59a49d7d6b76274462f8f22f86b787cff17b4e8a2b63aa3246d82c8ad051d024ae18b0ff728d28c128ce08d0e1c12331eb5d9	\\xc30d04070302afcd86e7a59b58357ed23a01c8a234d645a895652c756b17f0365908206868b2cb44b67dce6ca520608624274601c9361db0f70e01d210c24d0abe19c60c8ba340e1fe8433	\\xc30d040703028239d14359a6f38061d2390139d252d7b4a51efc09ed5f23c0e55b56e553ce7cb3ba62db2d6469c060a30b445589a3f7d75667fa5f7aadabeafef9c171a16a7631064dd6	\\xc30d04070302159e70a641e6665271d23701ed943c7bd610b475564c1e3079ec179183c93a493976136b72b3c554576540b60d9565f06c9eb5ac61904629943b92270a9f1f73a8b2	\\xc30d0407030242277be210345d8278d237010d6bbc8f665184e2ec8a5352a5472c5e1a5d6c5528f97f90d52d2dba3ff697d5573fc70e87281f6379c6f3cfd246fe47104429d7a100	\\xc30d040703021687012028bf621374d2370118b4d53124f70e37b4b821cc72c5f1f29c20a350e612aab1440574b8bc4ed2cc03534e50d7e89ce6c1c13c0c8cfc639e69a6157e01fd	\N	0.0000	0.0000	2026-03-09 20:20:12.424971+00	2026-03-09 20:20:12.424971+00	2	\N
104	8	EMP0104	Nadine Bernard	Technicien IT	SUPPORT	ACTIVE	2018-07-01	MONTHLY	t	f	f	1.0000	\\xc30d040703020b927d63e5eed1c76ed23a01901772fb8b132f90ef2a4927f0b9a6f0d897b7f8b06712ea28a06727933f1d5f48889e653f3e37b7e1901deda53e69923afcf6261a7adcd35b	\\xc30d04070302c29a1452c041903574d23a01a993f71de113ea66c690b01adb3cca17436c5a27d19d0f3fd8008fd280f67b794679e78e15a54d4e471e12e70d5b90d52034e6fc62add8d818	\\xc30d040703024fb3504bc43a92e66bd239011e308cc230c09e6d352bf72ba9699e0703e1edaad02af4bb892a6f7bff2c7b9b41a23e82f77a9db626bab61bbac46b7a8493c63635f489ad	\\xc30d0407030236bef766677fc06d63d23701cfb340f0c5b03f69e1dfc4257e2f3ab063661156a069045ffd372430702f0387d3ee2b3f071bb0509b48f9bbfbe694a0ed0cffa621b3	\\xc30d0407030262208879e279037c7cd237012853ee9f64334beeb5d805c7b51a1b657c2982b301d69eed0d30ce634f3ca7091ecd0983e8443e06364ea991040dbdf62656d322921f	\\xc30d040703024c83d0038800ae637bd23701731e55f9e402425462ab3b34934e39d358db8f1c662291a43744bf159d8b4b5e6e3d6cad496f5849b7d44ad677cdc140ec5411d9ad89	\N	0.0000	0.0000	2026-03-09 20:20:12.425742+00	2026-03-09 20:20:12.425742+00	2	\N
105	8	EMP0105	Rachid Al-Dosari	Technicien IT	SUPPORT	ACTIVE	2019-08-01	MONTHLY	f	f	f	1.0000	\\xc30d04070302811caa4e1bc745326cd23a01dcc66082147fc0e7db603a819f87b64ca05d38dd915d4197885ddf4b8ee3dbe711cef9d09720ae708c4fafe4d140406cf1a7af5ace347fc31b	\\xc30d0407030282d3d60a2e575a0d74d23a01907ab6b82b2d462941481bd2085289a20c184927fde22db5ce65abb6fe93f8d324e16ec059fd1ca5658647babbe0b00febc526047376e3e58f	\\xc30d0407030222d86536a641095964d23901589478b38d5f817fb4089f52ecb27f36740a8e1ef3b27a7ff9ffe1b6918852429576898d92b200878160d17fbc6b9608d62a51a8a73c2c24	\\xc30d04070302fd951ebfa11ffa237ed23701ed26ebe873c77fc583e8d1cde98313d56b832edb726f9961f38322231ef616a781ae446d4f00f35844cd9686600b888444b8c12fe432	\\xc30d04070302932b347fc5c0124f69d237013334ab8286d0a91f2a420324f23f9260ae82de7702bbff106e6bc3d2ac9656d189969be02338715c014306319b979930add42e144e6d	\\xc30d040703027bed6603785275f766d237019326bff533396a9ea2096d99dc0bcc68bf7c7bc4408f692c723ffab36c76ee8a8a911e940961ebb14ede4a6f068f63943525822a5cc9	\N	0.0000	0.0000	2026-03-09 20:20:12.426855+00	2026-03-09 20:20:12.426855+00	2	\N
106	8	EMP0106	Camille Leroy	Bibliothecaire	SUPPORT	ACTIVE	2020-09-01	MONTHLY	f	f	f	1.0000	\\xc30d04070302473b14ef0a3ee4e472d23a01fb5e1a6fea6aa9defa861d991031595b9648d3ed0fc8d70db60f6659846ea11504e83f9bc084bfd47a799398de73cd4c4c616cdc7cf2fe4e8c	\\xc30d04070302404d929f6f943c5b7bd23a01a741756993e029d08b17d0ac78318f005a67f54c5c0a0afa83939e208af7f9354555ddab9cb80910fb5a868660322591a8191703c432edb3d4	\\xc30d04070302693bd91b5109873968d23901e940b01f04ddfb3f982e87fe6c1521b75701e6350ea35402d1503ee65eb5b007aec555e0254594b85c4d4d8ee5098b9f9fa017fb221718eb	\\xc30d0407030261b6caa1538276c169d2370152ad7f70ccdae4932305dace9dd2def62ae1a889e4d923d90e9ab0ce8bdd8e4b801b650c1c7542a2c57b1efa20a78f8553477dd7aab1	\\xc30d0407030299415ffddbca1f4260d23701294a5aec0fcc9d763800c1f976d8105002ed60a2e8e4ea90c006ec86f7857ce51b32ebcf2cfbe6ec70f1f7d5714e74977f0e5445de0e	\\xc30d04070302572a37bd7dc8de2461d23701a68c040c12423276a0135c99a1907da2c958e5217c707128863b790529c6edcff87a63452ae66d5462fff05e8f0cc3fa17ad7f55a1fb	\N	0.0000	0.0000	2026-03-09 20:20:12.427576+00	2026-03-09 20:20:12.427576+00	2	\N
107	8	EMP0107	Mehdi Al-Shehri	Laborantin	SUPPORT	ACTIVE	2021-01-01	MONTHLY	t	f	f	1.0000	\\xc30d04070302b9f61b5a110624ab65d23a0178e0da480be33a69e1b4f85260ae91c526d0bb072f5b6056b7c9f38eceeb1c4e32ef3e97955b0f412cba3b212d4992b30dde88f4b56e0bf93e	\\xc30d04070302ea8cc59e97da5db163d23a0183f9bc6ca6d20cfee178b7d4402b546de50c2c819aa72e14b3fafdd7c0aa4f8cb30921e49a1ee5a2e20213413e245ff238a2b8627565688996	\\xc30d04070302dab5206592a89fc173d23901cc25b9de61f77b3f6a5ca2401600e85b76464d812badc739bfd45d468e18fe8bd5e43eec5f2d03fa5c39206c00d8739183b5e402bf3dca5d	\\xc30d04070302964c2f7659d4367766d237018d3e9765719d7f6164e9f69ed15170af7e494336bf2791d1840e0aee628aa5d06fe8264095537cdf6f2e8b38d0e14de6cf8e9b3cc7f5	\\xc30d040703029267e1079457fbdd67d23701c1545176837144ec88bbe8862f3db3e4826c5e32a3ae7f2a87c3c0db2ce537247d05e2b1a010427a9e534c37e335ef7c02b9fc2ed090	\\xc30d04070302be56a49c62f36fe26dd2370114b7f83c20b735d07f59cdc727726465a0a23bc8389b0ab5589d3f2a712507864c7bfc3d071bb29a2e840f145eb22000b3005426de06	\N	0.0000	0.0000	2026-03-09 20:20:12.428249+00	2026-03-09 20:20:12.428249+00	2	\N
108	8	EMP0108	Patricia David	Chauffeur	SUPPORT	ACTIVE	2022-02-01	MONTHLY	t	t	f	1.0000	\\xc30d0407030257616ce930c4c4ab72d23a01ec6253c4c2bf2722e0dc8bac91ecd811c5dda044b4f1471c33cdc16516722bdd28902fbbe02f177f86e1eebd9d915a5a93cbe0fa0b2a3e2cad	\\xc30d0407030213674a5e66e792197ed23a010daa373c9006543fbc127b919a432ac3867d30d80234083abc7c8244f3f3d2173553dfbe55bc31c2e5db2e4a76c89c63dba0c7b0e86ccbb59f	\\xc30d04070302b5ea1b0d393e92716ed23901bec2e30061b94ba550fd97429c50abde3858173f4777a2438fda3ff4d13bf1c74a485fd417c14e7132c18e26dc238ee8b88f51cd4732b0db	\\xc30d04070302c631e1eaec3164017ed2370186fe7d1179246debe1bc4487c3ec7f02a78fbc255dd291e096143895c35ac3bf840a18b4483c527af456edce93a7cbf8bca4fb00ede0	\\xc30d040703023a2406a263d67a8665d23701c47aaba1f84d1b92c8fcf087897e4e26619d782b32b2c0aa44df05a5a21c3ce94cef0cb48906b4896e1df751c3220ad5473c90fcbd56	\\xc30d0407030255b211dc8a906f6a7bd237010291f1e8d42d623646982e625a2ed89559192905aab53e1414bf338c398749a84640f46ceb1a1e6ed1174d949394adfab9ae8b728d69	\N	9600.0000	200.0000	2026-03-09 20:20:12.428872+00	2026-03-09 20:20:12.428872+00	2	\N
109	8	EMP0109	Amine Al-Malki	Chauffeur	SUPPORT	ACTIVE	2023-03-01	MONTHLY	t	t	f	1.0000	\\xc30d040703024aa6830d12c811cd65d23a01e632bd29428b96b37216f949e65a44f3865960e41c769014e69268d14987eceacf1b670a5dce97c7093c153fc74c7ba0b7381845e1eca5fdb0	\\xc30d04070302d8d531ca434c436061d23a01ac952e43c8a4cf859ba225ff6f22d804e52dee4dd433a2d102cadaedf5d3c4f0564ab831574ca1f1fc9852f3373285c8398fdf1b7209de977b	\\xc30d040703020a526dc7e2c5e0ed72d23901fdc97348936002ab0c867bcbd3ba8c2cb99c3942fdf3f2870851df08abf1ef96d2b84ff9eab75222dd446ad5044e5546aee0e3d0ca976fcb	\\xc30d0407030287e937c36954637d77d237016c3b4027c6760796f926d49834b1ef61386be251353d5ffc541a742365084a2d3d69ef8220e735638692f6c34d6e6dbcb7eb17335952	\\xc30d0407030267da47846fc24e3a71d237014c38b93becae83fe002a5838dcc783598617c1312b964ff106821d626c31249aba23b5dda544055ba78043777681e8bdb5f7dfb19742	\\xc30d04070302fe5dae4e326dd1b360d23701f7e5d270f5b10af3c93c077e7500173d55c6127e8e6cd34f872fb6950531b0cd41645b0d17a42e8e0cac1d4110d02829d80215635015	\N	9600.0000	200.0000	2026-03-09 20:20:12.429697+00	2026-03-09 20:20:12.429697+00	2	\N
110	8	EMP0110	Maryam Simon	Agent de Securite	SUPPORT	ACTIVE	2024-04-01	MONTHLY	t	t	f	1.0000	\\xc30d040703029edb8b005898d83171d23a015648b7cee16cadaa06e40b28ae35f9fdeecbadb8528d8e8b23d97c20eca24292e179fff36d8ada8a26d2625a7128edd1e57809b00b46eb2fad	\\xc30d0407030225ff79dd27c8689f7ed23a0162d67c48ee8e76d9cca40e528daf2610d358ac6b27c1868677accbf62108d077030a713c511df6954b1457a32c10ee83d8727a797dd74cdec0	\\xc30d04070302789c916d7e43cd6e6ed239010c5d2368c9a73411c099d82363bec6fbf6467cdd12e6cabddeb5b76d30fdc04780e88a1b39c44fb7de78fc7821e97824de228effd27c09be	\\xc30d0407030267d163c3ba51bf8260d23701c80c5b43930b8a76a26715b1b901d849addbf64a37ab2d82c71695ec65f51718962dbbf13b1a6fb190c930b87cee48f3eb6f17498ac8	\\xc30d04070302d9e345cdf177500b6ed23701af325cc0a0e124250e216c1a24b2eccf83d0f1065a7ea291e9d37f5c20a8cfc517300aeba7c938fd3cdb9908323349db3ea98ddecc3b	\\xc30d04070302a7f2bf291329b33c61d237012a3dac83d184ae0e197e446385421a3384504731ec67a3cb5c54b0d7d6061a324ab122a967fa8fdca33502a5a4e7990c877d11269ec3	\N	9600.0000	200.0000	2026-03-09 20:20:12.430351+00	2026-03-09 20:20:12.430351+00	2	\N
111	8	EMP0111	Tariq Boulanger	Agent de Securite	SUPPORT	ACTIVE	2018-05-01	MONTHLY	t	t	f	1.0000	\\xc30d04070302eebcf4703ca336ef60d23a01384ea42be238e123d0f79d1f9e4eb627bf74032f7983ca854c9bbcae1389fcac69c5322a279c8d6942bd822eff1619e39846956e1146d37e70	\\xc30d040703026b2cdb33e54c467e76d23a015729daebdd84354eb7c18f3b7b884fce2bec39c7b92b6a0b37620f7eb5e6d9cd8582d64aef8b6168022b0468a2f4238e1d845a2118e756a764	\\xc30d04070302f6efb190d44e2a5767d23901ba8673cb7c6bbaad4a687ee8769e31757705ae5812a5444e3093ce4f6d03080d7a1e984e5da75db793bd9ff56c5853594cc8e1c8d536369d	\\xc30d04070302acaafce153f5de8c60d237011221ad676e86b96869aff5ca44c898ba6dc5469aebdfd4200be7e6e248d69310ec69f1976d34888bab7fa034df5c83365844fdbd5fab	\\xc30d04070302c6ca733c013cdc4a6dd23701d3eb6d96178324d0abba6a655b14dac33225ad75e939b25e05593fa523a0501b1bd9258135376be0d75eaa44f69180c5f99bcaa28362	\\xc30d04070302106a853bca30aae067d237014d76a55cc9a1b22b0d47979b5c9157498a4df85a8ddddf1308c4190044bfe31d3a03234cf36017a18054763e778a33addf981d830262	\N	9600.0000	200.0000	2026-03-09 20:20:12.431036+00	2026-03-09 20:20:12.431036+00	2	\N
112	8	EMP0112	Elise Chevalier	Agent de Securite	SUPPORT	ACTIVE	2019-06-01	MONTHLY	t	t	f	1.0000	\\xc30d040703026b18abb7485264777ed23a014d69a63ca822894eb0f9f275da9a99ea94fb7beff825be37d8eba79152f14965f925c1d0472351f292d957bb729af86e6fcf5550b70d353a9c	\\xc30d04070302c5c46fd7ba6d83bd64d23a01416947e159ee0c53512c915879005ea71eb4a7e2d5991b552a457f70a099f52788f23728d05eb66d9f767a97651ad0faa34662389923271fee	\\xc30d04070302e400d61e0d67f4656fd23901428d9bd99db687ef9040879ff22fe8d017743b3687ed446c8b5d2512fcf5b2ec0707f8d3ae3870c106bb45a6206a414fc979d7c572b189c7	\\xc30d04070302e5bf4d31eba09a8f74d2370147364ede04981cfeba5a2fbf4c84bf47ab2ecc331f9065b0c5fca84f85b4ce86656e8c27411fac69d8a942ee7e6f284155d98fa2150b	\\xc30d04070302773fabf260d20cba7dd237017df61c2aa7c9efbcbb89c30b008aff738103b6b48422d9752686b6d0a9ec8056f17f0562ab2db146a41c00e8942f900460aa756f9a4f	\\xc30d040703026e540f7cab4766c166d237010c458e2e72758197a22c46750fab431a4ce8e08d14a1fe3bee360fa6622a49e2af513d74f2d2343d0e7266cded900b394147f0ddb019	\N	9600.0000	200.0000	2026-03-09 20:20:12.431834+00	2026-03-09 20:20:12.431834+00	2	\N
113	8	EMP0113	Walid Al-Ghamdi	Technicien Maintenance	MAINT	ACTIVE	2020-07-01	MONTHLY	t	f	f	1.0000	\\xc30d04070302815c5fcd4cae1eb87bd23a0153545958afb98f941060005d883c48efd20c4a59987491d68e934ff9a45639aebda0e837c2bd8bee47c8dcd4e15909dbc8357b29ad322709bf	\\xc30d0407030266d715786ca913177ad23a01dcab56d095571968b92d5ac4c89a5a9cc0617190e475c304e54495f68496c5643cfa4c6e91949139c619546500c909e44d5a67fee594ac34c5	\\xc30d0407030298f285d6d6f036f769d23901bc87cb303fecb84d2cf440f5f02f5ca1dd183561a68a6f25302d8c6317ba2accef82e3e4871a678422372f150262364a172e4066eb216cd2	\\xc30d040703022e7446df4f05ec2f61d237010ac3c03a2e5a570bd84523006e87a9414bf5a142a9e19d10a097406952eba1bbcc98eb52933ce491d26b6dd849cb435b324e8a9292ab	\\xc30d040703023ea62c614362069a7fd23701cdc493b719f08a561e11fd402db9470093a7a4e9c5f3966a63b64d4f1b125326af4590d281856c85d0aef83bddf8f5bdcbbe194ebd07	\\xc30d040703022fbf2573d1fa5dd76bd2370151ad23c61e6ee12ed2671a8d4ebd8162979f30d690fd82a3bc48dacb13b7e3397a673ec7ad47d9ea52501ccb917816d95cd03748885f	\N	0.0000	0.0000	2026-03-09 20:20:12.4326+00	2026-03-09 20:20:12.4326+00	2	\N
114	8	EMP0114	Hana Fournier	Technicien Maintenance	MAINT	ACTIVE	2021-08-01	MONTHLY	t	f	f	1.0000	\\xc30d0407030231153e1f5eec6e6077d23a01e9a311e4ccf7973d8fe699e6162ffcbb18a0e6d7cb36c37a29851aa6b717608d95e58f4dd2fbc2c463d4994bc50c9b77d229c1fbdb09309e37	\\xc30d04070302d9285c12faadda106ed23a01a34314e77c4d84f46c455af422a186db551dc239b3695a39dcea4013e0dba456764e3b7a4e6557e2b0569b79d9b32bebc6182d0a0a56611c8b	\\xc30d04070302e9800123d7e8039a6dd23901e50da1e3bb30d9f93c6c4105c8aecec252b045c452fda5b76eef356c7e71dbd3334c9c280b2429398a4955e1c81b7bec1dce8dd646d016f4	\\xc30d040703024792beb81e6d43fe7ad23701a77b717907619d081423920e0fa1d8a7584422c74eb046f443dc12b3227510c81e940bbac002d8c6c1ea4e221cf4401713c526b7f6b8	\\xc30d04070302268a5be5397b057875d237017f847a48156592485db1e3c0f543563ef3e43ed7d372f3f052332d6f672592019526380c10e8d0791747f074af05bfde3da9c9ec4905	\\xc30d04070302f83713494ad74cca78d2370194a3ab378c2a09430a1ca0631347b16f52268f60a1dfd355c83f54ae13192fd75213ffa11d43acb5257b1f106bf62fb6768866f56a08	\N	0.0000	0.0000	2026-03-09 20:20:12.433397+00	2026-03-09 20:20:12.433397+00	2	\N
115	8	EMP0115	Bilal Al-Zahrani	Technicien Maintenance	MAINT	ACTIVE	2022-09-01	MONTHLY	t	f	f	1.0000	\\xc30d04070302d57b00d20afd83e072d23a016e28feb5acbe3c643a6151ebb741920507037578f2d04a96ee8d8e9ac315bab6ab6d9669c183128bdcb8300a9f79a5f677a6226f3dbeed81ae	\\xc30d04070302fd3556ea38c7740369d23a01df0c735b7eae9d81b2e223c2f314a82426de0cdd5201eaddad098afcae3bde48dba16bd6b11bc4a63549717865ca95225c9717dd38129583ae	\\xc30d040703026edccf2a1675a2147bd239016a71eeb658b2fe5ee0ddd766ceae18c301fa6351d504a110a899bafd29cfe3200b2e83cd4943cbbfce29f3e83e709bc9314339d95dc2c3ba	\\xc30d040703021bd50d4b0410782878d23701c69a9553b94a8a7c319502159f7984837ad3bd4997896a95ea549a8d8cd51ddcde1cef665e72716490c41d0325adc7eea8ac95be3849	\\xc30d04070302276ca30c5468936e6fd2370177eb3bfcbfd0e218ddb01a9f1b704bd083921df3e51e268b184dec1aec1f3c6972317e777877f34f4503dfc7a396411e0e17e9bd747e	\\xc30d0407030293869cc52711a22e68d23701178d4e0ed53d17bd3d92f0f069cd09fe4e22a413043d3f28c886897375462edef24c1f8f9e168758af1154262f415ea8ef1ce3fa77bf	\N	0.0000	0.0000	2026-03-09 20:20:12.434384+00	2026-03-09 20:20:12.434384+00	2	\N
116	8	EMP0116	Lina Girard	Agent Entretien	MAINT	ACTIVE	2023-01-01	MONTHLY	f	t	f	1.0000	\\xc30d04070302c751a503c0a100386dd23a01f9361c19bd282fdd9a23249cc5ae2c79b56cf16194c0329496371e0e55642727f02184cd208c8015878d67d4bac636d720a9304f4636117a94	\\xc30d040703025b625385a55ea0be64d23a01a6d7d3004ae0318785268d8bc662d6e2d4f58e8fff64bf23fb63e8b652c8e0178a929d4f5615f29742953090cd813d85207200cc6314db45ce	\\xc30d04070302cb8505b2a6b1d18a7fd23901748b07169b715ee8b23559dfb35280f868b0bc95026200bab2631998e26e504705a9e4a7055f815ad27ad970615e38cb8dc66deb49b6b5e6	\\xc30d040703022228f462fe58544b76d23701fb1a4524429350f5d1aee72faa871dbcb0a963ba74f1b7b2d2cb1bace227ccd73f731a64b03964a0a45ad17f0dd9f98a2e24b978f3f1	\\xc30d04070302198b51fc6c5a5d566bd2370163ba723c198ba5bbe5beeff398f108f76a8ec1d241435a2aba5de86c6612c11497c5b5c8c786f39daabfcfb767e9574c778aa90475cb	\\xc30d040703027a8437e85396832161d2370113697391b62af20a47be3637f72d63eb8c89fecea90267aca605a81659c243347e8892c1aa01d2afaf37d6e7a9aaba61acc13b7cb8e8	\N	9600.0000	200.0000	2026-03-09 20:20:12.43519+00	2026-03-09 20:20:12.43519+00	2	\N
117	8	EMP0117	Hamza Al-Otaibi	Agent Entretien	MAINT	ACTIVE	2024-02-01	MONTHLY	f	t	f	1.0000	\\xc30d04070302f75ddf2e565979b16cd23a012bcf612dd63026d9567d0daa7c0562ab79a6f0626f82434a69f19280c0b309b7f3d6cdde363c4339388974d54f0d2045c0cfde0da05d9afb7f	\\xc30d040703027613d5a87c17cd156bd23a014b3c5aebdf092b22bce8a954222940df1037300bb1ed2c3b72f2e7ff159f98267566a6702f7bc463cca990fa4333df4d1068e2fde30a35698b	\\xc30d04070302299912954cfc72c667d2390184034f51da2381d9747d6423b816844d07d34a6540c45d57b59c25ea4300a353969f5c909699025e4b39aff9f8ef6a3d9366a709212f50e4	\\xc30d04070302534d99f5157fb10b7ad23701c0f7ccd49f5ddc4f203499d23cd15255c5a9044d225a009e8135f8a7d7fba7203ecc0eb747a7aa5ea8fd0d08cc97870804e5eacec67f	\\xc30d04070302d6c9fc0d342ad6bd79d237015d07bb548cb7865d059e94cbe08e950ea23989d7158c97e7a2e15b67d2920e30a2743f30ed2b8411b1c32dd0918b4a78cb240b0e5cc2	\\xc30d0407030213d3c0200bdd68c472d23701c615636d56c432b01dd3d0e6b5e8bdf7f5eed336ec58a507d3ebe85bc7e9df6e6aaba6ff5baa4ebe5be26b5e9a4b8e7673375dded46b	\N	9600.0000	200.0000	2026-03-09 20:20:12.435942+00	2026-03-09 20:20:12.435942+00	2	\N
118	8	EMP0118	Chloe Andre	Agent Entretien	MAINT	ACTIVE	2018-03-01	MONTHLY	f	t	f	1.0000	\\xc30d04070302c5a1528e3b91775462d23a012e43ba6930ff4862a2c5be2f7694379286b525e90765a57c6cf92b2d6b6a4c3dda21ecd82b36ab526487184a31b92bff4b264299f4c1fcce3a	\\xc30d040703020b77faf370aeba6e66d23a01fd4130b89dca27eb3266181369ffb0614123c0b678d0aba2e74af0fcebf41d00a029083d031b68f556ad94787e6f5a9acf42ac0e7e5cac6827	\\xc30d040703024c9d464f759a7e6769d2390193a83859196c8cf0a24043bc8321bec1562e7bc5cf5f0268a9ad46273905c099f92743eef82fd2169a3aaa6bfacab890ab69eacf7c9ceb79	\\xc30d040703021030c5f8b3a5b4fc67d237010ec3e48d6f19a429f5c926537c746236f8bab2891884e6a5da46b12c26ba03252feddcbe09da28ba68f8b788abaa98855a822aaa4bf6	\\xc30d040703024aa4b90aad9401e46bd23701cb40745e38685898ac4fb42c3491fa50676d5c91c630867ec567fa7fb908140736eebf547f1e2a673947aeb845888421d8f1896c54bb	\\xc30d0407030264992102ebd99ebb64d2370102f4d5c32a11349223a33de030099bfa637ab517b0ead85b52fd29b32a00556523ccd348f3889ff8bf9943b30ac3b90d939f9bcdbbb2	\N	9600.0000	200.0000	2026-03-09 20:20:12.436673+00	2026-03-09 20:20:12.436673+00	2	\N
119	8	EMP0119	Faisal Al-Tamimi	Agent Entretien	MAINT	ACTIVE	2019-04-01	MONTHLY	f	t	f	1.0000	\\xc30d04070302581e8210159c2f3160d23a01f2775a210574603fcb4c018a97b373235c9239a26c29dd1aa554b4eb95844bbc85895d69179683f879c0f1366a5e7e1b5ee1d610cb158356f4	\\xc30d04070302c3bf8259ca67ddbc61d23a015d8cbbee9bf5059bfab347182d03dedc1b71eb375d2882f426cde2e7b3f8c1f1776a598a3e54f0a527d5d9c147c5d5da0ecc2cb9444373c9c4	\\xc30d040703023cb3d270d78a0ae463d23901646fe8be216ff70c6dccd0d14ebc8a27d77490533ace1084ca99c1ed9b9125a4be095233d742d3d9b76d366add684be70b30ba9517e1ef42	\\xc30d0407030299509ba05a24ac3577d237011a2bcb433466038970927b788da0ad6d1028a434463ea9fc79a08a5fd6d506373cd61052d27dc9a8bfdfbff9d3084dc6136e4ecf9768	\\xc30d04070302722c6dfefe72b92365d23701a1fffc0c2bd4e9ca66b3734c12fb8500ff7f08e68e5229540146cab6a89e854406441a42f07ace92d2ff5a0a3a8c1fdbdd4199a318a3	\\xc30d04070302ee01b8f3e6b20d6178d2370180b28f40755b2e99ce20abb1b2afa3350f50e911a3de3bb731009ac48c98de4d6be664fdb182bbe3bc320de411252636d59f38708b35	\N	9600.0000	200.0000	2026-03-09 20:20:12.437295+00	2026-03-09 20:20:12.437295+00	2	\N
120	8	EMP0120	Marie Dupont	Agent Entretien	MAINT	ACTIVE	2020-05-01	MONTHLY	f	t	f	1.0000	\\xc30d04070302a0ffd14c2edac1b868d23a01829e6d14af1dba298232a014c6624defb6b04791001211a9a98aa332ff707c2ed3460c6defe37554df6a33fdc1e9c2f2b8206e20b3734eed16	\\xc30d04070302377d4fecc06e1e5f62d23a017c1f9deef0e185e454a4874beb29dadd89ffb05eb05311a8b678b771c86597ce2a8bc3868898bb54feac03f5afab04c73c7e7a7477728658cc	\\xc30d040703020d1e8bdcc624f6bc6bd23901e3e9ffc9d3c5a25edde7cd8190865942bf1b35a11884e8a8b32f8768e32b936c5ee7128aeceb4ae935840121966a9e30032e7ca01cc06210	\\xc30d04070302ad0b0b131cb185986ed2370180c15729889ac16c9f03d4f401c17e96802aba7765e9bae2d6a111a715fba743b40ca03b0d9a595714a66e4149ced5d7cd0999232e70	\\xc30d04070302d992a17fe4c622977dd237016ceae6a4ef9002fdafe8001a342effeaf207dae522652a820d76254f41d7e1b7ec6038f3c1ada3b88d31982fc6fb3fbe062fe760794f	\\xc30d04070302468c5ebad5c42fbb74d2370133d0c8b16efc52fc4e436e039a3a8c78fb05a66e87a2b87c8630030d6370f419e6a4e81586d4dcacfb5b33bb8c522c016dae2fd2937f	\N	9600.0000	200.0000	2026-03-09 20:20:12.437959+00	2026-03-09 20:20:12.437959+00	2	\N
\.


--
-- Data for Name: enrollment_detail; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.enrollment_detail (id, version_id, academic_period, grade_level, nationality, tariff, headcount, created_at, updated_at, created_by, updated_by) FROM stdin;
215	8	AY1	PS	FR	PLEIN	39	2026-03-09 20:20:12.045+00	2026-03-09 20:20:12.045+00	2	\N
216	8	AY1	PS	FR	RP	6	2026-03-09 20:20:12.046+00	2026-03-09 20:20:12.046+00	2	\N
217	8	AY1	PS	FR	R3P	5	2026-03-09 20:20:12.047+00	2026-03-09 20:20:12.047+00	2	\N
218	8	AY1	PS	NAT	PLEIN	25	2026-03-09 20:20:12.047+00	2026-03-09 20:20:12.047+00	2	\N
219	8	AY1	PS	NAT	RP	4	2026-03-09 20:20:12.048+00	2026-03-09 20:20:12.048+00	2	\N
220	8	AY1	PS	AUT	PLEIN	18	2026-03-09 20:20:12.048+00	2026-03-09 20:20:12.048+00	2	\N
221	8	AY1	PS	AUT	RP	3	2026-03-09 20:20:12.049+00	2026-03-09 20:20:12.049+00	2	\N
222	8	AY1	MS	FR	PLEIN	41	2026-03-09 20:20:12.049+00	2026-03-09 20:20:12.049+00	2	\N
223	8	AY1	MS	FR	RP	6	2026-03-09 20:20:12.049+00	2026-03-09 20:20:12.049+00	2	\N
224	8	AY1	MS	FR	R3P	5	2026-03-09 20:20:12.05+00	2026-03-09 20:20:12.05+00	2	\N
225	8	AY1	MS	NAT	PLEIN	25	2026-03-09 20:20:12.05+00	2026-03-09 20:20:12.05+00	2	\N
226	8	AY1	MS	NAT	RP	4	2026-03-09 20:20:12.051+00	2026-03-09 20:20:12.051+00	2	\N
227	8	AY1	MS	AUT	PLEIN	19	2026-03-09 20:20:12.051+00	2026-03-09 20:20:12.051+00	2	\N
228	8	AY1	MS	AUT	RP	3	2026-03-09 20:20:12.052+00	2026-03-09 20:20:12.052+00	2	\N
229	8	AY1	GS	FR	PLEIN	42	2026-03-09 20:20:12.052+00	2026-03-09 20:20:12.052+00	2	\N
230	8	AY1	GS	FR	RP	6	2026-03-09 20:20:12.052+00	2026-03-09 20:20:12.052+00	2	\N
231	8	AY1	GS	FR	R3P	5	2026-03-09 20:20:12.053+00	2026-03-09 20:20:12.053+00	2	\N
232	8	AY1	GS	NAT	PLEIN	26	2026-03-09 20:20:12.053+00	2026-03-09 20:20:12.053+00	2	\N
233	8	AY1	GS	NAT	RP	4	2026-03-09 20:20:12.054+00	2026-03-09 20:20:12.054+00	2	\N
234	8	AY1	GS	AUT	PLEIN	19	2026-03-09 20:20:12.054+00	2026-03-09 20:20:12.054+00	2	\N
235	8	AY1	GS	AUT	RP	4	2026-03-09 20:20:12.055+00	2026-03-09 20:20:12.055+00	2	\N
236	8	AY1	CP	FR	PLEIN	42	2026-03-09 20:20:12.055+00	2026-03-09 20:20:12.055+00	2	\N
237	8	AY1	CP	FR	RP	6	2026-03-09 20:20:12.056+00	2026-03-09 20:20:12.056+00	2	\N
238	8	AY1	CP	FR	R3P	5	2026-03-09 20:20:12.056+00	2026-03-09 20:20:12.056+00	2	\N
239	8	AY1	CP	NAT	PLEIN	26	2026-03-09 20:20:12.057+00	2026-03-09 20:20:12.057+00	2	\N
240	8	AY1	CP	NAT	RP	4	2026-03-09 20:20:12.057+00	2026-03-09 20:20:12.057+00	2	\N
241	8	AY1	CP	NAT	R3P	3	2026-03-09 20:20:12.058+00	2026-03-09 20:20:12.058+00	2	\N
242	8	AY1	CP	AUT	PLEIN	19	2026-03-09 20:20:12.058+00	2026-03-09 20:20:12.058+00	2	\N
243	8	AY1	CP	AUT	RP	5	2026-03-09 20:20:12.058+00	2026-03-09 20:20:12.058+00	2	\N
244	8	AY1	CE1	FR	PLEIN	43	2026-03-09 20:20:12.059+00	2026-03-09 20:20:12.059+00	2	\N
245	8	AY1	CE1	FR	RP	7	2026-03-09 20:20:12.059+00	2026-03-09 20:20:12.059+00	2	\N
246	8	AY1	CE1	FR	R3P	6	2026-03-09 20:20:12.06+00	2026-03-09 20:20:12.06+00	2	\N
247	8	AY1	CE1	NAT	PLEIN	27	2026-03-09 20:20:12.06+00	2026-03-09 20:20:12.06+00	2	\N
248	8	AY1	CE1	NAT	RP	4	2026-03-09 20:20:12.06+00	2026-03-09 20:20:12.06+00	2	\N
249	8	AY1	CE1	NAT	R3P	3	2026-03-09 20:20:12.061+00	2026-03-09 20:20:12.061+00	2	\N
250	8	AY1	CE1	AUT	PLEIN	20	2026-03-09 20:20:12.061+00	2026-03-09 20:20:12.061+00	2	\N
251	8	AY1	CE1	AUT	RP	3	2026-03-09 20:20:12.062+00	2026-03-09 20:20:12.062+00	2	\N
252	8	AY1	CE2	FR	PLEIN	44	2026-03-09 20:20:12.062+00	2026-03-09 20:20:12.062+00	2	\N
253	8	AY1	CE2	FR	RP	7	2026-03-09 20:20:12.062+00	2026-03-09 20:20:12.062+00	2	\N
254	8	AY1	CE2	FR	R3P	6	2026-03-09 20:20:12.063+00	2026-03-09 20:20:12.063+00	2	\N
255	8	AY1	CE2	NAT	PLEIN	28	2026-03-09 20:20:12.064+00	2026-03-09 20:20:12.064+00	2	\N
256	8	AY1	CE2	NAT	RP	4	2026-03-09 20:20:12.064+00	2026-03-09 20:20:12.064+00	2	\N
257	8	AY1	CE2	NAT	R3P	4	2026-03-09 20:20:12.064+00	2026-03-09 20:20:12.064+00	2	\N
258	8	AY1	CE2	AUT	PLEIN	20	2026-03-09 20:20:12.065+00	2026-03-09 20:20:12.065+00	2	\N
259	8	AY1	CE2	AUT	RP	3	2026-03-09 20:20:12.065+00	2026-03-09 20:20:12.065+00	2	\N
260	8	AY1	CM1	FR	PLEIN	46	2026-03-09 20:20:12.066+00	2026-03-09 20:20:12.066+00	2	\N
261	8	AY1	CM1	FR	RP	7	2026-03-09 20:20:12.066+00	2026-03-09 20:20:12.066+00	2	\N
262	8	AY1	CM1	FR	R3P	6	2026-03-09 20:20:12.066+00	2026-03-09 20:20:12.066+00	2	\N
263	8	AY1	CM1	NAT	PLEIN	28	2026-03-09 20:20:12.067+00	2026-03-09 20:20:12.067+00	2	\N
264	8	AY1	CM1	NAT	RP	4	2026-03-09 20:20:12.067+00	2026-03-09 20:20:12.067+00	2	\N
265	8	AY1	CM1	NAT	R3P	4	2026-03-09 20:20:12.068+00	2026-03-09 20:20:12.068+00	2	\N
266	8	AY1	CM1	AUT	PLEIN	21	2026-03-09 20:20:12.068+00	2026-03-09 20:20:12.068+00	2	\N
267	8	AY1	CM1	AUT	RP	3	2026-03-09 20:20:12.068+00	2026-03-09 20:20:12.068+00	2	\N
268	8	AY1	CM2	FR	PLEIN	47	2026-03-09 20:20:12.069+00	2026-03-09 20:20:12.069+00	2	\N
269	8	AY1	CM2	FR	RP	7	2026-03-09 20:20:12.069+00	2026-03-09 20:20:12.069+00	2	\N
270	8	AY1	CM2	FR	R3P	6	2026-03-09 20:20:12.07+00	2026-03-09 20:20:12.07+00	2	\N
271	8	AY1	CM2	NAT	PLEIN	29	2026-03-09 20:20:12.07+00	2026-03-09 20:20:12.07+00	2	\N
272	8	AY1	CM2	NAT	RP	4	2026-03-09 20:20:12.071+00	2026-03-09 20:20:12.071+00	2	\N
273	8	AY1	CM2	NAT	R3P	4	2026-03-09 20:20:12.071+00	2026-03-09 20:20:12.071+00	2	\N
274	8	AY1	CM2	AUT	PLEIN	21	2026-03-09 20:20:12.071+00	2026-03-09 20:20:12.071+00	2	\N
275	8	AY1	CM2	AUT	RP	4	2026-03-09 20:20:12.072+00	2026-03-09 20:20:12.072+00	2	\N
276	8	AY1	6EME	FR	PLEIN	50	2026-03-09 20:20:12.072+00	2026-03-09 20:20:12.072+00	2	\N
277	8	AY1	6EME	FR	RP	8	2026-03-09 20:20:12.073+00	2026-03-09 20:20:12.073+00	2	\N
278	8	AY1	6EME	FR	R3P	6	2026-03-09 20:20:12.073+00	2026-03-09 20:20:12.073+00	2	\N
279	8	AY1	6EME	NAT	PLEIN	31	2026-03-09 20:20:12.073+00	2026-03-09 20:20:12.073+00	2	\N
280	8	AY1	6EME	NAT	RP	5	2026-03-09 20:20:12.074+00	2026-03-09 20:20:12.074+00	2	\N
281	8	AY1	6EME	NAT	R3P	4	2026-03-09 20:20:12.074+00	2026-03-09 20:20:12.074+00	2	\N
282	8	AY1	6EME	AUT	PLEIN	23	2026-03-09 20:20:12.075+00	2026-03-09 20:20:12.075+00	2	\N
283	8	AY1	6EME	AUT	RP	4	2026-03-09 20:20:12.075+00	2026-03-09 20:20:12.075+00	2	\N
284	8	AY1	5EME	FR	PLEIN	51	2026-03-09 20:20:12.075+00	2026-03-09 20:20:12.075+00	2	\N
285	8	AY1	5EME	FR	RP	8	2026-03-09 20:20:12.076+00	2026-03-09 20:20:12.076+00	2	\N
286	8	AY1	5EME	FR	R3P	7	2026-03-09 20:20:12.076+00	2026-03-09 20:20:12.076+00	2	\N
287	8	AY1	5EME	NAT	PLEIN	32	2026-03-09 20:20:12.076+00	2026-03-09 20:20:12.076+00	2	\N
288	8	AY1	5EME	NAT	RP	5	2026-03-09 20:20:12.077+00	2026-03-09 20:20:12.077+00	2	\N
289	8	AY1	5EME	NAT	R3P	4	2026-03-09 20:20:12.077+00	2026-03-09 20:20:12.077+00	2	\N
290	8	AY1	5EME	AUT	PLEIN	24	2026-03-09 20:20:12.078+00	2026-03-09 20:20:12.078+00	2	\N
291	8	AY1	5EME	AUT	RP	3	2026-03-09 20:20:12.078+00	2026-03-09 20:20:12.078+00	2	\N
292	8	AY1	4EME	FR	PLEIN	52	2026-03-09 20:20:12.078+00	2026-03-09 20:20:12.078+00	2	\N
293	8	AY1	4EME	FR	RP	8	2026-03-09 20:20:12.079+00	2026-03-09 20:20:12.079+00	2	\N
294	8	AY1	4EME	FR	R3P	7	2026-03-09 20:20:12.079+00	2026-03-09 20:20:12.079+00	2	\N
295	8	AY1	4EME	NAT	PLEIN	33	2026-03-09 20:20:12.079+00	2026-03-09 20:20:12.079+00	2	\N
296	8	AY1	4EME	NAT	RP	5	2026-03-09 20:20:12.08+00	2026-03-09 20:20:12.08+00	2	\N
297	8	AY1	4EME	NAT	R3P	4	2026-03-09 20:20:12.08+00	2026-03-09 20:20:12.08+00	2	\N
298	8	AY1	4EME	AUT	PLEIN	24	2026-03-09 20:20:12.081+00	2026-03-09 20:20:12.081+00	2	\N
299	8	AY1	4EME	AUT	RP	4	2026-03-09 20:20:12.081+00	2026-03-09 20:20:12.081+00	2	\N
300	8	AY1	3EME	FR	PLEIN	53	2026-03-09 20:20:12.082+00	2026-03-09 20:20:12.082+00	2	\N
301	8	AY1	3EME	FR	RP	8	2026-03-09 20:20:12.082+00	2026-03-09 20:20:12.082+00	2	\N
302	8	AY1	3EME	FR	R3P	7	2026-03-09 20:20:12.082+00	2026-03-09 20:20:12.082+00	2	\N
303	8	AY1	3EME	NAT	PLEIN	33	2026-03-09 20:20:12.083+00	2026-03-09 20:20:12.083+00	2	\N
304	8	AY1	3EME	NAT	RP	5	2026-03-09 20:20:12.083+00	2026-03-09 20:20:12.083+00	2	\N
305	8	AY1	3EME	NAT	R3P	4	2026-03-09 20:20:12.084+00	2026-03-09 20:20:12.084+00	2	\N
306	8	AY1	3EME	AUT	PLEIN	24	2026-03-09 20:20:12.084+00	2026-03-09 20:20:12.084+00	2	\N
307	8	AY1	3EME	AUT	RP	5	2026-03-09 20:20:12.084+00	2026-03-09 20:20:12.084+00	2	\N
308	8	AY1	2NDE	FR	PLEIN	48	2026-03-09 20:20:12.085+00	2026-03-09 20:20:12.085+00	2	\N
309	8	AY1	2NDE	FR	RP	7	2026-03-09 20:20:12.085+00	2026-03-09 20:20:12.085+00	2	\N
310	8	AY1	2NDE	FR	R3P	6	2026-03-09 20:20:12.086+00	2026-03-09 20:20:12.086+00	2	\N
311	8	AY1	2NDE	NAT	PLEIN	30	2026-03-09 20:20:12.086+00	2026-03-09 20:20:12.086+00	2	\N
312	8	AY1	2NDE	NAT	RP	5	2026-03-09 20:20:12.086+00	2026-03-09 20:20:12.086+00	2	\N
313	8	AY1	2NDE	NAT	R3P	4	2026-03-09 20:20:12.087+00	2026-03-09 20:20:12.087+00	2	\N
314	8	AY1	2NDE	AUT	PLEIN	22	2026-03-09 20:20:12.087+00	2026-03-09 20:20:12.087+00	2	\N
315	8	AY1	2NDE	AUT	RP	3	2026-03-09 20:20:12.087+00	2026-03-09 20:20:12.087+00	2	\N
316	8	AY1	1ERE	FR	PLEIN	46	2026-03-09 20:20:12.088+00	2026-03-09 20:20:12.088+00	2	\N
317	8	AY1	1ERE	FR	RP	7	2026-03-09 20:20:12.088+00	2026-03-09 20:20:12.088+00	2	\N
318	8	AY1	1ERE	FR	R3P	6	2026-03-09 20:20:12.089+00	2026-03-09 20:20:12.089+00	2	\N
319	8	AY1	1ERE	NAT	PLEIN	29	2026-03-09 20:20:12.089+00	2026-03-09 20:20:12.089+00	2	\N
320	8	AY1	1ERE	NAT	RP	4	2026-03-09 20:20:12.089+00	2026-03-09 20:20:12.089+00	2	\N
321	8	AY1	1ERE	NAT	R3P	4	2026-03-09 20:20:12.09+00	2026-03-09 20:20:12.09+00	2	\N
322	8	AY1	1ERE	AUT	PLEIN	21	2026-03-09 20:20:12.09+00	2026-03-09 20:20:12.09+00	2	\N
323	8	AY1	1ERE	AUT	RP	3	2026-03-09 20:20:12.091+00	2026-03-09 20:20:12.091+00	2	\N
324	8	AY1	TERM	FR	PLEIN	30	2026-03-09 20:20:12.091+00	2026-03-09 20:20:12.091+00	2	\N
325	8	AY1	TERM	FR	RP	5	2026-03-09 20:20:12.091+00	2026-03-09 20:20:12.091+00	2	\N
326	8	AY1	TERM	FR	R3P	4	2026-03-09 20:20:12.092+00	2026-03-09 20:20:12.092+00	2	\N
327	8	AY1	TERM	NAT	PLEIN	19	2026-03-09 20:20:12.092+00	2026-03-09 20:20:12.092+00	2	\N
328	8	AY1	TERM	NAT	RP	3	2026-03-09 20:20:12.093+00	2026-03-09 20:20:12.093+00	2	\N
329	8	AY1	TERM	NAT	R3P	2	2026-03-09 20:20:12.093+00	2026-03-09 20:20:12.093+00	2	\N
330	8	AY1	TERM	AUT	PLEIN	14	2026-03-09 20:20:12.093+00	2026-03-09 20:20:12.093+00	2	\N
331	8	AY1	TERM	AUT	RP	1	2026-03-09 20:20:12.094+00	2026-03-09 20:20:12.094+00	2	\N
332	8	AY2	PS	FR	PLEIN	40	2026-03-09 20:20:12.094+00	2026-03-09 20:20:12.094+00	2	\N
333	8	AY2	PS	FR	RP	6	2026-03-09 20:20:12.094+00	2026-03-09 20:20:12.094+00	2	\N
334	8	AY2	PS	FR	R3P	5	2026-03-09 20:20:12.095+00	2026-03-09 20:20:12.095+00	2	\N
335	8	AY2	PS	NAT	PLEIN	25	2026-03-09 20:20:12.095+00	2026-03-09 20:20:12.095+00	2	\N
336	8	AY2	PS	AUT	PLEIN	19	2026-03-09 20:20:12.096+00	2026-03-09 20:20:12.096+00	2	\N
337	8	AY2	MS	FR	PLEIN	41	2026-03-09 20:20:12.096+00	2026-03-09 20:20:12.096+00	2	\N
338	8	AY2	MS	FR	RP	6	2026-03-09 20:20:12.096+00	2026-03-09 20:20:12.096+00	2	\N
339	8	AY2	MS	FR	R3P	5	2026-03-09 20:20:12.097+00	2026-03-09 20:20:12.097+00	2	\N
340	8	AY2	MS	NAT	PLEIN	26	2026-03-09 20:20:12.097+00	2026-03-09 20:20:12.097+00	2	\N
341	8	AY2	MS	AUT	PLEIN	20	2026-03-09 20:20:12.097+00	2026-03-09 20:20:12.097+00	2	\N
342	8	AY2	GS	FR	PLEIN	45	2026-03-09 20:20:12.098+00	2026-03-09 20:20:12.098+00	2	\N
343	8	AY2	GS	FR	RP	7	2026-03-09 20:20:12.098+00	2026-03-09 20:20:12.098+00	2	\N
344	8	AY2	GS	NAT	PLEIN	28	2026-03-09 20:20:12.099+00	2026-03-09 20:20:12.099+00	2	\N
345	8	AY2	GS	AUT	PLEIN	21	2026-03-09 20:20:12.099+00	2026-03-09 20:20:12.099+00	2	\N
346	8	AY2	CP	FR	PLEIN	41	2026-03-09 20:20:12.099+00	2026-03-09 20:20:12.099+00	2	\N
347	8	AY2	CP	FR	RP	6	2026-03-09 20:20:12.1+00	2026-03-09 20:20:12.1+00	2	\N
348	8	AY2	CP	FR	R3P	5	2026-03-09 20:20:12.1+00	2026-03-09 20:20:12.1+00	2	\N
349	8	AY2	CP	NAT	PLEIN	26	2026-03-09 20:20:12.1+00	2026-03-09 20:20:12.1+00	2	\N
350	8	AY2	CP	NAT	RP	4	2026-03-09 20:20:12.101+00	2026-03-09 20:20:12.101+00	2	\N
351	8	AY2	CP	NAT	R3P	3	2026-03-09 20:20:12.101+00	2026-03-09 20:20:12.101+00	2	\N
352	8	AY2	CP	AUT	PLEIN	20	2026-03-09 20:20:12.102+00	2026-03-09 20:20:12.102+00	2	\N
353	8	AY2	CE1	FR	PLEIN	42	2026-03-09 20:20:12.102+00	2026-03-09 20:20:12.102+00	2	\N
354	8	AY2	CE1	FR	RP	6	2026-03-09 20:20:12.102+00	2026-03-09 20:20:12.102+00	2	\N
355	8	AY2	CE1	FR	R3P	5	2026-03-09 20:20:12.103+00	2026-03-09 20:20:12.103+00	2	\N
356	8	AY2	CE1	NAT	PLEIN	26	2026-03-09 20:20:12.103+00	2026-03-09 20:20:12.103+00	2	\N
357	8	AY2	CE1	NAT	RP	4	2026-03-09 20:20:12.104+00	2026-03-09 20:20:12.104+00	2	\N
358	8	AY2	CE1	NAT	R3P	3	2026-03-09 20:20:12.104+00	2026-03-09 20:20:12.104+00	2	\N
359	8	AY2	CE1	AUT	PLEIN	21	2026-03-09 20:20:12.104+00	2026-03-09 20:20:12.104+00	2	\N
360	8	AY2	CE2	FR	PLEIN	43	2026-03-09 20:20:12.105+00	2026-03-09 20:20:12.105+00	2	\N
361	8	AY2	CE2	FR	RP	7	2026-03-09 20:20:12.105+00	2026-03-09 20:20:12.105+00	2	\N
362	8	AY2	CE2	FR	R3P	6	2026-03-09 20:20:12.105+00	2026-03-09 20:20:12.105+00	2	\N
363	8	AY2	CE2	NAT	PLEIN	27	2026-03-09 20:20:12.106+00	2026-03-09 20:20:12.106+00	2	\N
364	8	AY2	CE2	NAT	RP	4	2026-03-09 20:20:12.106+00	2026-03-09 20:20:12.106+00	2	\N
365	8	AY2	CE2	NAT	R3P	3	2026-03-09 20:20:12.107+00	2026-03-09 20:20:12.107+00	2	\N
366	8	AY2	CE2	AUT	PLEIN	20	2026-03-09 20:20:12.107+00	2026-03-09 20:20:12.107+00	2	\N
367	8	AY2	CM1	FR	PLEIN	44	2026-03-09 20:20:12.107+00	2026-03-09 20:20:12.107+00	2	\N
368	8	AY2	CM1	FR	RP	7	2026-03-09 20:20:12.108+00	2026-03-09 20:20:12.108+00	2	\N
369	8	AY2	CM1	FR	R3P	6	2026-03-09 20:20:12.108+00	2026-03-09 20:20:12.108+00	2	\N
370	8	AY2	CM1	NAT	PLEIN	28	2026-03-09 20:20:12.108+00	2026-03-09 20:20:12.108+00	2	\N
371	8	AY2	CM1	NAT	RP	4	2026-03-09 20:20:12.109+00	2026-03-09 20:20:12.109+00	2	\N
372	8	AY2	CM1	NAT	R3P	4	2026-03-09 20:20:12.109+00	2026-03-09 20:20:12.109+00	2	\N
373	8	AY2	CM1	AUT	PLEIN	20	2026-03-09 20:20:12.109+00	2026-03-09 20:20:12.109+00	2	\N
374	8	AY2	CM2	FR	PLEIN	46	2026-03-09 20:20:12.11+00	2026-03-09 20:20:12.11+00	2	\N
375	8	AY2	CM2	FR	RP	7	2026-03-09 20:20:12.11+00	2026-03-09 20:20:12.11+00	2	\N
376	8	AY2	CM2	FR	R3P	6	2026-03-09 20:20:12.111+00	2026-03-09 20:20:12.111+00	2	\N
377	8	AY2	CM2	NAT	PLEIN	29	2026-03-09 20:20:12.111+00	2026-03-09 20:20:12.111+00	2	\N
378	8	AY2	CM2	NAT	RP	4	2026-03-09 20:20:12.111+00	2026-03-09 20:20:12.111+00	2	\N
379	8	AY2	CM2	NAT	R3P	4	2026-03-09 20:20:12.112+00	2026-03-09 20:20:12.112+00	2	\N
380	8	AY2	CM2	AUT	PLEIN	20	2026-03-09 20:20:12.112+00	2026-03-09 20:20:12.112+00	2	\N
381	8	AY2	6EME	FR	PLEIN	49	2026-03-09 20:20:12.113+00	2026-03-09 20:20:12.113+00	2	\N
382	8	AY2	6EME	FR	RP	8	2026-03-09 20:20:12.113+00	2026-03-09 20:20:12.113+00	2	\N
383	8	AY2	6EME	FR	R3P	6	2026-03-09 20:20:12.113+00	2026-03-09 20:20:12.113+00	2	\N
384	8	AY2	6EME	NAT	PLEIN	30	2026-03-09 20:20:12.114+00	2026-03-09 20:20:12.114+00	2	\N
385	8	AY2	6EME	NAT	RP	5	2026-03-09 20:20:12.114+00	2026-03-09 20:20:12.114+00	2	\N
386	8	AY2	6EME	NAT	R3P	4	2026-03-09 20:20:12.114+00	2026-03-09 20:20:12.114+00	2	\N
387	8	AY2	6EME	AUT	PLEIN	22	2026-03-09 20:20:12.115+00	2026-03-09 20:20:12.115+00	2	\N
388	8	AY2	5EME	FR	PLEIN	50	2026-03-09 20:20:12.115+00	2026-03-09 20:20:12.115+00	2	\N
389	8	AY2	5EME	FR	RP	8	2026-03-09 20:20:12.116+00	2026-03-09 20:20:12.116+00	2	\N
390	8	AY2	5EME	FR	R3P	6	2026-03-09 20:20:12.116+00	2026-03-09 20:20:12.116+00	2	\N
391	8	AY2	5EME	NAT	PLEIN	31	2026-03-09 20:20:12.116+00	2026-03-09 20:20:12.116+00	2	\N
392	8	AY2	5EME	NAT	RP	5	2026-03-09 20:20:12.117+00	2026-03-09 20:20:12.117+00	2	\N
393	8	AY2	5EME	NAT	R3P	4	2026-03-09 20:20:12.117+00	2026-03-09 20:20:12.117+00	2	\N
394	8	AY2	5EME	AUT	PLEIN	23	2026-03-09 20:20:12.117+00	2026-03-09 20:20:12.117+00	2	\N
395	8	AY2	4EME	FR	PLEIN	51	2026-03-09 20:20:12.118+00	2026-03-09 20:20:12.118+00	2	\N
396	8	AY2	4EME	FR	RP	8	2026-03-09 20:20:12.118+00	2026-03-09 20:20:12.118+00	2	\N
397	8	AY2	4EME	FR	R3P	7	2026-03-09 20:20:12.119+00	2026-03-09 20:20:12.119+00	2	\N
398	8	AY2	4EME	NAT	PLEIN	32	2026-03-09 20:20:12.119+00	2026-03-09 20:20:12.119+00	2	\N
399	8	AY2	4EME	NAT	RP	5	2026-03-09 20:20:12.119+00	2026-03-09 20:20:12.119+00	2	\N
400	8	AY2	4EME	NAT	R3P	4	2026-03-09 20:20:12.12+00	2026-03-09 20:20:12.12+00	2	\N
401	8	AY2	4EME	AUT	PLEIN	23	2026-03-09 20:20:12.12+00	2026-03-09 20:20:12.12+00	2	\N
402	8	AY2	3EME	FR	PLEIN	52	2026-03-09 20:20:12.12+00	2026-03-09 20:20:12.12+00	2	\N
403	8	AY2	3EME	FR	RP	8	2026-03-09 20:20:12.121+00	2026-03-09 20:20:12.121+00	2	\N
404	8	AY2	3EME	FR	R3P	7	2026-03-09 20:20:12.121+00	2026-03-09 20:20:12.121+00	2	\N
405	8	AY2	3EME	NAT	PLEIN	32	2026-03-09 20:20:12.122+00	2026-03-09 20:20:12.122+00	2	\N
406	8	AY2	3EME	NAT	RP	5	2026-03-09 20:20:12.122+00	2026-03-09 20:20:12.122+00	2	\N
407	8	AY2	3EME	NAT	R3P	4	2026-03-09 20:20:12.122+00	2026-03-09 20:20:12.122+00	2	\N
408	8	AY2	3EME	AUT	PLEIN	24	2026-03-09 20:20:12.123+00	2026-03-09 20:20:12.123+00	2	\N
409	8	AY2	2NDE	FR	PLEIN	47	2026-03-09 20:20:12.123+00	2026-03-09 20:20:12.123+00	2	\N
410	8	AY2	2NDE	FR	RP	7	2026-03-09 20:20:12.124+00	2026-03-09 20:20:12.124+00	2	\N
411	8	AY2	2NDE	FR	R3P	6	2026-03-09 20:20:12.124+00	2026-03-09 20:20:12.124+00	2	\N
412	8	AY2	2NDE	NAT	PLEIN	29	2026-03-09 20:20:12.124+00	2026-03-09 20:20:12.124+00	2	\N
413	8	AY2	2NDE	NAT	RP	5	2026-03-09 20:20:12.125+00	2026-03-09 20:20:12.125+00	2	\N
414	8	AY2	2NDE	NAT	R3P	4	2026-03-09 20:20:12.125+00	2026-03-09 20:20:12.125+00	2	\N
415	8	AY2	2NDE	AUT	PLEIN	21	2026-03-09 20:20:12.126+00	2026-03-09 20:20:12.126+00	2	\N
416	8	AY2	1ERE	FR	PLEIN	45	2026-03-09 20:20:12.126+00	2026-03-09 20:20:12.126+00	2	\N
417	8	AY2	1ERE	FR	RP	7	2026-03-09 20:20:12.126+00	2026-03-09 20:20:12.126+00	2	\N
418	8	AY2	1ERE	FR	R3P	6	2026-03-09 20:20:12.127+00	2026-03-09 20:20:12.127+00	2	\N
419	8	AY2	1ERE	NAT	PLEIN	28	2026-03-09 20:20:12.127+00	2026-03-09 20:20:12.127+00	2	\N
420	8	AY2	1ERE	NAT	RP	4	2026-03-09 20:20:12.128+00	2026-03-09 20:20:12.128+00	2	\N
421	8	AY2	1ERE	NAT	R3P	4	2026-03-09 20:20:12.128+00	2026-03-09 20:20:12.128+00	2	\N
422	8	AY2	1ERE	AUT	PLEIN	20	2026-03-09 20:20:12.128+00	2026-03-09 20:20:12.128+00	2	\N
423	8	AY2	TERM	FR	PLEIN	31	2026-03-09 20:20:12.129+00	2026-03-09 20:20:12.129+00	2	\N
424	8	AY2	TERM	FR	RP	5	2026-03-09 20:20:12.129+00	2026-03-09 20:20:12.129+00	2	\N
425	8	AY2	TERM	NAT	PLEIN	19	2026-03-09 20:20:12.129+00	2026-03-09 20:20:12.129+00	2	\N
426	8	AY2	TERM	NAT	RP	3	2026-03-09 20:20:12.13+00	2026-03-09 20:20:12.13+00	2	\N
427	8	AY2	TERM	NAT	R3P	2	2026-03-09 20:20:12.13+00	2026-03-09 20:20:12.13+00	2	\N
428	8	AY2	TERM	AUT	PLEIN	14	2026-03-09 20:20:12.13+00	2026-03-09 20:20:12.13+00	2	\N
\.


--
-- Data for Name: enrollment_headcount; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.enrollment_headcount (id, version_id, academic_period, grade_level, headcount, created_at, updated_at, created_by, updated_by) FROM stdin;
106	8	AY1	PS	100	2026-03-09 20:20:12.032+00	2026-03-09 20:20:12.032+00	2	\N
107	8	AY1	MS	103	2026-03-09 20:20:12.033+00	2026-03-09 20:20:12.033+00	2	\N
108	8	AY1	GS	106	2026-03-09 20:20:12.034+00	2026-03-09 20:20:12.034+00	2	\N
109	8	AY1	CP	110	2026-03-09 20:20:12.035+00	2026-03-09 20:20:12.035+00	2	\N
110	8	AY1	CE1	113	2026-03-09 20:20:12.035+00	2026-03-09 20:20:12.035+00	2	\N
111	8	AY1	CE2	116	2026-03-09 20:20:12.035+00	2026-03-09 20:20:12.035+00	2	\N
112	8	AY1	CM1	119	2026-03-09 20:20:12.036+00	2026-03-09 20:20:12.036+00	2	\N
113	8	AY1	CM2	122	2026-03-09 20:20:12.036+00	2026-03-09 20:20:12.036+00	2	\N
114	8	AY1	6EME	131	2026-03-09 20:20:12.037+00	2026-03-09 20:20:12.037+00	2	\N
115	8	AY1	5EME	134	2026-03-09 20:20:12.037+00	2026-03-09 20:20:12.037+00	2	\N
116	8	AY1	4EME	137	2026-03-09 20:20:12.037+00	2026-03-09 20:20:12.037+00	2	\N
117	8	AY1	3EME	139	2026-03-09 20:20:12.038+00	2026-03-09 20:20:12.038+00	2	\N
118	8	AY1	2NDE	125	2026-03-09 20:20:12.038+00	2026-03-09 20:20:12.038+00	2	\N
119	8	AY1	1ERE	120	2026-03-09 20:20:12.039+00	2026-03-09 20:20:12.039+00	2	\N
120	8	AY1	TERM	78	2026-03-09 20:20:12.039+00	2026-03-09 20:20:12.039+00	2	\N
121	8	AY2	PS	95	2026-03-09 20:20:12.039+00	2026-03-09 20:20:12.039+00	2	\N
122	8	AY2	MS	98	2026-03-09 20:20:12.04+00	2026-03-09 20:20:12.04+00	2	\N
123	8	AY2	GS	101	2026-03-09 20:20:12.04+00	2026-03-09 20:20:12.04+00	2	\N
124	8	AY2	CP	105	2026-03-09 20:20:12.04+00	2026-03-09 20:20:12.04+00	2	\N
125	8	AY2	CE1	107	2026-03-09 20:20:12.041+00	2026-03-09 20:20:12.041+00	2	\N
126	8	AY2	CE2	110	2026-03-09 20:20:12.041+00	2026-03-09 20:20:12.041+00	2	\N
127	8	AY2	CM1	113	2026-03-09 20:20:12.042+00	2026-03-09 20:20:12.042+00	2	\N
128	8	AY2	CM2	116	2026-03-09 20:20:12.042+00	2026-03-09 20:20:12.042+00	2	\N
129	8	AY2	6EME	124	2026-03-09 20:20:12.042+00	2026-03-09 20:20:12.042+00	2	\N
130	8	AY2	5EME	127	2026-03-09 20:20:12.043+00	2026-03-09 20:20:12.043+00	2	\N
131	8	AY2	4EME	130	2026-03-09 20:20:12.043+00	2026-03-09 20:20:12.043+00	2	\N
132	8	AY2	3EME	132	2026-03-09 20:20:12.043+00	2026-03-09 20:20:12.043+00	2	\N
133	8	AY2	2NDE	119	2026-03-09 20:20:12.044+00	2026-03-09 20:20:12.044+00	2	\N
134	8	AY2	1ERE	114	2026-03-09 20:20:12.044+00	2026-03-09 20:20:12.044+00	2	\N
135	8	AY2	TERM	74	2026-03-09 20:20:12.045+00	2026-03-09 20:20:12.045+00	2	\N
136	9	AY1	PS	77	2026-03-09 20:20:12.318+00	2026-03-09 20:20:12.318+00	2	\N
137	9	AY1	MS	82	2026-03-09 20:20:12.318+00	2026-03-09 20:20:12.318+00	2	\N
138	9	AY1	GS	85	2026-03-09 20:20:12.319+00	2026-03-09 20:20:12.319+00	2	\N
139	9	AY1	CP	89	2026-03-09 20:20:12.319+00	2026-03-09 20:20:12.319+00	2	\N
140	9	AY1	CE1	90	2026-03-09 20:20:12.319+00	2026-03-09 20:20:12.319+00	2	\N
141	9	AY1	CE2	92	2026-03-09 20:20:12.32+00	2026-03-09 20:20:12.32+00	2	\N
142	9	AY1	CM1	95	2026-03-09 20:20:12.32+00	2026-03-09 20:20:12.32+00	2	\N
143	9	AY1	CM2	98	2026-03-09 20:20:12.32+00	2026-03-09 20:20:12.32+00	2	\N
144	9	AY1	6EME	105	2026-03-09 20:20:12.321+00	2026-03-09 20:20:12.321+00	2	\N
145	9	AY1	5EME	108	2026-03-09 20:20:12.321+00	2026-03-09 20:20:12.321+00	2	\N
146	9	AY1	4EME	110	2026-03-09 20:20:12.321+00	2026-03-09 20:20:12.321+00	2	\N
147	9	AY1	3EME	112	2026-03-09 20:20:12.322+00	2026-03-09 20:20:12.322+00	2	\N
148	9	AY1	2NDE	100	2026-03-09 20:20:12.322+00	2026-03-09 20:20:12.322+00	2	\N
149	9	AY1	1ERE	98	2026-03-09 20:20:12.323+00	2026-03-09 20:20:12.323+00	2	\N
150	9	AY1	TERM	93	2026-03-09 20:20:12.323+00	2026-03-09 20:20:12.323+00	2	\N
151	10	AY1	PS	81	2026-03-09 20:20:12.323+00	2026-03-09 20:20:12.323+00	2	\N
152	10	AY1	MS	85	2026-03-09 20:20:12.324+00	2026-03-09 20:20:12.324+00	2	\N
153	10	AY1	GS	88	2026-03-09 20:20:12.324+00	2026-03-09 20:20:12.324+00	2	\N
154	10	AY1	CP	93	2026-03-09 20:20:12.324+00	2026-03-09 20:20:12.324+00	2	\N
155	10	AY1	CE1	94	2026-03-09 20:20:12.325+00	2026-03-09 20:20:12.325+00	2	\N
156	10	AY1	CE2	96	2026-03-09 20:20:12.325+00	2026-03-09 20:20:12.325+00	2	\N
157	10	AY1	CM1	99	2026-03-09 20:20:12.325+00	2026-03-09 20:20:12.325+00	2	\N
158	10	AY1	CM2	102	2026-03-09 20:20:12.326+00	2026-03-09 20:20:12.326+00	2	\N
159	10	AY1	6EME	109	2026-03-09 20:20:12.326+00	2026-03-09 20:20:12.326+00	2	\N
160	10	AY1	5EME	112	2026-03-09 20:20:12.326+00	2026-03-09 20:20:12.326+00	2	\N
161	10	AY1	4EME	115	2026-03-09 20:20:12.327+00	2026-03-09 20:20:12.327+00	2	\N
162	10	AY1	3EME	117	2026-03-09 20:20:12.327+00	2026-03-09 20:20:12.327+00	2	\N
163	10	AY1	2NDE	105	2026-03-09 20:20:12.327+00	2026-03-09 20:20:12.327+00	2	\N
164	10	AY1	1ERE	102	2026-03-09 20:20:12.328+00	2026-03-09 20:20:12.328+00	2	\N
165	10	AY1	TERM	101	2026-03-09 20:20:12.328+00	2026-03-09 20:20:12.328+00	2	\N
166	11	AY1	PS	86	2026-03-09 20:20:12.328+00	2026-03-09 20:20:12.328+00	2	\N
167	11	AY1	MS	90	2026-03-09 20:20:12.329+00	2026-03-09 20:20:12.329+00	2	\N
168	11	AY1	GS	94	2026-03-09 20:20:12.329+00	2026-03-09 20:20:12.329+00	2	\N
169	11	AY1	CP	98	2026-03-09 20:20:12.329+00	2026-03-09 20:20:12.329+00	2	\N
170	11	AY1	CE1	100	2026-03-09 20:20:12.33+00	2026-03-09 20:20:12.33+00	2	\N
171	11	AY1	CE2	102	2026-03-09 20:20:12.33+00	2026-03-09 20:20:12.33+00	2	\N
172	11	AY1	CM1	105	2026-03-09 20:20:12.33+00	2026-03-09 20:20:12.33+00	2	\N
173	11	AY1	CM2	108	2026-03-09 20:20:12.331+00	2026-03-09 20:20:12.331+00	2	\N
174	11	AY1	6EME	116	2026-03-09 20:20:12.331+00	2026-03-09 20:20:12.331+00	2	\N
175	11	AY1	5EME	119	2026-03-09 20:20:12.331+00	2026-03-09 20:20:12.331+00	2	\N
176	11	AY1	4EME	122	2026-03-09 20:20:12.332+00	2026-03-09 20:20:12.332+00	2	\N
177	11	AY1	3EME	124	2026-03-09 20:20:12.332+00	2026-03-09 20:20:12.332+00	2	\N
178	11	AY1	2NDE	111	2026-03-09 20:20:12.332+00	2026-03-09 20:20:12.332+00	2	\N
179	11	AY1	1ERE	108	2026-03-09 20:20:12.333+00	2026-03-09 20:20:12.333+00	2	\N
180	11	AY1	TERM	104	2026-03-09 20:20:12.333+00	2026-03-09 20:20:12.333+00	2	\N
181	12	AY1	PS	97	2026-03-09 20:20:12.333+00	2026-03-09 20:20:12.333+00	2	\N
182	12	AY1	MS	102	2026-03-09 20:20:12.334+00	2026-03-09 20:20:12.334+00	2	\N
183	12	AY1	GS	106	2026-03-09 20:20:12.334+00	2026-03-09 20:20:12.334+00	2	\N
184	12	AY1	CP	111	2026-03-09 20:20:12.334+00	2026-03-09 20:20:12.334+00	2	\N
185	12	AY1	CE1	113	2026-03-09 20:20:12.335+00	2026-03-09 20:20:12.335+00	2	\N
186	12	AY1	CE2	115	2026-03-09 20:20:12.335+00	2026-03-09 20:20:12.335+00	2	\N
187	12	AY1	CM1	118	2026-03-09 20:20:12.335+00	2026-03-09 20:20:12.335+00	2	\N
188	12	AY1	CM2	122	2026-03-09 20:20:12.336+00	2026-03-09 20:20:12.336+00	2	\N
189	12	AY1	6EME	131	2026-03-09 20:20:12.336+00	2026-03-09 20:20:12.336+00	2	\N
190	12	AY1	5EME	135	2026-03-09 20:20:12.336+00	2026-03-09 20:20:12.336+00	2	\N
191	12	AY1	4EME	138	2026-03-09 20:20:12.337+00	2026-03-09 20:20:12.337+00	2	\N
192	12	AY1	3EME	140	2026-03-09 20:20:12.337+00	2026-03-09 20:20:12.337+00	2	\N
193	12	AY1	2NDE	126	2026-03-09 20:20:12.337+00	2026-03-09 20:20:12.337+00	2	\N
194	12	AY1	1ERE	122	2026-03-09 20:20:12.338+00	2026-03-09 20:20:12.338+00	2	\N
195	12	AY1	TERM	118	2026-03-09 20:20:12.338+00	2026-03-09 20:20:12.338+00	2	\N
196	13	AY1	PS	94	2026-03-09 20:20:12.339+00	2026-03-09 20:20:12.339+00	2	\N
197	13	AY1	MS	100	2026-03-09 20:20:12.339+00	2026-03-09 20:20:12.339+00	2	\N
198	13	AY1	GS	103	2026-03-09 20:20:12.339+00	2026-03-09 20:20:12.339+00	2	\N
199	13	AY1	CP	108	2026-03-09 20:20:12.34+00	2026-03-09 20:20:12.34+00	2	\N
200	13	AY1	CE1	110	2026-03-09 20:20:12.34+00	2026-03-09 20:20:12.34+00	2	\N
201	13	AY1	CE2	112	2026-03-09 20:20:12.341+00	2026-03-09 20:20:12.341+00	2	\N
202	13	AY1	CM1	115	2026-03-09 20:20:12.341+00	2026-03-09 20:20:12.341+00	2	\N
203	13	AY1	CM2	119	2026-03-09 20:20:12.341+00	2026-03-09 20:20:12.341+00	2	\N
204	13	AY1	6EME	128	2026-03-09 20:20:12.342+00	2026-03-09 20:20:12.342+00	2	\N
205	13	AY1	5EME	131	2026-03-09 20:20:12.342+00	2026-03-09 20:20:12.342+00	2	\N
206	13	AY1	4EME	135	2026-03-09 20:20:12.342+00	2026-03-09 20:20:12.342+00	2	\N
207	13	AY1	3EME	136	2026-03-09 20:20:12.343+00	2026-03-09 20:20:12.343+00	2	\N
208	13	AY1	2NDE	122	2026-03-09 20:20:12.343+00	2026-03-09 20:20:12.343+00	2	\N
209	13	AY1	1ERE	119	2026-03-09 20:20:12.343+00	2026-03-09 20:20:12.343+00	2	\N
210	13	AY1	TERM	115	2026-03-09 20:20:12.343+00	2026-03-09 20:20:12.343+00	2	\N
\.


--
-- Data for Name: eos_provisions; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.eos_provisions (id, version_id, employee_id, years_of_service, eos_base, eos_annual, eos_monthly_accrual, as_of_date, calculated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fee_grids; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.fee_grids (id, version_id, academic_period, grade_level, nationality, tariff, dai, tuition_ttc, tuition_ht, term1_amount, term2_amount, term3_amount, created_at, updated_at, created_by, updated_by) FROM stdin;
271	8	AY1	PS	FR	PLEIN	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.131+00	2026-03-09 20:20:12.131+00	2	\N
272	8	AY1	PS	FR	RP	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.132+00	2026-03-09 20:20:12.132+00	2	\N
273	8	AY1	PS	FR	R3P	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.133+00	2026-03-09 20:20:12.133+00	2	\N
274	8	AY1	PS	NAT	PLEIN	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.133+00	2026-03-09 20:20:12.133+00	2	\N
275	8	AY1	PS	NAT	RP	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.134+00	2026-03-09 20:20:12.134+00	2	\N
276	8	AY1	PS	NAT	R3P	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.134+00	2026-03-09 20:20:12.134+00	2	\N
277	8	AY1	PS	AUT	PLEIN	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.135+00	2026-03-09 20:20:12.135+00	2	\N
278	8	AY1	PS	AUT	RP	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.135+00	2026-03-09 20:20:12.135+00	2	\N
279	8	AY1	PS	AUT	R3P	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.136+00	2026-03-09 20:20:12.136+00	2	\N
280	8	AY1	MS	FR	PLEIN	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.137+00	2026-03-09 20:20:12.137+00	2	\N
281	8	AY1	MS	FR	RP	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.137+00	2026-03-09 20:20:12.137+00	2	\N
282	8	AY1	MS	FR	R3P	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.138+00	2026-03-09 20:20:12.138+00	2	\N
283	8	AY1	MS	NAT	PLEIN	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.138+00	2026-03-09 20:20:12.138+00	2	\N
284	8	AY1	MS	NAT	RP	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.139+00	2026-03-09 20:20:12.139+00	2	\N
285	8	AY1	MS	NAT	R3P	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.139+00	2026-03-09 20:20:12.139+00	2	\N
286	8	AY1	MS	AUT	PLEIN	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.14+00	2026-03-09 20:20:12.14+00	2	\N
287	8	AY1	MS	AUT	RP	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.14+00	2026-03-09 20:20:12.14+00	2	\N
288	8	AY1	MS	AUT	R3P	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.141+00	2026-03-09 20:20:12.141+00	2	\N
289	8	AY1	GS	FR	PLEIN	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.141+00	2026-03-09 20:20:12.141+00	2	\N
290	8	AY1	GS	FR	RP	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.141+00	2026-03-09 20:20:12.141+00	2	\N
291	8	AY1	GS	FR	R3P	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.142+00	2026-03-09 20:20:12.142+00	2	\N
292	8	AY1	GS	NAT	PLEIN	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.142+00	2026-03-09 20:20:12.142+00	2	\N
293	8	AY1	GS	NAT	RP	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.143+00	2026-03-09 20:20:12.143+00	2	\N
294	8	AY1	GS	NAT	R3P	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.143+00	2026-03-09 20:20:12.143+00	2	\N
295	8	AY1	GS	AUT	PLEIN	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.144+00	2026-03-09 20:20:12.144+00	2	\N
296	8	AY1	GS	AUT	RP	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.144+00	2026-03-09 20:20:12.144+00	2	\N
297	8	AY1	GS	AUT	R3P	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.145+00	2026-03-09 20:20:12.145+00	2	\N
298	8	AY1	CP	FR	PLEIN	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.145+00	2026-03-09 20:20:12.145+00	2	\N
299	8	AY1	CP	FR	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.146+00	2026-03-09 20:20:12.146+00	2	\N
300	8	AY1	CP	FR	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.146+00	2026-03-09 20:20:12.146+00	2	\N
301	8	AY1	CP	NAT	PLEIN	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.146+00	2026-03-09 20:20:12.146+00	2	\N
302	8	AY1	CP	NAT	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.147+00	2026-03-09 20:20:12.147+00	2	\N
303	8	AY1	CP	NAT	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.148+00	2026-03-09 20:20:12.148+00	2	\N
304	8	AY1	CP	AUT	PLEIN	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.148+00	2026-03-09 20:20:12.148+00	2	\N
305	8	AY1	CP	AUT	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.148+00	2026-03-09 20:20:12.148+00	2	\N
306	8	AY1	CP	AUT	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.149+00	2026-03-09 20:20:12.149+00	2	\N
307	8	AY1	CE1	FR	PLEIN	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.149+00	2026-03-09 20:20:12.149+00	2	\N
308	8	AY1	CE1	FR	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.15+00	2026-03-09 20:20:12.15+00	2	\N
309	8	AY1	CE1	FR	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.15+00	2026-03-09 20:20:12.15+00	2	\N
310	8	AY1	CE1	NAT	PLEIN	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.151+00	2026-03-09 20:20:12.151+00	2	\N
311	8	AY1	CE1	NAT	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.151+00	2026-03-09 20:20:12.151+00	2	\N
312	8	AY1	CE1	NAT	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.152+00	2026-03-09 20:20:12.152+00	2	\N
313	8	AY1	CE1	AUT	PLEIN	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.152+00	2026-03-09 20:20:12.152+00	2	\N
314	8	AY1	CE1	AUT	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.152+00	2026-03-09 20:20:12.152+00	2	\N
315	8	AY1	CE1	AUT	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.153+00	2026-03-09 20:20:12.153+00	2	\N
316	8	AY1	CE2	FR	PLEIN	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.153+00	2026-03-09 20:20:12.153+00	2	\N
317	8	AY1	CE2	FR	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.154+00	2026-03-09 20:20:12.154+00	2	\N
318	8	AY1	CE2	FR	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.154+00	2026-03-09 20:20:12.154+00	2	\N
319	8	AY1	CE2	NAT	PLEIN	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.155+00	2026-03-09 20:20:12.155+00	2	\N
320	8	AY1	CE2	NAT	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.155+00	2026-03-09 20:20:12.155+00	2	\N
321	8	AY1	CE2	NAT	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.155+00	2026-03-09 20:20:12.155+00	2	\N
322	8	AY1	CE2	AUT	PLEIN	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.156+00	2026-03-09 20:20:12.156+00	2	\N
323	8	AY1	CE2	AUT	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.156+00	2026-03-09 20:20:12.156+00	2	\N
324	8	AY1	CE2	AUT	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.157+00	2026-03-09 20:20:12.157+00	2	\N
325	8	AY1	CM1	FR	PLEIN	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.157+00	2026-03-09 20:20:12.157+00	2	\N
326	8	AY1	CM1	FR	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.158+00	2026-03-09 20:20:12.158+00	2	\N
327	8	AY1	CM1	FR	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.158+00	2026-03-09 20:20:12.158+00	2	\N
328	8	AY1	CM1	NAT	PLEIN	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.159+00	2026-03-09 20:20:12.159+00	2	\N
329	8	AY1	CM1	NAT	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.159+00	2026-03-09 20:20:12.159+00	2	\N
330	8	AY1	CM1	NAT	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.16+00	2026-03-09 20:20:12.16+00	2	\N
331	8	AY1	CM1	AUT	PLEIN	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.16+00	2026-03-09 20:20:12.16+00	2	\N
332	8	AY1	CM1	AUT	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.161+00	2026-03-09 20:20:12.161+00	2	\N
333	8	AY1	CM1	AUT	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.161+00	2026-03-09 20:20:12.161+00	2	\N
334	8	AY1	CM2	FR	PLEIN	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.162+00	2026-03-09 20:20:12.162+00	2	\N
335	8	AY1	CM2	FR	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.162+00	2026-03-09 20:20:12.162+00	2	\N
336	8	AY1	CM2	FR	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.163+00	2026-03-09 20:20:12.163+00	2	\N
337	8	AY1	CM2	NAT	PLEIN	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.163+00	2026-03-09 20:20:12.163+00	2	\N
338	8	AY1	CM2	NAT	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.164+00	2026-03-09 20:20:12.164+00	2	\N
339	8	AY1	CM2	NAT	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.164+00	2026-03-09 20:20:12.164+00	2	\N
340	8	AY1	CM2	AUT	PLEIN	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.165+00	2026-03-09 20:20:12.165+00	2	\N
341	8	AY1	CM2	AUT	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.165+00	2026-03-09 20:20:12.165+00	2	\N
342	8	AY1	CM2	AUT	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.166+00	2026-03-09 20:20:12.166+00	2	\N
343	8	AY1	6EME	FR	PLEIN	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.166+00	2026-03-09 20:20:12.166+00	2	\N
344	8	AY1	6EME	FR	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.167+00	2026-03-09 20:20:12.167+00	2	\N
345	8	AY1	6EME	FR	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.167+00	2026-03-09 20:20:12.167+00	2	\N
346	8	AY1	6EME	NAT	PLEIN	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.168+00	2026-03-09 20:20:12.168+00	2	\N
347	8	AY1	6EME	NAT	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.168+00	2026-03-09 20:20:12.168+00	2	\N
348	8	AY1	6EME	NAT	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.168+00	2026-03-09 20:20:12.168+00	2	\N
349	8	AY1	6EME	AUT	PLEIN	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.169+00	2026-03-09 20:20:12.169+00	2	\N
350	8	AY1	6EME	AUT	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.169+00	2026-03-09 20:20:12.169+00	2	\N
351	8	AY1	6EME	AUT	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.17+00	2026-03-09 20:20:12.17+00	2	\N
352	8	AY1	5EME	FR	PLEIN	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.17+00	2026-03-09 20:20:12.17+00	2	\N
353	8	AY1	5EME	FR	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.171+00	2026-03-09 20:20:12.171+00	2	\N
354	8	AY1	5EME	FR	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.171+00	2026-03-09 20:20:12.171+00	2	\N
355	8	AY1	5EME	NAT	PLEIN	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.172+00	2026-03-09 20:20:12.172+00	2	\N
356	8	AY1	5EME	NAT	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.172+00	2026-03-09 20:20:12.172+00	2	\N
357	8	AY1	5EME	NAT	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.173+00	2026-03-09 20:20:12.173+00	2	\N
358	8	AY1	5EME	AUT	PLEIN	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.173+00	2026-03-09 20:20:12.173+00	2	\N
359	8	AY1	5EME	AUT	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.174+00	2026-03-09 20:20:12.174+00	2	\N
360	8	AY1	5EME	AUT	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.174+00	2026-03-09 20:20:12.174+00	2	\N
361	8	AY1	4EME	FR	PLEIN	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.174+00	2026-03-09 20:20:12.174+00	2	\N
362	8	AY1	4EME	FR	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.175+00	2026-03-09 20:20:12.175+00	2	\N
363	8	AY1	4EME	FR	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.175+00	2026-03-09 20:20:12.175+00	2	\N
364	8	AY1	4EME	NAT	PLEIN	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.176+00	2026-03-09 20:20:12.176+00	2	\N
365	8	AY1	4EME	NAT	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.176+00	2026-03-09 20:20:12.176+00	2	\N
366	8	AY1	4EME	NAT	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.177+00	2026-03-09 20:20:12.177+00	2	\N
367	8	AY1	4EME	AUT	PLEIN	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.177+00	2026-03-09 20:20:12.177+00	2	\N
368	8	AY1	4EME	AUT	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.177+00	2026-03-09 20:20:12.177+00	2	\N
369	8	AY1	4EME	AUT	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.178+00	2026-03-09 20:20:12.178+00	2	\N
370	8	AY1	3EME	FR	PLEIN	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.178+00	2026-03-09 20:20:12.178+00	2	\N
371	8	AY1	3EME	FR	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.179+00	2026-03-09 20:20:12.179+00	2	\N
372	8	AY1	3EME	FR	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.179+00	2026-03-09 20:20:12.179+00	2	\N
373	8	AY1	3EME	NAT	PLEIN	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.18+00	2026-03-09 20:20:12.18+00	2	\N
374	8	AY1	3EME	NAT	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.18+00	2026-03-09 20:20:12.18+00	2	\N
375	8	AY1	3EME	NAT	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.18+00	2026-03-09 20:20:12.18+00	2	\N
376	8	AY1	3EME	AUT	PLEIN	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.181+00	2026-03-09 20:20:12.181+00	2	\N
377	8	AY1	3EME	AUT	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.181+00	2026-03-09 20:20:12.181+00	2	\N
378	8	AY1	3EME	AUT	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.182+00	2026-03-09 20:20:12.182+00	2	\N
379	8	AY1	2NDE	FR	PLEIN	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.182+00	2026-03-09 20:20:12.182+00	2	\N
380	8	AY1	2NDE	FR	RP	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.183+00	2026-03-09 20:20:12.183+00	2	\N
381	8	AY1	2NDE	FR	R3P	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.183+00	2026-03-09 20:20:12.183+00	2	\N
382	8	AY1	2NDE	NAT	PLEIN	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.183+00	2026-03-09 20:20:12.183+00	2	\N
383	8	AY1	2NDE	NAT	RP	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.184+00	2026-03-09 20:20:12.184+00	2	\N
384	8	AY1	2NDE	NAT	R3P	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.184+00	2026-03-09 20:20:12.184+00	2	\N
385	8	AY1	2NDE	AUT	PLEIN	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.185+00	2026-03-09 20:20:12.185+00	2	\N
386	8	AY1	2NDE	AUT	RP	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.185+00	2026-03-09 20:20:12.185+00	2	\N
387	8	AY1	2NDE	AUT	R3P	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.186+00	2026-03-09 20:20:12.186+00	2	\N
388	8	AY1	1ERE	FR	PLEIN	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.186+00	2026-03-09 20:20:12.186+00	2	\N
389	8	AY1	1ERE	FR	RP	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.186+00	2026-03-09 20:20:12.186+00	2	\N
390	8	AY1	1ERE	FR	R3P	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.187+00	2026-03-09 20:20:12.187+00	2	\N
391	8	AY1	1ERE	NAT	PLEIN	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.187+00	2026-03-09 20:20:12.187+00	2	\N
392	8	AY1	1ERE	NAT	RP	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.188+00	2026-03-09 20:20:12.188+00	2	\N
393	8	AY1	1ERE	NAT	R3P	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.188+00	2026-03-09 20:20:12.188+00	2	\N
394	8	AY1	1ERE	AUT	PLEIN	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.189+00	2026-03-09 20:20:12.189+00	2	\N
395	8	AY1	1ERE	AUT	RP	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.189+00	2026-03-09 20:20:12.189+00	2	\N
396	8	AY1	1ERE	AUT	R3P	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.189+00	2026-03-09 20:20:12.189+00	2	\N
397	8	AY1	TERM	FR	PLEIN	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.19+00	2026-03-09 20:20:12.19+00	2	\N
398	8	AY1	TERM	FR	RP	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.19+00	2026-03-09 20:20:12.19+00	2	\N
399	8	AY1	TERM	FR	R3P	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.191+00	2026-03-09 20:20:12.191+00	2	\N
400	8	AY1	TERM	NAT	PLEIN	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.191+00	2026-03-09 20:20:12.191+00	2	\N
401	8	AY1	TERM	NAT	RP	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.192+00	2026-03-09 20:20:12.192+00	2	\N
402	8	AY1	TERM	NAT	R3P	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.192+00	2026-03-09 20:20:12.192+00	2	\N
403	8	AY1	TERM	AUT	PLEIN	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.192+00	2026-03-09 20:20:12.192+00	2	\N
404	8	AY1	TERM	AUT	RP	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.193+00	2026-03-09 20:20:12.193+00	2	\N
405	8	AY1	TERM	AUT	R3P	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.193+00	2026-03-09 20:20:12.193+00	2	\N
406	8	AY2	PS	FR	PLEIN	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.194+00	2026-03-09 20:20:12.194+00	2	\N
407	8	AY2	PS	FR	RP	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.194+00	2026-03-09 20:20:12.194+00	2	\N
408	8	AY2	PS	FR	R3P	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.195+00	2026-03-09 20:20:12.195+00	2	\N
409	8	AY2	PS	NAT	PLEIN	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.195+00	2026-03-09 20:20:12.195+00	2	\N
410	8	AY2	PS	NAT	RP	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.196+00	2026-03-09 20:20:12.196+00	2	\N
411	8	AY2	PS	NAT	R3P	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.196+00	2026-03-09 20:20:12.196+00	2	\N
412	8	AY2	PS	AUT	PLEIN	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.196+00	2026-03-09 20:20:12.196+00	2	\N
413	8	AY2	PS	AUT	RP	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.197+00	2026-03-09 20:20:12.197+00	2	\N
414	8	AY2	PS	AUT	R3P	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.197+00	2026-03-09 20:20:12.197+00	2	\N
415	8	AY2	MS	FR	PLEIN	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.198+00	2026-03-09 20:20:12.198+00	2	\N
416	8	AY2	MS	FR	RP	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.198+00	2026-03-09 20:20:12.198+00	2	\N
417	8	AY2	MS	FR	R3P	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.199+00	2026-03-09 20:20:12.199+00	2	\N
418	8	AY2	MS	NAT	PLEIN	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.199+00	2026-03-09 20:20:12.199+00	2	\N
419	8	AY2	MS	NAT	RP	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.2+00	2026-03-09 20:20:12.2+00	2	\N
420	8	AY2	MS	NAT	R3P	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.2+00	2026-03-09 20:20:12.2+00	2	\N
421	8	AY2	MS	AUT	PLEIN	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.201+00	2026-03-09 20:20:12.201+00	2	\N
422	8	AY2	MS	AUT	RP	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.201+00	2026-03-09 20:20:12.201+00	2	\N
423	8	AY2	MS	AUT	R3P	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.202+00	2026-03-09 20:20:12.202+00	2	\N
424	8	AY2	GS	FR	PLEIN	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.202+00	2026-03-09 20:20:12.202+00	2	\N
425	8	AY2	GS	FR	RP	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.203+00	2026-03-09 20:20:12.203+00	2	\N
426	8	AY2	GS	FR	R3P	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.203+00	2026-03-09 20:20:12.203+00	2	\N
427	8	AY2	GS	NAT	PLEIN	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.204+00	2026-03-09 20:20:12.204+00	2	\N
428	8	AY2	GS	NAT	RP	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.204+00	2026-03-09 20:20:12.204+00	2	\N
429	8	AY2	GS	NAT	R3P	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.204+00	2026-03-09 20:20:12.204+00	2	\N
430	8	AY2	GS	AUT	PLEIN	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.205+00	2026-03-09 20:20:12.205+00	2	\N
431	8	AY2	GS	AUT	RP	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.206+00	2026-03-09 20:20:12.206+00	2	\N
432	8	AY2	GS	AUT	R3P	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.206+00	2026-03-09 20:20:12.206+00	2	\N
433	8	AY2	CP	FR	PLEIN	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.206+00	2026-03-09 20:20:12.206+00	2	\N
434	8	AY2	CP	FR	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.207+00	2026-03-09 20:20:12.207+00	2	\N
435	8	AY2	CP	FR	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.207+00	2026-03-09 20:20:12.207+00	2	\N
436	8	AY2	CP	NAT	PLEIN	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.208+00	2026-03-09 20:20:12.208+00	2	\N
437	8	AY2	CP	NAT	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.208+00	2026-03-09 20:20:12.208+00	2	\N
438	8	AY2	CP	NAT	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.209+00	2026-03-09 20:20:12.209+00	2	\N
439	8	AY2	CP	AUT	PLEIN	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.209+00	2026-03-09 20:20:12.209+00	2	\N
440	8	AY2	CP	AUT	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.209+00	2026-03-09 20:20:12.209+00	2	\N
441	8	AY2	CP	AUT	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.21+00	2026-03-09 20:20:12.21+00	2	\N
442	8	AY2	CE1	FR	PLEIN	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.21+00	2026-03-09 20:20:12.21+00	2	\N
443	8	AY2	CE1	FR	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.211+00	2026-03-09 20:20:12.211+00	2	\N
444	8	AY2	CE1	FR	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.212+00	2026-03-09 20:20:12.212+00	2	\N
445	8	AY2	CE1	NAT	PLEIN	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.212+00	2026-03-09 20:20:12.212+00	2	\N
446	8	AY2	CE1	NAT	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.212+00	2026-03-09 20:20:12.212+00	2	\N
447	8	AY2	CE1	NAT	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.213+00	2026-03-09 20:20:12.213+00	2	\N
448	8	AY2	CE1	AUT	PLEIN	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.213+00	2026-03-09 20:20:12.213+00	2	\N
449	8	AY2	CE1	AUT	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.214+00	2026-03-09 20:20:12.214+00	2	\N
450	8	AY2	CE1	AUT	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.214+00	2026-03-09 20:20:12.214+00	2	\N
451	8	AY2	CE2	FR	PLEIN	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.214+00	2026-03-09 20:20:12.214+00	2	\N
452	8	AY2	CE2	FR	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.215+00	2026-03-09 20:20:12.215+00	2	\N
453	8	AY2	CE2	FR	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.215+00	2026-03-09 20:20:12.215+00	2	\N
454	8	AY2	CE2	NAT	PLEIN	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.216+00	2026-03-09 20:20:12.216+00	2	\N
455	8	AY2	CE2	NAT	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.216+00	2026-03-09 20:20:12.216+00	2	\N
456	8	AY2	CE2	NAT	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.217+00	2026-03-09 20:20:12.217+00	2	\N
457	8	AY2	CE2	AUT	PLEIN	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.217+00	2026-03-09 20:20:12.217+00	2	\N
458	8	AY2	CE2	AUT	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.218+00	2026-03-09 20:20:12.218+00	2	\N
459	8	AY2	CE2	AUT	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.218+00	2026-03-09 20:20:12.218+00	2	\N
460	8	AY2	CM1	FR	PLEIN	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.219+00	2026-03-09 20:20:12.219+00	2	\N
461	8	AY2	CM1	FR	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.219+00	2026-03-09 20:20:12.219+00	2	\N
462	8	AY2	CM1	FR	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.22+00	2026-03-09 20:20:12.22+00	2	\N
463	8	AY2	CM1	NAT	PLEIN	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.22+00	2026-03-09 20:20:12.22+00	2	\N
464	8	AY2	CM1	NAT	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.22+00	2026-03-09 20:20:12.22+00	2	\N
465	8	AY2	CM1	NAT	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.221+00	2026-03-09 20:20:12.221+00	2	\N
466	8	AY2	CM1	AUT	PLEIN	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.221+00	2026-03-09 20:20:12.221+00	2	\N
467	8	AY2	CM1	AUT	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.222+00	2026-03-09 20:20:12.222+00	2	\N
468	8	AY2	CM1	AUT	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.222+00	2026-03-09 20:20:12.222+00	2	\N
469	8	AY2	CM2	FR	PLEIN	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.223+00	2026-03-09 20:20:12.223+00	2	\N
470	8	AY2	CM2	FR	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.223+00	2026-03-09 20:20:12.223+00	2	\N
471	8	AY2	CM2	FR	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.223+00	2026-03-09 20:20:12.223+00	2	\N
472	8	AY2	CM2	NAT	PLEIN	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.224+00	2026-03-09 20:20:12.224+00	2	\N
473	8	AY2	CM2	NAT	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.224+00	2026-03-09 20:20:12.224+00	2	\N
474	8	AY2	CM2	NAT	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.225+00	2026-03-09 20:20:12.225+00	2	\N
475	8	AY2	CM2	AUT	PLEIN	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.225+00	2026-03-09 20:20:12.225+00	2	\N
476	8	AY2	CM2	AUT	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.225+00	2026-03-09 20:20:12.225+00	2	\N
477	8	AY2	CM2	AUT	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.226+00	2026-03-09 20:20:12.226+00	2	\N
478	8	AY2	6EME	FR	PLEIN	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.226+00	2026-03-09 20:20:12.226+00	2	\N
479	8	AY2	6EME	FR	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.227+00	2026-03-09 20:20:12.227+00	2	\N
480	8	AY2	6EME	FR	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.227+00	2026-03-09 20:20:12.227+00	2	\N
481	8	AY2	6EME	NAT	PLEIN	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.228+00	2026-03-09 20:20:12.228+00	2	\N
482	8	AY2	6EME	NAT	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.228+00	2026-03-09 20:20:12.228+00	2	\N
483	8	AY2	6EME	NAT	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.229+00	2026-03-09 20:20:12.229+00	2	\N
484	8	AY2	6EME	AUT	PLEIN	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.229+00	2026-03-09 20:20:12.229+00	2	\N
485	8	AY2	6EME	AUT	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.229+00	2026-03-09 20:20:12.229+00	2	\N
486	8	AY2	6EME	AUT	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.23+00	2026-03-09 20:20:12.23+00	2	\N
487	8	AY2	5EME	FR	PLEIN	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.23+00	2026-03-09 20:20:12.23+00	2	\N
488	8	AY2	5EME	FR	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.231+00	2026-03-09 20:20:12.231+00	2	\N
489	8	AY2	5EME	FR	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.231+00	2026-03-09 20:20:12.231+00	2	\N
490	8	AY2	5EME	NAT	PLEIN	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.232+00	2026-03-09 20:20:12.232+00	2	\N
491	8	AY2	5EME	NAT	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.232+00	2026-03-09 20:20:12.232+00	2	\N
492	8	AY2	5EME	NAT	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.233+00	2026-03-09 20:20:12.233+00	2	\N
493	8	AY2	5EME	AUT	PLEIN	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.233+00	2026-03-09 20:20:12.233+00	2	\N
494	8	AY2	5EME	AUT	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.234+00	2026-03-09 20:20:12.234+00	2	\N
495	8	AY2	5EME	AUT	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.234+00	2026-03-09 20:20:12.234+00	2	\N
496	8	AY2	4EME	FR	PLEIN	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.234+00	2026-03-09 20:20:12.234+00	2	\N
497	8	AY2	4EME	FR	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.235+00	2026-03-09 20:20:12.235+00	2	\N
498	8	AY2	4EME	FR	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.235+00	2026-03-09 20:20:12.235+00	2	\N
499	8	AY2	4EME	NAT	PLEIN	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.236+00	2026-03-09 20:20:12.236+00	2	\N
500	8	AY2	4EME	NAT	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.236+00	2026-03-09 20:20:12.236+00	2	\N
501	8	AY2	4EME	NAT	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.236+00	2026-03-09 20:20:12.236+00	2	\N
502	8	AY2	4EME	AUT	PLEIN	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.237+00	2026-03-09 20:20:12.237+00	2	\N
503	8	AY2	4EME	AUT	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.237+00	2026-03-09 20:20:12.237+00	2	\N
504	8	AY2	4EME	AUT	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.238+00	2026-03-09 20:20:12.238+00	2	\N
505	8	AY2	3EME	FR	PLEIN	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.238+00	2026-03-09 20:20:12.238+00	2	\N
506	8	AY2	3EME	FR	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.239+00	2026-03-09 20:20:12.239+00	2	\N
507	8	AY2	3EME	FR	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.239+00	2026-03-09 20:20:12.239+00	2	\N
508	8	AY2	3EME	NAT	PLEIN	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.24+00	2026-03-09 20:20:12.24+00	2	\N
509	8	AY2	3EME	NAT	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.24+00	2026-03-09 20:20:12.24+00	2	\N
510	8	AY2	3EME	NAT	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.241+00	2026-03-09 20:20:12.241+00	2	\N
511	8	AY2	3EME	AUT	PLEIN	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.241+00	2026-03-09 20:20:12.241+00	2	\N
512	8	AY2	3EME	AUT	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.242+00	2026-03-09 20:20:12.242+00	2	\N
513	8	AY2	3EME	AUT	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.242+00	2026-03-09 20:20:12.242+00	2	\N
514	8	AY2	2NDE	FR	PLEIN	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.242+00	2026-03-09 20:20:12.242+00	2	\N
515	8	AY2	2NDE	FR	RP	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.243+00	2026-03-09 20:20:12.243+00	2	\N
516	8	AY2	2NDE	FR	R3P	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.243+00	2026-03-09 20:20:12.243+00	2	\N
517	8	AY2	2NDE	NAT	PLEIN	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.244+00	2026-03-09 20:20:12.244+00	2	\N
518	8	AY2	2NDE	NAT	RP	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.244+00	2026-03-09 20:20:12.244+00	2	\N
519	8	AY2	2NDE	NAT	R3P	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.245+00	2026-03-09 20:20:12.245+00	2	\N
520	8	AY2	2NDE	AUT	PLEIN	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.245+00	2026-03-09 20:20:12.245+00	2	\N
521	8	AY2	2NDE	AUT	RP	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.246+00	2026-03-09 20:20:12.246+00	2	\N
522	8	AY2	2NDE	AUT	R3P	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.246+00	2026-03-09 20:20:12.246+00	2	\N
523	8	AY2	1ERE	FR	PLEIN	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.247+00	2026-03-09 20:20:12.247+00	2	\N
524	8	AY2	1ERE	FR	RP	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.247+00	2026-03-09 20:20:12.247+00	2	\N
525	8	AY2	1ERE	FR	R3P	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.248+00	2026-03-09 20:20:12.248+00	2	\N
526	8	AY2	1ERE	NAT	PLEIN	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.248+00	2026-03-09 20:20:12.248+00	2	\N
527	8	AY2	1ERE	NAT	RP	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.249+00	2026-03-09 20:20:12.249+00	2	\N
528	8	AY2	1ERE	NAT	R3P	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.249+00	2026-03-09 20:20:12.249+00	2	\N
529	8	AY2	1ERE	AUT	PLEIN	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.25+00	2026-03-09 20:20:12.25+00	2	\N
530	8	AY2	1ERE	AUT	RP	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.25+00	2026-03-09 20:20:12.25+00	2	\N
531	8	AY2	1ERE	AUT	R3P	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.251+00	2026-03-09 20:20:12.251+00	2	\N
532	8	AY2	TERM	FR	PLEIN	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.251+00	2026-03-09 20:20:12.251+00	2	\N
533	8	AY2	TERM	FR	RP	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.252+00	2026-03-09 20:20:12.252+00	2	\N
534	8	AY2	TERM	FR	R3P	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.252+00	2026-03-09 20:20:12.252+00	2	\N
535	8	AY2	TERM	NAT	PLEIN	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.252+00	2026-03-09 20:20:12.252+00	2	\N
536	8	AY2	TERM	NAT	RP	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.253+00	2026-03-09 20:20:12.253+00	2	\N
537	8	AY2	TERM	NAT	R3P	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.253+00	2026-03-09 20:20:12.253+00	2	\N
538	8	AY2	TERM	AUT	PLEIN	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.254+00	2026-03-09 20:20:12.254+00	2	\N
539	8	AY2	TERM	AUT	RP	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.254+00	2026-03-09 20:20:12.254+00	2	\N
540	8	AY2	TERM	AUT	R3P	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:20:12.255+00	2026-03-09 20:20:12.255+00	2	\N
\.


--
-- Data for Name: fiscal_periods; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.fiscal_periods (id, fiscal_year, month, status, actual_version_id, locked_at, locked_by_id, created_at, updated_at, updated_by_id) FROM stdin;
1	2026	1	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
2	2026	2	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
3	2026	3	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
4	2026	4	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
5	2026	5	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
6	2026	6	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
7	2026	7	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
8	2026	8	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
9	2026	9	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
10	2026	10	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
11	2026	11	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
12	2026	12	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
\.


--
-- Data for Name: grade_levels; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.grade_levels (id, grade_code, grade_name, band, max_class_size, plancher_pct, cible_pct, plafond_pct, display_order, version, created_at, updated_at) FROM stdin;
1	PS	Petite Section	MATERNELLE	28	0.7000	0.8000	0.9000	1	1	2026-03-07 22:19:06.426+00	2026-03-08 20:16:39.695+00
2	MS	Moyenne Section	MATERNELLE	28	0.7000	0.8000	0.9000	2	1	2026-03-07 22:19:06.429+00	2026-03-08 20:16:39.698+00
3	GS	Grande Section	MATERNELLE	28	0.7500	0.8500	0.9500	3	1	2026-03-07 22:19:06.43+00	2026-03-08 20:16:39.699+00
4	CP	Cours Preparatoire	ELEMENTAIRE	28	0.7500	0.8500	0.9500	4	1	2026-03-07 22:19:06.43+00	2026-03-08 20:16:39.699+00
5	CE1	Cours Elementaire 1	ELEMENTAIRE	30	0.7500	0.8500	0.9500	5	1	2026-03-07 22:19:06.431+00	2026-03-08 20:16:39.7+00
6	CE2	Cours Elementaire 2	ELEMENTAIRE	30	0.7500	0.8500	0.9500	6	1	2026-03-07 22:19:06.432+00	2026-03-08 20:16:39.7+00
7	CM1	Cours Moyen 1	ELEMENTAIRE	30	0.7500	0.8500	0.9500	7	1	2026-03-07 22:19:06.432+00	2026-03-08 20:16:39.701+00
8	CM2	Cours Moyen 2	ELEMENTAIRE	30	0.7500	0.8500	0.9500	8	1	2026-03-07 22:19:06.433+00	2026-03-08 20:16:39.701+00
9	6EME	Sixieme	COLLEGE	30	0.8000	0.8500	0.9500	9	1	2026-03-07 22:19:06.433+00	2026-03-08 20:16:39.702+00
10	5EME	Cinquieme	COLLEGE	30	0.8000	0.8500	0.9500	10	1	2026-03-07 22:19:06.434+00	2026-03-08 20:16:39.702+00
11	4EME	Quatrieme	COLLEGE	30	0.8000	0.8500	0.9500	11	1	2026-03-07 22:19:06.434+00	2026-03-08 20:16:39.703+00
12	3EME	Troisieme	COLLEGE	30	0.8000	0.8500	0.9500	12	1	2026-03-07 22:19:06.435+00	2026-03-08 20:16:39.703+00
13	2NDE	Seconde	LYCEE	35	0.8000	0.9000	1.0000	13	1	2026-03-07 22:19:06.435+00	2026-03-08 20:16:39.703+00
14	1ERE	Premiere	LYCEE	35	0.8000	0.9000	1.0000	14	1	2026-03-07 22:19:06.435+00	2026-03-08 20:16:39.704+00
15	TERM	Terminale	LYCEE	35	0.8000	0.9000	1.0000	15	1	2026-03-07 22:19:06.436+00	2026-03-08 20:16:39.704+00
\.


--
-- Data for Name: monthly_budget_summary; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.monthly_budget_summary (id, version_id, month, revenue_ht, staff_costs, net_profit, calculated_at) FROM stdin;
\.


--
-- Data for Name: monthly_other_revenue; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.monthly_other_revenue (id, version_id, scenario_name, line_item_name, ifrs_category, executive_category, month, amount, calculated_at, calculated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: monthly_revenue; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.monthly_revenue (id, version_id, scenario_name, academic_period, grade_level, nationality, tariff, month, gross_revenue_ht, discount_amount, scholarship_deduction, net_revenue_ht, vat_amount, calculated_at, calculated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: monthly_staff_costs; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.monthly_staff_costs (id, version_id, employee_id, month, base_gross, adjusted_gross, housing_allowance, transport_allowance, responsibility_premium, hsa_amount, gosi_amount, ajeer_amount, eos_monthly_accrual, total_cost, calculated_at, calculated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nationalities; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.nationalities (id, code, label, vat_exempt, version, created_at, updated_at, created_by, updated_by) FROM stdin;
1	FR	Francais	f	1	2026-03-09 20:15:46.26+00	2026-03-09 20:20:11.97+00	2	2
2	NAT	Nationaux	f	1	2026-03-09 20:15:46.267+00	2026-03-09 20:20:11.971+00	2	2
3	AUT	Autres	f	1	2026-03-09 20:15:46.268+00	2026-03-09 20:20:11.972+00	2	2
\.


--
-- Data for Name: nationality_breakdown; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.nationality_breakdown (id, version_id, academic_period, grade_level, nationality, weight, headcount, is_overridden, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: other_revenue_items; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.other_revenue_items (id, version_id, line_item_name, annual_amount, distribution_method, weight_array, specific_months, ifrs_category, created_at, updated_at, created_by, updated_by) FROM stdin;
22	8	DAI — Maternelle	600000.0000	ACADEMIC	\N	{}	Registration Fees	2026-03-09 20:20:12.26+00	2026-03-09 20:20:12.26+00	2	\N
23	8	DAI — Elementaire	1100000.0000	ACADEMIC	\N	{}	Registration Fees	2026-03-09 20:20:12.26+00	2026-03-09 20:20:12.26+00	2	\N
24	8	DAI — College	1350000.0000	ACADEMIC	\N	{}	Registration Fees	2026-03-09 20:20:12.261+00	2026-03-09 20:20:12.261+00	2	\N
25	8	DAI — Lycee	905000.0000	ACADEMIC	\N	{}	Registration Fees	2026-03-09 20:20:12.261+00	2026-03-09 20:20:12.261+00	2	\N
26	8	DPI Revenue	450000.0000	SPECIFIC_MONTHS	\N	{1,9}	Registration Fees	2026-03-09 20:20:12.262+00	2026-03-09 20:20:12.262+00	2	\N
27	8	Frais de Dossier	350000.0000	SPECIFIC_MONTHS	\N	{3,4,5}	Registration Fees	2026-03-09 20:20:12.262+00	2026-03-09 20:20:12.262+00	2	\N
28	8	Examination Fees — BAC	78000.0000	SPECIFIC_MONTHS	\N	{3}	Examination Fees	2026-03-09 20:20:12.263+00	2026-03-09 20:20:12.263+00	2	\N
29	8	Examination Fees — DNB	69500.0000	SPECIFIC_MONTHS	\N	{3}	Examination Fees	2026-03-09 20:20:12.263+00	2026-03-09 20:20:12.263+00	2	\N
30	8	Examination Fees — EAF	60000.0000	SPECIFIC_MONTHS	\N	{4}	Examination Fees	2026-03-09 20:20:12.264+00	2026-03-09 20:20:12.264+00	2	\N
31	8	Examination Fees — SIELE	42000.0000	SPECIFIC_MONTHS	\N	{5}	Examination Fees	2026-03-09 20:20:12.264+00	2026-03-09 20:20:12.264+00	2	\N
32	8	After-School Activities	280000.0000	ACADEMIC	\N	{}	Activities & Services	2026-03-09 20:20:12.265+00	2026-03-09 20:20:12.265+00	2	\N
33	8	Daycare Revenue	195000.0000	ACADEMIC	\N	{}	Activities & Services	2026-03-09 20:20:12.265+00	2026-03-09 20:20:12.265+00	2	\N
34	8	Class Photos Revenue	35000.0000	SPECIFIC_MONTHS	\N	{10,11}	Activities & Services	2026-03-09 20:20:12.265+00	2026-03-09 20:20:12.265+00	2	\N
35	8	PSG Academy Rental	120000.0000	EVEN	\N	{}	Activities & Services	2026-03-09 20:20:12.266+00	2026-03-09 20:20:12.266+00	2	\N
36	8	Evaluation Fees	87500.0000	SPECIFIC_MONTHS	\N	{1,2,3}	Registration Fees	2026-03-09 20:20:12.266+00	2026-03-09 20:20:12.266+00	2	\N
37	8	Bourses AEFE	-450000.0000	EVEN	\N	{}	Other Revenue	2026-03-09 20:20:12.267+00	2026-03-09 20:20:12.267+00	2	\N
38	8	Bourses AESH	-120000.0000	EVEN	\N	{}	Other Revenue	2026-03-09 20:20:12.267+00	2026-03-09 20:20:12.267+00	2	\N
39	8	Transport Service — Buses	680000.0000	ACADEMIC	\N	{}	Activities & Services	2026-03-09 20:20:12.268+00	2026-03-09 20:20:12.268+00	2	\N
40	8	Cafeteria Concession	95000.0000	EVEN	\N	{}	Other Revenue	2026-03-09 20:20:12.268+00	2026-03-09 20:20:12.268+00	2	\N
41	8	Uniform Sales Commission	45000.0000	SPECIFIC_MONTHS	\N	{8,9}	Other Revenue	2026-03-09 20:20:12.269+00	2026-03-09 20:20:12.269+00	2	\N
42	8	Summer Camp Revenue	150000.0000	SPECIFIC_MONTHS	\N	{7,8}	Activities & Services	2026-03-09 20:20:12.269+00	2026-03-09 20:20:12.269+00	2	\N
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.refresh_tokens (id, user_id, token_hash, family_id, is_revoked, expires_at, created_at) FROM stdin;
58	1	9aaa4059abc208c6923305d0fe543e84dcf610c4b7c8830c5ba9bf671b0e7429	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:55:01.149+00	2026-03-08 21:55:01.15+00
1	1	0567f0f6f5989b13ef1fbdda4fc60fa0008d4c774ff90456351ad21f43fac5f8	985e34a0-e0c5-429f-a1da-5df8b6852060	t	2026-03-08 06:19:22.078+00	2026-03-07 22:19:22.079+00
59	1	7c0f83c71f10ba1fa3251b8926ad41f9d9d0c273007ec500939ca2a3883c8446	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:55:14.16+00	2026-03-08 21:55:14.161+00
2	1	932a53615bd4ff6fbd93410e9e15113c37d3782473f0d7244f7a0284792eecbc	013b4daf-e306-441e-befd-b4f1162264d6	t	2026-03-08 06:19:28.217+00	2026-03-07 22:19:28.217+00
4	1	8b5cf138efe7337d8860dc577a379d5226311a07d8d64ac1cb745592edd8ed2f	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-08 06:23:31.315+00	2026-03-07 22:23:31.315+00
60	1	7e586e43a40763e96e11144a5e1b284f5bf6c7429e59e832761b1e9ee41a4fa6	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:55:20.123+00	2026-03-08 21:55:20.124+00
5	1	5a280156187255f32f29311df959878e84093428279d5ed4f0e794c505801e48	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-08 07:11:44.606+00	2026-03-07 23:11:44.607+00
6	1	45e1f9d17c7fd82d180450baa48a6df93d544f5e78044aabdcb245a3efd5c306	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-08 07:11:47.973+00	2026-03-07 23:11:47.974+00
7	1	7ed9a7f9ac5ffb7793af928ad4d9e05f73a79ff53a681b3c48b104681fbc6506	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-08 09:31:49.105+00	2026-03-08 01:31:49.106+00
8	1	9e01cf3817a123fc224cd7bf31c5c1de89333c56cdc01aa48c320184b23f3b93	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-08 14:39:34.492+00	2026-03-08 06:39:34.493+00
9	1	db34e30f4aad7b875f2e4010f675f3e92e1b6ff89ecd548ebde0e352758bc8e9	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-08 19:01:49.978+00	2026-03-08 11:01:49.979+00
10	1	9d417a511fdb35ab51d06351b4024012290a53df865bf4d7272cb6e1c955430b	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-08 21:25:44.009+00	2026-03-08 13:25:44.009+00
11	1	cdfdef12030ba76d78500a7fcafe43db0b5f8fcad33fee4a675334821cb4d32c	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-08 21:25:48.121+00	2026-03-08 13:25:48.122+00
12	1	a1851860730d78218e22da27a469135ae168538d69485ab9c8b989f046af6ceb	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-08 21:41:08.192+00	2026-03-08 13:41:08.193+00
13	1	696b39542bf79d920fec407f9550db7bb893ebfef79107484abba3bfe9d9e783	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-08 21:41:09.105+00	2026-03-08 13:41:09.106+00
14	1	bc6b1337fc592a63a07b6dfa428bbce46fa1320e6fe9c5401538fd52698be299	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-09 00:19:46.261+00	2026-03-08 16:19:46.262+00
15	1	f409756fa34e4302276ead7f01b4c99224a9baffcafdd7c4e501f58f3f641246	2d19ba37-8cb8-40b8-b663-baecb7921c2c	t	2026-03-09 00:31:36.426+00	2026-03-08 16:31:36.426+00
21	1	83f3280738f84e8e4c071b443716894992a79807d04b4c0744f96cc71b65ca0d	1940d1de-1dd7-4c78-a9fe-dc6584763918	t	2026-03-09 01:38:19.159+00	2026-03-08 17:38:19.16+00
23	1	76f150d57a7cf30cfe6d7767b76c30d02755007b08f720027c2826b76ba829b4	4807eb79-5993-42e9-90c5-49d54c324151	t	2026-03-09 01:40:33.257+00	2026-03-08 17:40:33.257+00
22	1	a1db3f2269bbc28cf84c17e106793842a5fe3098d3fce2dbb0d9b74dc3a06cdd	0178110a-99e3-47ea-bd26-1231006ea6e4	t	2026-03-09 01:38:37.109+00	2026-03-08 17:38:37.109+00
24	1	80da89724e0bf9d1a3e47e999a77a616bf8b2259024b0b6c50c373753c2a7d31	4807eb79-5993-42e9-90c5-49d54c324151	t	2026-03-09 02:50:51.806+00	2026-03-08 18:50:51.806+00
25	1	b4e2d2221dab318b9ec1b0ecc64e4207f87bdb1b2aefe62c05ccb34b2ee1c880	0178110a-99e3-47ea-bd26-1231006ea6e4	t	2026-03-09 02:53:09.79+00	2026-03-08 18:53:09.791+00
26	1	e2f05201dbcd873dfa6aa8fd23b8416ccf3de112d565dd8ed4a3954ec697bd86	4807eb79-5993-42e9-90c5-49d54c324151	t	2026-03-09 02:53:09.861+00	2026-03-08 18:53:09.862+00
27	1	737e14327fd971a23ceea702ae656ca4f78bedc0a274f8881a145da1eac5d8c1	0178110a-99e3-47ea-bd26-1231006ea6e4	t	2026-03-09 02:54:16.967+00	2026-03-08 18:54:16.968+00
28	1	5d860f7578226edb003b0285f6bb10e5296803f619204d76e572cf41056956e8	4807eb79-5993-42e9-90c5-49d54c324151	t	2026-03-09 02:54:16.974+00	2026-03-08 18:54:16.975+00
30	1	9f3912db1c546b89a201ee3842bf0b3cc632e5eeb6646f20f98d60ca66396470	0178110a-99e3-47ea-bd26-1231006ea6e4	t	2026-03-09 03:05:46.113+00	2026-03-08 19:05:46.113+00
29	1	1ef3966d7122c9f5d2eac04a8382d8d27b9206c122d818b1283d53fd9b3257ea	4807eb79-5993-42e9-90c5-49d54c324151	t	2026-03-09 03:05:46.112+00	2026-03-08 19:05:46.113+00
32	1	69ea7c224820a44255980a1065f20dd619cb548b4dbd84fd005fe8a06f37494f	4807eb79-5993-42e9-90c5-49d54c324151	t	2026-03-09 03:12:08.685+00	2026-03-08 19:12:08.686+00
33	1	0a329a35e5aed3861af9360325cf96e55cad7db67dfa118cfa1bb1131a2a8f98	4807eb79-5993-42e9-90c5-49d54c324151	t	2026-03-09 03:12:28.157+00	2026-03-08 19:12:28.158+00
31	1	7aef536b548184b53538ed6124e6f787e2fac59a18d3e78c2aec876d23a1f993	0178110a-99e3-47ea-bd26-1231006ea6e4	t	2026-03-09 03:06:46.921+00	2026-03-08 19:06:46.922+00
35	1	614e280b2575d93ed99b77f900bc583049f28d0574b1bf140b3ca59ac01ab42a	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:12:49.965+00	2026-03-08 19:12:49.966+00
36	1	be1b9a6dfbb3652af53b56c8c56a59568ec2d92f732e3afa48c91ff0e46a7f8f	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:13:47.102+00	2026-03-08 19:13:47.103+00
37	1	e2cf84eab7eb538ebecabf0499d3883cff1928b0efb0f7d667ee08f278f4557e	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:14:09.527+00	2026-03-08 19:14:09.528+00
38	1	04062ba6846295145d97d10fdc8072a5c09932a3261d0d80d64080464d60912d	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:16:43.212+00	2026-03-08 19:16:43.212+00
39	1	ba8d946f5b2484eb05df07ab96a34e455bd18a3af38e9f3c6eced0a7f6456179	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:17:10.373+00	2026-03-08 19:17:10.374+00
40	1	983a81569fba12430d2392f82a9f1333a0f715fe7a3b9e8b4a376d4e11ceb970	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:17:29.008+00	2026-03-08 19:17:29.009+00
41	1	3d62b399da72e20f816ee4414f8b6251e76b0c9893730b97a2d12b94e6de2ed9	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:17:49.422+00	2026-03-08 19:17:49.423+00
42	1	a79bd96b5cca72dde008d2748db6ee542ae8f23f8590179017e7e7241eb333a4	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:18:09.113+00	2026-03-08 19:18:09.113+00
43	1	0747b94a08f97e970f943471b6cf56cd0a2924b7c8e13df3db5f5e344ca9bb94	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:18:30.498+00	2026-03-08 19:18:30.498+00
44	1	270634da6aa03fcead8aa3366c47bda72cb57b2a1aebc1bc0e87e0ea57c54103	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:19:47.673+00	2026-03-08 19:19:47.674+00
45	1	e89e5af3fc5b749bfe6f3451f8dca8f5808f792193021a631934d380a5da8e54	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:20:13.043+00	2026-03-08 19:20:13.044+00
46	1	950e9759bbd46f4cd3d17b2d90c027fef9c11d856de732bc276e6ba114e662ea	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:21:31.204+00	2026-03-08 19:21:31.205+00
34	1	c40734802245c5d804217fbb77e3a76f75b90be60fe585889ec77c9fcd46a8b2	4807eb79-5993-42e9-90c5-49d54c324151	t	2026-03-09 03:12:44.397+00	2026-03-08 19:12:44.398+00
47	1	8007694b0267d9ff579e54e90792c7f982119b0cfdb3c2f3ab33e700f39aa7cf	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:34:16.083+00	2026-03-08 19:34:16.084+00
49	1	5e7d37793882ee98f10820e50a3eb99b53ab67282970f3347859393f3ce1b65a	d8697512-db0b-440c-8c93-d9f57786ceee	t	2026-03-09 03:38:50.939+00	2026-03-08 19:38:50.939+00
48	1	e398a19b6452ef24bbbac38e6325b574c0766f37c85466c50683daaa4e4c13f4	32ec98e7-b1a8-42b3-a445-9952934e2a01	t	2026-03-09 03:35:44.626+00	2026-03-08 19:35:44.627+00
3	1	7b8562caaae4634e60fe865a12a2a01e2cbcfb7d24b830364e14394b5b7cfe57	292ae4b6-30c5-4d73-840e-3ac8ef635fbe	t	2026-03-08 06:20:03.65+00	2026-03-07 22:20:03.651+00
50	1	f90e22228f34dc952ba726d48d7f03aec255cafe5e401b72fa5fd6f9c90e5784	d8697512-db0b-440c-8c93-d9f57786ceee	t	2026-03-09 04:16:48.535+00	2026-03-08 20:16:48.536+00
51	1	059500a34ee76de32182af145ababff5976112648789d24d0135286ba8799489	6cf6edcc-3c4d-42a3-917d-8c203dedf738	t	2026-03-09 04:17:12.895+00	2026-03-08 20:17:12.896+00
52	1	64b1dffbbe20349835228a2f1ca7a5e48f1aff86c8b9c1dbf5db390289d19824	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:50:04.796+00	2026-03-08 21:50:04.797+00
53	1	be4a4b7596c48d9c50a820b117e8cc7186d18941d4c4610079699a4af4b5a1b0	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:54:19.157+00	2026-03-08 21:54:19.158+00
54	1	ad42f8c11d62629cda1e739c2171214e1adcb75f7350d70a723715b8c9ae97e2	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:54:25.111+00	2026-03-08 21:54:25.111+00
55	1	662da2e33088de978ac506092250e63e0f9b4bd7d0752554e098dec4a2ae2cdb	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:54:38.104+00	2026-03-08 21:54:38.105+00
56	1	d9432ad6046777be0a0fd7dab5c6b9a5ab1bce4d0cbed225bfba9f238deb473b	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:54:44.097+00	2026-03-08 21:54:44.097+00
57	1	f5678ecf97e051b6c80ca49183a4f6716b131c0366f9d26c821f2159d56dd6a8	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:54:50.063+00	2026-03-08 21:54:50.064+00
61	1	d213b11bdbee0607519589cf9c5a68e1af44951cd87ec5b92a1b4318b5d916b4	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:55:54.13+00	2026-03-08 21:55:54.131+00
62	1	264476f784d306b11cff31741706b4cc30da9b7ceaba6ccec79b301d747ffa9a	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:55:55.067+00	2026-03-08 21:55:55.067+00
63	1	d79d81e0e6be385966dfd45d093689d6bbb78f135f9f8ade5e37d4040d25e18a	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:56:00.096+00	2026-03-08 21:56:00.097+00
64	1	a283526d45ad42eba530fc0887de420485e985eecabedaff1705858d60cd379a	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:56:13.176+00	2026-03-08 21:56:13.177+00
65	1	9deddbe14dea4fc38eb74fcb394cac5583ecd74d91e85a13cabaed4ec366d307	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:56:24.098+00	2026-03-08 21:56:24.099+00
66	1	bba75ac505c689cfa6bcc2f09f92110692f518e1fe82569c820a7e13d454b38e	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:56:33.237+00	2026-03-08 21:56:33.237+00
67	1	30421b5fb8e6b31dc1ee6881dc00fa09e5a17d4561f793edc90847822c444b0c	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:57:00.133+00	2026-03-08 21:57:00.133+00
68	1	cb1305fc19150e6b3157e0b08f4bd6a1e62b14eb0ebdc330adde2fa59193656e	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:57:05.12+00	2026-03-08 21:57:05.12+00
69	1	90c25d844ca4bcf4f724182d9b76a007a835c38147f0c22f6beff1e1ee682a0d	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:57:33.14+00	2026-03-08 21:57:33.141+00
70	1	d3cec048e61bd31c721fa61bb8415140b0c76752a0a09add12c1b8ecff9c5fdb	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 06:01:45.341+00	2026-03-08 22:01:45.342+00
71	1	960548c472abfe6c12697dbd857d488b38b933ed0cab74a0d6a97c27c1e24ca8	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 06:02:16.244+00	2026-03-08 22:02:16.244+00
72	1	b009e30320d78f758f9ad15a7f1323f3faab938e071c3a0cd26fd3331992a372	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 06:47:50.43+00	2026-03-08 22:47:50.431+00
73	1	cf4923305904c8c79fd9e8e5cdaf853885c951fe56466335af1457b6faa7ec57	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 06:51:03.295+00	2026-03-08 22:51:03.297+00
74	1	003c9db3f6e3ba82734134b017cc4a1b4452e6565e1534b5b0bbf3c23efbad4c	702fa665-5f28-433a-8df9-aa88adf39afc	f	2026-03-09 14:18:58.212+00	2026-03-09 06:18:58.216+00
75	1	08011e3d54ae964742221613fe3b646023892b886dfe8e8043a88b8d74f97fab	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:06:34.84+00	2026-03-09 16:06:34.841+00
76	1	13223e09bea0dc613ffb514c3a8c42d031b8126eac2e03785db402f44f65b54d	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:08:03.2+00	2026-03-09 16:08:03.201+00
77	1	719fa10a0039b31a0cc72f97c39f47b9f035a33896788a8815f670b228c94b05	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:08:57.885+00	2026-03-09 16:08:57.886+00
78	1	2a51d51b07a0040776ef195e55541c06cfd39b4b934c7b3f1e836e040ffdb95f	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:09:10.85+00	2026-03-09 16:09:10.851+00
79	1	d38104ef1045f482ba2e93be38b649d631b13a87165b4a0ec858a2aa7632985d	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:09:53.424+00	2026-03-09 16:09:53.425+00
80	1	469f3a1b1e0d357a65775d7c3c55fc49c20d78e30b9392eb663c8350620e5627	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:12:34.374+00	2026-03-09 16:12:34.375+00
81	1	e23949cf741913c53387770cba25571e424c364fea7717188eba418740b4b115	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:15:45.456+00	2026-03-09 16:15:45.457+00
82	1	f9c69809bae2209237c925c92b11ead33392379efb2bdc2ff82c7e30cf6ea2a7	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:18:24.26+00	2026-03-09 16:18:24.262+00
83	1	887fca783ab602847abdb56486a8f2235852766fc9a6b656e17ed5da5fe8515e	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:19:18.149+00	2026-03-09 16:19:18.15+00
84	1	028783c5921529f51948cb2050182f81a69235700ffd2e566032fea2896388e7	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:21:31.709+00	2026-03-09 16:21:31.71+00
85	1	ce6660a466582f1c3bc21e03dad3136ba0ce019818a01ea85c702cc98ee843b4	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:30:11.537+00	2026-03-09 16:30:11.538+00
86	1	ae79e8ee3e08753e0edaf521f771785d0d451f4f08bbf416582bf8f9ead9207a	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:30:12.279+00	2026-03-09 16:30:12.28+00
87	1	5cc1b3aefe8fcc7f9d87c3bdf526fb4976cb31b329dff3381f048146c8c51a03	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:30:14.036+00	2026-03-09 16:30:14.037+00
88	1	ccca66b11e6bdb3cad8f3eb2e8c19f0119f2c3d96d54247c3c35bbfb2edc2aee	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:30:16.565+00	2026-03-09 16:30:16.565+00
89	1	c36e734efdcb013a312814ebd87702563a3c7a5b7b47096db38816927df470b8	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:30:17.998+00	2026-03-09 16:30:17.998+00
90	1	c6d59376d651d4821c2c18708c36c622974ae90f6e8e98f09ddc9ed314f709aa	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:30:19.552+00	2026-03-09 16:30:19.552+00
91	1	57a8e0299d7cf4f1da2038d7e72608861266768e22f49f048b4cc5a5fa581920	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:31:57.766+00	2026-03-09 16:31:57.767+00
92	1	768ed6ac631df9f0672878b13af4724c24f59e5773e731663168e488bf12807e	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:33:29.121+00	2026-03-09 16:33:29.122+00
93	1	3d5410d532845dc83b091705e71e9e74323456c45a1827ed37595a5eaf133aed	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 01:50:01.853+00	2026-03-09 17:50:01.857+00
94	1	10e3481208fe9ed2d6ffb0c48b33ba526d6c47f784332afb7cced6ce4971acb7	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 01:50:02.485+00	2026-03-09 17:50:02.485+00
95	1	190aa6c421fce017f4313038b0b71bb64afb1416f883b8ec190b1550bdcf131d	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 01:50:03.468+00	2026-03-09 17:50:03.469+00
96	1	d2178e425089a8d72e41c69a023fc6621aba551bebb5f97aa524ba1becc16009	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 01:54:05.508+00	2026-03-09 17:54:05.509+00
97	1	645bd4d08f5f5446928627eef398e40afc9c8299327fc45bb7c1e17f32417b67	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 01:57:44.527+00	2026-03-09 17:57:44.528+00
98	1	ab3ec3b22997b869bf6753b6899afa68cde59cfb07f1677c80591dd398957e4f	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:01:21.666+00	2026-03-09 19:01:21.668+00
99	1	38571d3624c2fdc8c65556a56ef3d09be61e5406fa4bd7c80eaa6362bb5d0018	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:01:22.453+00	2026-03-09 19:01:22.453+00
100	1	5290cba410f8958293a1df78a65f324428a5d6d46ff2664323442aec94f72de3	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:02:49.511+00	2026-03-09 19:02:49.512+00
101	1	ff4e83dc9e31784ee2fd5e9bfcfa492be83385f44b3dd12a1dce251e6e236072	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:17:09.561+00	2026-03-09 19:17:09.562+00
102	1	5f126e154417b1f43d8170d2d29e80d6b52b713170d5828b4ce406da476c83d8	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:17:14.498+00	2026-03-09 19:17:14.499+00
103	1	f35374dce887b16c6b63026f4751a3783630aeb25e396461ea29634de82da662	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:17:38.522+00	2026-03-09 19:17:38.523+00
104	1	e6bfc57ec100c8ffa7a4c83e1a13086bd32cabd5bcb69dfccb54acb628f12675	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:45:34.614+00	2026-03-09 19:45:34.616+00
105	1	e40a2cfa5dde0a4442224fc9a937314dc49b93d9eb598adb05b0695462572b87	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:46:28.523+00	2026-03-09 19:46:28.524+00
106	1	4e28e8c83ea077484883d567fa745ca8d58c681e4f46501f04604f5f2c014d1e	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:47:29.52+00	2026-03-09 19:47:29.52+00
107	1	186d7b865e504f235f75e2c3ddd6f1be64169e7b36580713293456275b0e708d	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:52:43.599+00	2026-03-09 19:52:43.6+00
108	1	f8508549ca7bcb986a5879422af0c6f7fcdff12c81f52ef80b1757f061cc3e5f	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:53:05.583+00	2026-03-09 19:53:05.584+00
109	1	c9b1d2903cd667e5266d131bf5a4ed8d7bfc7e3ecfeb97ef4e22d2729eb7276a	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:57:11.565+00	2026-03-09 19:57:11.565+00
110	1	0dcee3608597a9bc2d1052f1878f5bca9d45173c094f046d88850f3f55c53122	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 04:00:57.622+00	2026-03-09 20:00:57.623+00
111	1	b27480111e4f2a536e88eb37c57032e9e4eb2875138916542ea54e0ef31e3f7d	63ac93a0-6354-4c24-a4a0-415e262f06f5	f	2026-03-10 04:03:42.463+00	2026-03-09 20:03:42.464+00
112	1	20154e70c72126bdfc6500b344610398a12d1659192b58566073341aa7886e7c	9ecc1774-8b98-4cca-acf1-7ce7432dba20	f	2026-03-10 04:03:48.077+00	2026-03-09 20:03:48.078+00
\.


--
-- Data for Name: schema_version; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.schema_version (id, version, applied_at) FROM stdin;
\.


--
-- Data for Name: system_config; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.system_config (key, value, data_type, description, updated_at, updated_by) FROM stdin;
max_sessions_per_user	2	number	Maximum concurrent sessions per user	2026-03-07 22:19:06.402+00	\N
session_timeout_minutes	30	number	Session timeout in minutes	2026-03-07 22:19:06.411+00	\N
lockout_threshold	5	number	Failed login attempts before lockout	2026-03-07 22:19:06.413+00	\N
lockout_duration_minutes	30	number	Lockout duration in minutes	2026-03-07 22:19:06.415+00	\N
fiscal_year_start_month	9	number	Fiscal year start month (1-12)	2026-03-07 22:19:06.42+00	\N
fiscal_year_range	10	number	Fiscal year range in years	2026-03-07 22:19:06.422+00	\N
autosave_interval_seconds	30	number	Auto-save interval in seconds	2026-03-07 22:19:06.423+00	\N
schoolYear	2025-2026	string	Current school year displayed in context bar	2026-03-07 22:19:06.424+00	\N
\.


--
-- Data for Name: tariffs; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.tariffs (id, code, label, description, version, created_at, updated_at, created_by, updated_by) FROM stdin;
3	PLEIN	Plein Tarif	\N	1	2026-03-09 20:19:33.075+00	2026-03-09 20:20:11.972+00	2	2
4	RP	Reduit Personnel	\N	1	2026-03-09 20:19:33.077+00	2026-03-09 20:20:11.973+00	2	2
5	R3P	Reduit 3+	\N	1	2026-03-09 20:19:33.078+00	2026-03-09 20:20:11.974+00	2	2
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.users (id, email, password_hash, role, is_active, failed_attempts, locked_until, force_password_reset, last_login_at, created_at, updated_at) FROM stdin;
1	admin@efir.edu.sa	$2b$12$vGZDrNa/MawU3H7cJFvGI.0clcxYGcAWd17JgyrZ4z0N7nSITcGdK	Admin	t	0	\N	t	2026-03-09 20:03:48.068+00	2026-03-07 22:19:06.393+00	2026-03-09 20:03:48.074+00
2	migration@system	$2b$12$zjYL3WnFLBa38U1A75IMneixRUbmQIKMJEvsXk698DyCRbgSb4WBi	Admin	f	0	\N	f	\N	2026-03-09 20:15:46.255+00	2026-03-09 20:15:46.255+00
\.


--
-- Name: academic_years_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.academic_years_id_seq', 12, true);


--
-- Name: actuals_import_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.actuals_import_log_id_seq', 14, true);


--
-- Name: assumptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.assumptions_id_seq', 1, false);


--
-- Name: audit_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.audit_entries_id_seq', 143, true);


--
-- Name: budget_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.budget_versions_id_seq', 13, true);


--
-- Name: calculation_audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.calculation_audit_log_id_seq', 1, false);


--
-- Name: category_monthly_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.category_monthly_costs_id_seq', 1, false);


--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.chart_of_accounts_id_seq', 153, true);


--
-- Name: cohort_parameters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.cohort_parameters_id_seq', 1, false);


--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.departments_id_seq', 11, true);


--
-- Name: dhg_grille_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.dhg_grille_config_id_seq', 296, true);


--
-- Name: dhg_requirements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.dhg_requirements_id_seq', 1, false);


--
-- Name: discount_policies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.discount_policies_id_seq', 6, true);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.employees_id_seq', 120, true);


--
-- Name: enrollment_detail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.enrollment_detail_id_seq', 428, true);


--
-- Name: enrollment_headcount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.enrollment_headcount_id_seq', 210, true);


--
-- Name: eos_provisions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.eos_provisions_id_seq', 1, false);


--
-- Name: fee_grids_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.fee_grids_id_seq', 540, true);


--
-- Name: fiscal_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.fiscal_periods_id_seq', 12, true);


--
-- Name: grade_levels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.grade_levels_id_seq', 90, true);


--
-- Name: monthly_budget_summary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.monthly_budget_summary_id_seq', 1, false);


--
-- Name: monthly_other_revenue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.monthly_other_revenue_id_seq', 1, false);


--
-- Name: monthly_revenue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.monthly_revenue_id_seq', 1, false);


--
-- Name: monthly_staff_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.monthly_staff_costs_id_seq', 1, false);


--
-- Name: nationalities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.nationalities_id_seq', 9, true);


--
-- Name: nationality_breakdown_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.nationality_breakdown_id_seq', 1, false);


--
-- Name: other_revenue_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.other_revenue_items_id_seq', 42, true);


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.refresh_tokens_id_seq', 112, true);


--
-- Name: tariffs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.tariffs_id_seq', 8, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: academic_years academic_years_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.academic_years
    ADD CONSTRAINT academic_years_pkey PRIMARY KEY (id);


--
-- Name: actuals_import_log actuals_import_log_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.actuals_import_log
    ADD CONSTRAINT actuals_import_log_pkey PRIMARY KEY (id);


--
-- Name: assumptions assumptions_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.assumptions
    ADD CONSTRAINT assumptions_pkey PRIMARY KEY (id);


--
-- Name: audit_entries audit_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.audit_entries
    ADD CONSTRAINT audit_entries_pkey PRIMARY KEY (id);


--
-- Name: budget_versions budget_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.budget_versions
    ADD CONSTRAINT budget_versions_pkey PRIMARY KEY (id);


--
-- Name: calculation_audit_log calculation_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.calculation_audit_log
    ADD CONSTRAINT calculation_audit_log_pkey PRIMARY KEY (id);


--
-- Name: category_monthly_costs category_monthly_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.category_monthly_costs
    ADD CONSTRAINT category_monthly_costs_pkey PRIMARY KEY (id);


--
-- Name: chart_of_accounts chart_of_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_pkey PRIMARY KEY (id);


--
-- Name: cohort_parameters cohort_parameters_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.cohort_parameters
    ADD CONSTRAINT cohort_parameters_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: dhg_grille_config dhg_grille_config_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.dhg_grille_config
    ADD CONSTRAINT dhg_grille_config_pkey PRIMARY KEY (id);


--
-- Name: dhg_requirements dhg_requirements_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.dhg_requirements
    ADD CONSTRAINT dhg_requirements_pkey PRIMARY KEY (id);


--
-- Name: discount_policies discount_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.discount_policies
    ADD CONSTRAINT discount_policies_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: enrollment_detail enrollment_detail_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_detail
    ADD CONSTRAINT enrollment_detail_pkey PRIMARY KEY (id);


--
-- Name: enrollment_headcount enrollment_headcount_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_headcount
    ADD CONSTRAINT enrollment_headcount_pkey PRIMARY KEY (id);


--
-- Name: eos_provisions eos_provisions_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.eos_provisions
    ADD CONSTRAINT eos_provisions_pkey PRIMARY KEY (id);


--
-- Name: fee_grids fee_grids_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.fee_grids
    ADD CONSTRAINT fee_grids_pkey PRIMARY KEY (id);


--
-- Name: fiscal_periods fiscal_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.fiscal_periods
    ADD CONSTRAINT fiscal_periods_pkey PRIMARY KEY (id);


--
-- Name: grade_levels grade_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.grade_levels
    ADD CONSTRAINT grade_levels_pkey PRIMARY KEY (id);


--
-- Name: monthly_budget_summary monthly_budget_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_budget_summary
    ADD CONSTRAINT monthly_budget_summary_pkey PRIMARY KEY (id);


--
-- Name: monthly_other_revenue monthly_other_revenue_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_other_revenue
    ADD CONSTRAINT monthly_other_revenue_pkey PRIMARY KEY (id);


--
-- Name: monthly_revenue monthly_revenue_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_revenue
    ADD CONSTRAINT monthly_revenue_pkey PRIMARY KEY (id);


--
-- Name: monthly_staff_costs monthly_staff_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_staff_costs
    ADD CONSTRAINT monthly_staff_costs_pkey PRIMARY KEY (id);


--
-- Name: nationalities nationalities_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.nationalities
    ADD CONSTRAINT nationalities_pkey PRIMARY KEY (id);


--
-- Name: nationality_breakdown nationality_breakdown_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.nationality_breakdown
    ADD CONSTRAINT nationality_breakdown_pkey PRIMARY KEY (id);


--
-- Name: other_revenue_items other_revenue_items_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.other_revenue_items
    ADD CONSTRAINT other_revenue_items_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: schema_version schema_version_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.schema_version
    ADD CONSTRAINT schema_version_pkey PRIMARY KEY (id);


--
-- Name: system_config system_config_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_pkey PRIMARY KEY (key);


--
-- Name: tariffs tariffs_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.tariffs
    ADD CONSTRAINT tariffs_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: academic_years_fiscal_year_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX academic_years_fiscal_year_key ON public.academic_years USING btree (fiscal_year);


--
-- Name: assumptions_key_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX assumptions_key_key ON public.assumptions USING btree (key);


--
-- Name: chart_of_accounts_account_code_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX chart_of_accounts_account_code_key ON public.chart_of_accounts USING btree (account_code);


--
-- Name: departments_code_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX departments_code_key ON public.departments USING btree (code);


--
-- Name: eos_provisions_employee_id_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX eos_provisions_employee_id_key ON public.eos_provisions USING btree (employee_id);


--
-- Name: grade_levels_grade_code_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX grade_levels_grade_code_key ON public.grade_levels USING btree (grade_code);


--
-- Name: idx_audit_entries_created; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_audit_entries_created ON public.audit_entries USING btree (created_at);


--
-- Name: idx_audit_entries_operation; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_audit_entries_operation ON public.audit_entries USING btree (operation);


--
-- Name: idx_audit_entries_table_record; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_audit_entries_table_record ON public.audit_entries USING btree (table_name, record_id);


--
-- Name: idx_audit_entries_user; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_audit_entries_user ON public.audit_entries USING btree (user_id);


--
-- Name: idx_budget_versions_created_by; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_budget_versions_created_by ON public.budget_versions USING btree (created_by_id);


--
-- Name: idx_budget_versions_fiscal_year; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_budget_versions_fiscal_year ON public.budget_versions USING btree (fiscal_year);


--
-- Name: idx_budget_versions_source; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_budget_versions_source ON public.budget_versions USING btree (source_version_id);


--
-- Name: idx_budget_versions_status; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_budget_versions_status ON public.budget_versions USING btree (status);


--
-- Name: idx_budget_versions_updated_by; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_budget_versions_updated_by ON public.budget_versions USING btree (updated_by_id);


--
-- Name: idx_calc_audit_module_status; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_calc_audit_module_status ON public.calculation_audit_log USING btree (module, status);


--
-- Name: idx_calc_audit_run_id; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_calc_audit_run_id ON public.calculation_audit_log USING btree (run_id);


--
-- Name: idx_calc_audit_triggered_by; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_calc_audit_triggered_by ON public.calculation_audit_log USING btree (triggered_by);


--
-- Name: idx_calc_audit_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_calc_audit_version ON public.calculation_audit_log USING btree (version_id);


--
-- Name: idx_category_monthly_costs_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_category_monthly_costs_version ON public.category_monthly_costs USING btree (version_id);


--
-- Name: idx_cohort_parameters_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_cohort_parameters_version ON public.cohort_parameters USING btree (version_id);


--
-- Name: idx_dhg_grille_grade; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_dhg_grille_grade ON public.dhg_grille_config USING btree (grade_level);


--
-- Name: idx_dhg_requirements_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_dhg_requirements_version ON public.dhg_requirements USING btree (version_id);


--
-- Name: idx_discount_policies_calc; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_discount_policies_calc ON public.discount_policies USING btree (version_id, tariff, nationality);


--
-- Name: idx_discount_policies_created_by; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_discount_policies_created_by ON public.discount_policies USING btree (created_by);


--
-- Name: idx_employees_department; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_employees_department ON public.employees USING btree (version_id, department);


--
-- Name: idx_employees_status; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_employees_status ON public.employees USING btree (version_id, status);


--
-- Name: idx_employees_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_employees_version ON public.employees USING btree (version_id);


--
-- Name: idx_enrollment_detail_version_period_grade; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_enrollment_detail_version_period_grade ON public.enrollment_detail USING btree (version_id, academic_period, grade_level);


--
-- Name: idx_enrollment_headcount_version_period; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_enrollment_headcount_version_period ON public.enrollment_headcount USING btree (version_id, academic_period);


--
-- Name: idx_eos_provisions_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_eos_provisions_version ON public.eos_provisions USING btree (version_id);


--
-- Name: idx_fee_grids_created_by; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_fee_grids_created_by ON public.fee_grids USING btree (created_by);


--
-- Name: idx_fee_grids_revenue_calc; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_fee_grids_revenue_calc ON public.fee_grids USING btree (version_id, academic_period, grade_level, nationality, tariff);


--
-- Name: idx_fiscal_periods_actual_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_fiscal_periods_actual_version ON public.fiscal_periods USING btree (actual_version_id);


--
-- Name: idx_fiscal_periods_fiscal_year; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_fiscal_periods_fiscal_year ON public.fiscal_periods USING btree (fiscal_year);


--
-- Name: idx_fiscal_periods_locked_by; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_fiscal_periods_locked_by ON public.fiscal_periods USING btree (locked_by_id);


--
-- Name: idx_fiscal_periods_updated_by; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_fiscal_periods_updated_by ON public.fiscal_periods USING btree (updated_by_id);


--
-- Name: idx_monthly_other_revenue_calculated_by; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_monthly_other_revenue_calculated_by ON public.monthly_other_revenue USING btree (calculated_by);


--
-- Name: idx_monthly_other_revenue_version_category; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_monthly_other_revenue_version_category ON public.monthly_other_revenue USING btree (version_id, executive_category);


--
-- Name: idx_monthly_other_revenue_version_month; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_monthly_other_revenue_version_month ON public.monthly_other_revenue USING btree (version_id, month);


--
-- Name: idx_monthly_revenue_calculated_by; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_monthly_revenue_calculated_by ON public.monthly_revenue USING btree (calculated_by);


--
-- Name: idx_monthly_revenue_version_month; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_monthly_revenue_version_month ON public.monthly_revenue USING btree (version_id, month);


--
-- Name: idx_monthly_revenue_version_period; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_monthly_revenue_version_period ON public.monthly_revenue USING btree (version_id, academic_period);


--
-- Name: idx_monthly_staff_costs_employee; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_monthly_staff_costs_employee ON public.monthly_staff_costs USING btree (employee_id);


--
-- Name: idx_monthly_staff_costs_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_monthly_staff_costs_version ON public.monthly_staff_costs USING btree (version_id);


--
-- Name: idx_monthly_staff_costs_version_month; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_monthly_staff_costs_version_month ON public.monthly_staff_costs USING btree (version_id, month);


--
-- Name: idx_monthly_summary_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_monthly_summary_version ON public.monthly_budget_summary USING btree (version_id);


--
-- Name: idx_nationality_breakdown_version_period; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_nationality_breakdown_version_period ON public.nationality_breakdown USING btree (version_id, academic_period);


--
-- Name: idx_other_revenue_items_created_by; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_other_revenue_items_created_by ON public.other_revenue_items USING btree (created_by);


--
-- Name: idx_other_revenue_items_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_other_revenue_items_version ON public.other_revenue_items USING btree (version_id);


--
-- Name: idx_refresh_tokens_expires; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_refresh_tokens_expires ON public.refresh_tokens USING btree (expires_at);


--
-- Name: idx_refresh_tokens_family; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_refresh_tokens_family ON public.refresh_tokens USING btree (family_id);


--
-- Name: idx_refresh_tokens_user_active; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_refresh_tokens_user_active ON public.refresh_tokens USING btree (user_id, is_revoked);


--
-- Name: nationalities_code_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX nationalities_code_key ON public.nationalities USING btree (code);


--
-- Name: refresh_tokens_token_hash_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX refresh_tokens_token_hash_key ON public.refresh_tokens USING btree (token_hash);


--
-- Name: tariffs_code_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX tariffs_code_key ON public.tariffs USING btree (code);


--
-- Name: uq_budget_version_name_fy; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_budget_version_name_fy ON public.budget_versions USING btree (fiscal_year, name);


--
-- Name: uq_category_monthly_cost; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_category_monthly_cost ON public.category_monthly_costs USING btree (version_id, month, category);


--
-- Name: uq_cohort_parameter; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_cohort_parameter ON public.cohort_parameters USING btree (version_id, grade_level);


--
-- Name: uq_dhg_grille; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_dhg_grille ON public.dhg_grille_config USING btree (grade_level, subject, effective_from_year);


--
-- Name: uq_dhg_requirement; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_dhg_requirement ON public.dhg_requirements USING btree (version_id, academic_period, grade_level);


--
-- Name: uq_discount_policy; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_discount_policy ON public.discount_policies USING btree (version_id, tariff, nationality);


--
-- Name: uq_employee_code_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_employee_code_version ON public.employees USING btree (version_id, employee_code);


--
-- Name: uq_enrollment_detail; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_enrollment_detail ON public.enrollment_detail USING btree (version_id, academic_period, grade_level, nationality, tariff);


--
-- Name: uq_enrollment_headcount; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_enrollment_headcount ON public.enrollment_headcount USING btree (version_id, academic_period, grade_level);


--
-- Name: uq_eos_provision; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_eos_provision ON public.eos_provisions USING btree (version_id, employee_id);


--
-- Name: uq_fee_grid; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_fee_grid ON public.fee_grids USING btree (version_id, academic_period, grade_level, nationality, tariff);


--
-- Name: uq_fiscal_period; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_fiscal_period ON public.fiscal_periods USING btree (fiscal_year, month);


--
-- Name: uq_monthly_other_revenue; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_monthly_other_revenue ON public.monthly_other_revenue USING btree (version_id, scenario_name, line_item_name, month);


--
-- Name: uq_monthly_revenue; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_monthly_revenue ON public.monthly_revenue USING btree (version_id, scenario_name, academic_period, grade_level, nationality, tariff, month);


--
-- Name: uq_monthly_staff_cost; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_monthly_staff_cost ON public.monthly_staff_costs USING btree (version_id, employee_id, month);


--
-- Name: uq_monthly_summary; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_monthly_summary ON public.monthly_budget_summary USING btree (version_id, month);


--
-- Name: uq_nationality_breakdown; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_nationality_breakdown ON public.nationality_breakdown USING btree (version_id, academic_period, grade_level, nationality);


--
-- Name: uq_other_revenue_item; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_other_revenue_item ON public.other_revenue_items USING btree (version_id, line_item_name);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: academic_years academic_years_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.academic_years
    ADD CONSTRAINT academic_years_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: academic_years academic_years_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.academic_years
    ADD CONSTRAINT academic_years_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: actuals_import_log actuals_import_log_imported_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.actuals_import_log
    ADD CONSTRAINT actuals_import_log_imported_by_id_fkey FOREIGN KEY (imported_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: actuals_import_log actuals_import_log_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.actuals_import_log
    ADD CONSTRAINT actuals_import_log_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: assumptions assumptions_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.assumptions
    ADD CONSTRAINT assumptions_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: audit_entries audit_entries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.audit_entries
    ADD CONSTRAINT audit_entries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: budget_versions budget_versions_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.budget_versions
    ADD CONSTRAINT budget_versions_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: budget_versions budget_versions_source_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.budget_versions
    ADD CONSTRAINT budget_versions_source_version_id_fkey FOREIGN KEY (source_version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: budget_versions budget_versions_updated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.budget_versions
    ADD CONSTRAINT budget_versions_updated_by_id_fkey FOREIGN KEY (updated_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: calculation_audit_log calculation_audit_log_triggered_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.calculation_audit_log
    ADD CONSTRAINT calculation_audit_log_triggered_by_fkey FOREIGN KEY (triggered_by) REFERENCES public.users(id);


--
-- Name: calculation_audit_log calculation_audit_log_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.calculation_audit_log
    ADD CONSTRAINT calculation_audit_log_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: category_monthly_costs category_monthly_costs_calculated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.category_monthly_costs
    ADD CONSTRAINT category_monthly_costs_calculated_by_fkey FOREIGN KEY (calculated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: category_monthly_costs category_monthly_costs_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.category_monthly_costs
    ADD CONSTRAINT category_monthly_costs_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chart_of_accounts chart_of_accounts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: chart_of_accounts chart_of_accounts_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: cohort_parameters cohort_parameters_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.cohort_parameters
    ADD CONSTRAINT cohort_parameters_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON DELETE CASCADE;


--
-- Name: departments departments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: departments departments_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: dhg_requirements dhg_requirements_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.dhg_requirements
    ADD CONSTRAINT dhg_requirements_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON DELETE CASCADE;


--
-- Name: discount_policies discount_policies_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.discount_policies
    ADD CONSTRAINT discount_policies_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: discount_policies discount_policies_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.discount_policies
    ADD CONSTRAINT discount_policies_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: discount_policies discount_policies_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.discount_policies
    ADD CONSTRAINT discount_policies_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: employees employees_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: employees employees_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: employees employees_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: enrollment_detail enrollment_detail_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_detail
    ADD CONSTRAINT enrollment_detail_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: enrollment_detail enrollment_detail_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_detail
    ADD CONSTRAINT enrollment_detail_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: enrollment_detail enrollment_detail_version_id_academic_period_grade_level_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_detail
    ADD CONSTRAINT enrollment_detail_version_id_academic_period_grade_level_fkey FOREIGN KEY (version_id, academic_period, grade_level) REFERENCES public.enrollment_headcount(version_id, academic_period, grade_level) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: enrollment_detail enrollment_detail_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_detail
    ADD CONSTRAINT enrollment_detail_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: enrollment_headcount enrollment_headcount_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_headcount
    ADD CONSTRAINT enrollment_headcount_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: enrollment_headcount enrollment_headcount_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_headcount
    ADD CONSTRAINT enrollment_headcount_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: enrollment_headcount enrollment_headcount_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_headcount
    ADD CONSTRAINT enrollment_headcount_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: eos_provisions eos_provisions_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.eos_provisions
    ADD CONSTRAINT eos_provisions_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: eos_provisions eos_provisions_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.eos_provisions
    ADD CONSTRAINT eos_provisions_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fee_grids fee_grids_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.fee_grids
    ADD CONSTRAINT fee_grids_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: fee_grids fee_grids_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.fee_grids
    ADD CONSTRAINT fee_grids_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fee_grids fee_grids_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.fee_grids
    ADD CONSTRAINT fee_grids_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fiscal_periods fiscal_periods_actual_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.fiscal_periods
    ADD CONSTRAINT fiscal_periods_actual_version_id_fkey FOREIGN KEY (actual_version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fiscal_periods fiscal_periods_locked_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.fiscal_periods
    ADD CONSTRAINT fiscal_periods_locked_by_id_fkey FOREIGN KEY (locked_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fiscal_periods fiscal_periods_updated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.fiscal_periods
    ADD CONSTRAINT fiscal_periods_updated_by_id_fkey FOREIGN KEY (updated_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: monthly_budget_summary monthly_budget_summary_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_budget_summary
    ADD CONSTRAINT monthly_budget_summary_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: monthly_other_revenue monthly_other_revenue_calculated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_other_revenue
    ADD CONSTRAINT monthly_other_revenue_calculated_by_fkey FOREIGN KEY (calculated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: monthly_other_revenue monthly_other_revenue_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_other_revenue
    ADD CONSTRAINT monthly_other_revenue_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: monthly_revenue monthly_revenue_calculated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_revenue
    ADD CONSTRAINT monthly_revenue_calculated_by_fkey FOREIGN KEY (calculated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: monthly_revenue monthly_revenue_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_revenue
    ADD CONSTRAINT monthly_revenue_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: monthly_staff_costs monthly_staff_costs_calculated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_staff_costs
    ADD CONSTRAINT monthly_staff_costs_calculated_by_fkey FOREIGN KEY (calculated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: monthly_staff_costs monthly_staff_costs_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_staff_costs
    ADD CONSTRAINT monthly_staff_costs_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: monthly_staff_costs monthly_staff_costs_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_staff_costs
    ADD CONSTRAINT monthly_staff_costs_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: nationalities nationalities_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.nationalities
    ADD CONSTRAINT nationalities_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: nationalities nationalities_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.nationalities
    ADD CONSTRAINT nationalities_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: nationality_breakdown nationality_breakdown_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.nationality_breakdown
    ADD CONSTRAINT nationality_breakdown_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON DELETE CASCADE;


--
-- Name: other_revenue_items other_revenue_items_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.other_revenue_items
    ADD CONSTRAINT other_revenue_items_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: other_revenue_items other_revenue_items_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.other_revenue_items
    ADD CONSTRAINT other_revenue_items_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: other_revenue_items other_revenue_items_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.other_revenue_items
    ADD CONSTRAINT other_revenue_items_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: system_config system_config_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tariffs tariffs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.tariffs
    ADD CONSTRAINT tariffs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tariffs tariffs_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.tariffs
    ADD CONSTRAINT tariffs_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TABLE audit_entries; Type: ACL; Schema: public; Owner: app_user
--

REVOKE SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.audit_entries FROM app_user;
GRANT SELECT,INSERT,REFERENCES,TRIGGER,TRUNCATE ON TABLE public.audit_entries TO app_user;


--
-- PostgreSQL database dump complete
--

\unrestrict eeUbA8mCfJdW8Qe6sd6m9WKed65b098gBKaglXMk8VPPFgfyjSVWSqHi2B6EbFC

