--
-- PostgreSQL database dump
--

\restrict 14oWCJj2iBoqxpg1OUC9VhKwq76vMlsPw7uG0coawRUnGRS3oz5wwIP8LksXEgv

-- Dumped from database version 16.13
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: account_status; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE public.account_status AS ENUM (
    'ACTIVE',
    'INACTIVE'
);


ALTER TYPE public.account_status OWNER TO app_user;

--
-- Name: account_type; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE public.account_type AS ENUM (
    'REVENUE',
    'EXPENSE',
    'ASSET',
    'LIABILITY'
);


ALTER TYPE public.account_type OWNER TO app_user;

--
-- Name: assumption_value_type; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE public.assumption_value_type AS ENUM (
    'PERCENTAGE',
    'CURRENCY',
    'INTEGER',
    'DECIMAL',
    'TEXT'
);


ALTER TYPE public.assumption_value_type OWNER TO app_user;

--
-- Name: center_type; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE public.center_type AS ENUM (
    'PROFIT_CENTER',
    'COST_CENTER'
);


ALTER TYPE public.center_type OWNER TO app_user;

--
-- Name: department_band; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE public.department_band AS ENUM (
    'MATERNELLE',
    'ELEMENTAIRE',
    'COLLEGE',
    'LYCEE',
    'NON_ACADEMIC'
);


ALTER TYPE public.department_band OWNER TO app_user;

--
-- Name: grade_band; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE public.grade_band AS ENUM (
    'MATERNELLE',
    'ELEMENTAIRE',
    'COLLEGE',
    'LYCEE'
);


ALTER TYPE public.grade_band OWNER TO app_user;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE public.user_role AS ENUM (
    'Admin',
    'BudgetOwner',
    'Editor',
    'Viewer'
);


ALTER TYPE public.user_role OWNER TO app_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO app_user;

--
-- Name: academic_years; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.academic_years (
    id integer NOT NULL,
    fiscal_year character varying(6) NOT NULL,
    ay1_start date NOT NULL,
    ay1_end date NOT NULL,
    ay2_start date NOT NULL,
    ay2_end date NOT NULL,
    summer_start date NOT NULL,
    summer_end date NOT NULL,
    academic_weeks integer NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer NOT NULL,
    updated_by integer NOT NULL,
    CONSTRAINT chk_academic_weeks CHECK (((academic_weeks >= 1) AND (academic_weeks <= 52))),
    CONSTRAINT chk_date_ordering CHECK (((ay1_start < ay1_end) AND (ay1_end <= summer_start) AND (summer_start < summer_end) AND (summer_end <= ay2_start) AND (ay2_start < ay2_end)))
);


ALTER TABLE public.academic_years OWNER TO app_user;

--
-- Name: academic_years_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.academic_years_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.academic_years_id_seq OWNER TO app_user;

--
-- Name: academic_years_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.academic_years_id_seq OWNED BY public.academic_years.id;


--
-- Name: actuals_import_log; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.actuals_import_log (
    id integer NOT NULL,
    version_id integer NOT NULL,
    module character varying(12) NOT NULL,
    source_file character varying(255) NOT NULL,
    validation_status character varying(10) NOT NULL,
    rows_imported integer DEFAULT 0 NOT NULL,
    imported_by_id integer NOT NULL,
    imported_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.actuals_import_log OWNER TO app_user;

--
-- Name: actuals_import_log_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.actuals_import_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.actuals_import_log_id_seq OWNER TO app_user;

--
-- Name: actuals_import_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.actuals_import_log_id_seq OWNED BY public.actuals_import_log.id;


--
-- Name: assumptions; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.assumptions (
    id integer NOT NULL,
    key character varying(50) NOT NULL,
    value character varying(500) NOT NULL,
    unit character varying(20) NOT NULL,
    section character varying(50) NOT NULL,
    label character varying(100) NOT NULL,
    value_type public.assumption_value_type NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    updated_by integer
);


ALTER TABLE public.assumptions OWNER TO app_user;

--
-- Name: assumptions_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.assumptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.assumptions_id_seq OWNER TO app_user;

--
-- Name: assumptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.assumptions_id_seq OWNED BY public.assumptions.id;


--
-- Name: audit_entries; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.audit_entries (
    id integer NOT NULL,
    user_id integer,
    operation character varying(50) NOT NULL,
    table_name character varying(100),
    record_id integer,
    old_values jsonb,
    new_values jsonb,
    ip_address character varying(45),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    user_email character varying(255),
    session_id character varying(100),
    audit_note text
);


ALTER TABLE public.audit_entries OWNER TO app_user;

--
-- Name: audit_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.audit_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_entries_id_seq OWNER TO app_user;

--
-- Name: audit_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.audit_entries_id_seq OWNED BY public.audit_entries.id;


--
-- Name: budget_versions; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.budget_versions (
    id integer NOT NULL,
    fiscal_year smallint NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(10) NOT NULL,
    status character varying(10) DEFAULT 'Draft'::character varying NOT NULL,
    description text,
    data_source character varying(12) DEFAULT 'CALCULATED'::character varying NOT NULL,
    source_version_id integer,
    modification_count integer DEFAULT 0 NOT NULL,
    stale_modules text[] DEFAULT ARRAY[]::text[],
    created_by_id integer NOT NULL,
    published_at timestamp with time zone,
    locked_at timestamp with time zone,
    archived_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    updated_by_id integer
);


ALTER TABLE public.budget_versions OWNER TO app_user;

--
-- Name: budget_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.budget_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_versions_id_seq OWNER TO app_user;

--
-- Name: budget_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.budget_versions_id_seq OWNED BY public.budget_versions.id;


--
-- Name: calculation_audit_log; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.calculation_audit_log (
    id integer NOT NULL,
    version_id integer,
    run_id uuid NOT NULL,
    module character varying(20) DEFAULT 'ENROLLMENT'::character varying NOT NULL,
    status character varying(20) DEFAULT 'STARTED'::character varying NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    duration_ms integer,
    input_summary jsonb,
    output_summary jsonb,
    triggered_by integer
);


ALTER TABLE public.calculation_audit_log OWNER TO app_user;

--
-- Name: calculation_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.calculation_audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.calculation_audit_log_id_seq OWNER TO app_user;

--
-- Name: calculation_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.calculation_audit_log_id_seq OWNED BY public.calculation_audit_log.id;


--
-- Name: category_monthly_costs; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.category_monthly_costs (
    id integer NOT NULL,
    version_id integer NOT NULL,
    month smallint NOT NULL,
    category character varying(40) NOT NULL,
    amount numeric(15,4) NOT NULL,
    calculated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    calculated_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.category_monthly_costs OWNER TO app_user;

--
-- Name: category_monthly_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.category_monthly_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.category_monthly_costs_id_seq OWNER TO app_user;

--
-- Name: category_monthly_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.category_monthly_costs_id_seq OWNED BY public.category_monthly_costs.id;


--
-- Name: chart_of_accounts; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.chart_of_accounts (
    id integer NOT NULL,
    account_code character varying(10) NOT NULL,
    account_name character varying(100) NOT NULL,
    type public.account_type NOT NULL,
    ifrs_category character varying(100) NOT NULL,
    center_type public.center_type NOT NULL,
    description character varying(500),
    status public.account_status DEFAULT 'ACTIVE'::public.account_status NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer NOT NULL,
    updated_by integer NOT NULL,
    CONSTRAINT chk_account_code CHECK (((account_code)::text ~ '^[A-Z0-9]{3,10}$'::text))
);


ALTER TABLE public.chart_of_accounts OWNER TO app_user;

--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.chart_of_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chart_of_accounts_id_seq OWNER TO app_user;

--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.chart_of_accounts_id_seq OWNED BY public.chart_of_accounts.id;


--
-- Name: cohort_parameters; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.cohort_parameters (
    id integer NOT NULL,
    version_id integer NOT NULL,
    grade_level character varying(10) NOT NULL,
    retention_rate numeric(5,4) DEFAULT 0.97 NOT NULL,
    lateral_entry_count integer DEFAULT 0 NOT NULL,
    lateral_weight_fr numeric(5,4) DEFAULT 0 NOT NULL,
    lateral_weight_nat numeric(5,4) DEFAULT 0 NOT NULL,
    lateral_weight_aut numeric(5,4) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.cohort_parameters OWNER TO app_user;

--
-- Name: cohort_parameters_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.cohort_parameters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cohort_parameters_id_seq OWNER TO app_user;

--
-- Name: cohort_parameters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.cohort_parameters_id_seq OWNED BY public.cohort_parameters.id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.departments (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    label character varying(100) NOT NULL,
    band_mapping public.department_band NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer NOT NULL,
    updated_by integer NOT NULL,
    CONSTRAINT chk_department_code CHECK (((code)::text ~ '^[A-Z_]{2,20}$'::text))
);


ALTER TABLE public.departments OWNER TO app_user;

--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.departments_id_seq OWNER TO app_user;

--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;


--
-- Name: dhg_grille_config; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.dhg_grille_config (
    id integer NOT NULL,
    grade_level character varying(10) NOT NULL,
    subject character varying(100) NOT NULL,
    dhg_type character varying(20) DEFAULT 'Structural'::character varying NOT NULL,
    hours_per_week_per_section numeric(5,2) NOT NULL,
    effective_from_year integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dhg_grille_config OWNER TO app_user;

--
-- Name: dhg_grille_config_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.dhg_grille_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dhg_grille_config_id_seq OWNER TO app_user;

--
-- Name: dhg_grille_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.dhg_grille_config_id_seq OWNED BY public.dhg_grille_config.id;


--
-- Name: dhg_requirements; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.dhg_requirements (
    id integer NOT NULL,
    version_id integer NOT NULL,
    academic_period character varying(3) NOT NULL,
    grade_level character varying(10) NOT NULL,
    headcount integer DEFAULT 0 NOT NULL,
    max_class_size integer NOT NULL,
    sections_needed integer DEFAULT 0 NOT NULL,
    utilization numeric(5,1) DEFAULT 0 NOT NULL,
    alert character varying(10),
    recruitment_slots integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    total_weekly_hours numeric(10,4) DEFAULT 0 NOT NULL,
    total_annual_hours numeric(10,4) DEFAULT 0 NOT NULL,
    fte numeric(7,4) DEFAULT 0 NOT NULL
);


ALTER TABLE public.dhg_requirements OWNER TO app_user;

--
-- Name: dhg_requirements_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.dhg_requirements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dhg_requirements_id_seq OWNER TO app_user;

--
-- Name: dhg_requirements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.dhg_requirements_id_seq OWNED BY public.dhg_requirements.id;


--
-- Name: discount_policies; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.discount_policies (
    id integer NOT NULL,
    version_id integer NOT NULL,
    tariff character varying(10) NOT NULL,
    nationality character varying(10),
    discount_rate numeric(7,6) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer NOT NULL,
    updated_by integer
);


ALTER TABLE public.discount_policies OWNER TO app_user;

--
-- Name: discount_policies_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.discount_policies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.discount_policies_id_seq OWNER TO app_user;

--
-- Name: discount_policies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.discount_policies_id_seq OWNED BY public.discount_policies.id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    version_id integer NOT NULL,
    employee_code character varying(20) NOT NULL,
    name character varying(200) NOT NULL,
    function_role character varying(100) NOT NULL,
    department character varying(50) NOT NULL,
    status character varying(10) DEFAULT 'Existing'::character varying NOT NULL,
    joining_date date NOT NULL,
    payment_method character varying(50) NOT NULL,
    is_saudi boolean DEFAULT false NOT NULL,
    is_ajeer boolean DEFAULT false NOT NULL,
    is_teaching boolean DEFAULT false NOT NULL,
    hourly_percentage numeric(5,4) DEFAULT 1.0000 NOT NULL,
    base_salary bytea NOT NULL,
    housing_allowance bytea NOT NULL,
    transport_allowance bytea NOT NULL,
    responsibility_premium bytea DEFAULT public.pgp_sym_encrypt('0.0000'::text, current_setting('app.encryption_key'::text)) NOT NULL,
    hsa_amount bytea DEFAULT public.pgp_sym_encrypt('0.0000'::text, current_setting('app.encryption_key'::text)) NOT NULL,
    augmentation bytea DEFAULT public.pgp_sym_encrypt('0.0000'::text, current_setting('app.encryption_key'::text)) NOT NULL,
    augmentation_effective_date date,
    ajeer_annual_levy numeric(15,4) DEFAULT 0 NOT NULL,
    ajeer_monthly_fee numeric(15,4) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer NOT NULL,
    updated_by integer
);


ALTER TABLE public.employees OWNER TO app_user;

--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employees_id_seq OWNER TO app_user;

--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: enrollment_detail; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.enrollment_detail (
    id integer NOT NULL,
    version_id integer NOT NULL,
    academic_period character varying(3) NOT NULL,
    grade_level character varying(10) NOT NULL,
    nationality character varying(10) NOT NULL,
    tariff character varying(10) NOT NULL,
    headcount integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer NOT NULL,
    updated_by integer
);


ALTER TABLE public.enrollment_detail OWNER TO app_user;

--
-- Name: enrollment_detail_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.enrollment_detail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.enrollment_detail_id_seq OWNER TO app_user;

--
-- Name: enrollment_detail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.enrollment_detail_id_seq OWNED BY public.enrollment_detail.id;


--
-- Name: enrollment_headcount; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.enrollment_headcount (
    id integer NOT NULL,
    version_id integer NOT NULL,
    academic_period character varying(3) NOT NULL,
    grade_level character varying(10) NOT NULL,
    headcount integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer NOT NULL,
    updated_by integer
);


ALTER TABLE public.enrollment_headcount OWNER TO app_user;

--
-- Name: enrollment_headcount_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.enrollment_headcount_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.enrollment_headcount_id_seq OWNER TO app_user;

--
-- Name: enrollment_headcount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.enrollment_headcount_id_seq OWNED BY public.enrollment_headcount.id;


--
-- Name: eos_provisions; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.eos_provisions (
    id integer NOT NULL,
    version_id integer NOT NULL,
    employee_id integer NOT NULL,
    years_of_service numeric(7,4) NOT NULL,
    eos_base numeric(15,4) NOT NULL,
    eos_annual numeric(15,4) NOT NULL,
    eos_monthly_accrual numeric(15,4) NOT NULL,
    as_of_date date NOT NULL,
    calculated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.eos_provisions OWNER TO app_user;

--
-- Name: eos_provisions_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.eos_provisions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.eos_provisions_id_seq OWNER TO app_user;

--
-- Name: eos_provisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.eos_provisions_id_seq OWNED BY public.eos_provisions.id;


--
-- Name: fee_grids; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.fee_grids (
    id integer NOT NULL,
    version_id integer NOT NULL,
    academic_period character varying(3) NOT NULL,
    grade_level character varying(10) NOT NULL,
    nationality character varying(10) NOT NULL,
    tariff character varying(10) NOT NULL,
    dai numeric(15,4) DEFAULT 0 NOT NULL,
    tuition_ttc numeric(15,4) NOT NULL,
    tuition_ht numeric(15,4) NOT NULL,
    term1_amount numeric(15,4) DEFAULT 0 NOT NULL,
    term2_amount numeric(15,4) DEFAULT 0 NOT NULL,
    term3_amount numeric(15,4) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer NOT NULL,
    updated_by integer
);


ALTER TABLE public.fee_grids OWNER TO app_user;

--
-- Name: fee_grids_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.fee_grids_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fee_grids_id_seq OWNER TO app_user;

--
-- Name: fee_grids_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.fee_grids_id_seq OWNED BY public.fee_grids.id;


--
-- Name: fiscal_periods; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.fiscal_periods (
    id integer NOT NULL,
    fiscal_year smallint NOT NULL,
    month smallint NOT NULL,
    status character varying(10) DEFAULT 'Draft'::character varying NOT NULL,
    actual_version_id integer,
    locked_at timestamp with time zone,
    locked_by_id integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    updated_by_id integer
);


ALTER TABLE public.fiscal_periods OWNER TO app_user;

--
-- Name: fiscal_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.fiscal_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fiscal_periods_id_seq OWNER TO app_user;

--
-- Name: fiscal_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.fiscal_periods_id_seq OWNED BY public.fiscal_periods.id;


--
-- Name: grade_levels; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.grade_levels (
    id integer NOT NULL,
    grade_code character varying(10) NOT NULL,
    grade_name character varying(60) NOT NULL,
    band public.grade_band NOT NULL,
    max_class_size integer NOT NULL,
    plancher_pct numeric(5,4) NOT NULL,
    cible_pct numeric(5,4) NOT NULL,
    plafond_pct numeric(5,4) NOT NULL,
    display_order integer NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT chk_max_class_size CHECK (((max_class_size >= 1) AND (max_class_size <= 50))),
    CONSTRAINT chk_pct_ordering CHECK (((plancher_pct <= cible_pct) AND (cible_pct <= plafond_pct)))
);


ALTER TABLE public.grade_levels OWNER TO app_user;

--
-- Name: grade_levels_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.grade_levels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.grade_levels_id_seq OWNER TO app_user;

--
-- Name: grade_levels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.grade_levels_id_seq OWNED BY public.grade_levels.id;


--
-- Name: monthly_budget_summary; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.monthly_budget_summary (
    id integer NOT NULL,
    version_id integer NOT NULL,
    month smallint NOT NULL,
    revenue_ht numeric(15,4) DEFAULT 0 NOT NULL,
    staff_costs numeric(15,4) DEFAULT 0 NOT NULL,
    net_profit numeric(15,4) DEFAULT 0 NOT NULL,
    calculated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.monthly_budget_summary OWNER TO app_user;

--
-- Name: monthly_budget_summary_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.monthly_budget_summary_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.monthly_budget_summary_id_seq OWNER TO app_user;

--
-- Name: monthly_budget_summary_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.monthly_budget_summary_id_seq OWNED BY public.monthly_budget_summary.id;


--
-- Name: monthly_other_revenue; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.monthly_other_revenue (
    id integer NOT NULL,
    version_id integer NOT NULL,
    scenario_name character varying(20) DEFAULT 'Base'::character varying NOT NULL,
    line_item_name text NOT NULL,
    ifrs_category character varying(50) NOT NULL,
    executive_category character varying(40),
    month smallint NOT NULL,
    amount numeric(15,4) DEFAULT 0 NOT NULL,
    calculated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    calculated_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.monthly_other_revenue OWNER TO app_user;

--
-- Name: monthly_other_revenue_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.monthly_other_revenue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.monthly_other_revenue_id_seq OWNER TO app_user;

--
-- Name: monthly_other_revenue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.monthly_other_revenue_id_seq OWNED BY public.monthly_other_revenue.id;


--
-- Name: monthly_revenue; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.monthly_revenue (
    id integer NOT NULL,
    version_id integer NOT NULL,
    scenario_name character varying(20) DEFAULT 'Base'::character varying NOT NULL,
    academic_period character varying(3) NOT NULL,
    grade_level character varying(10) NOT NULL,
    nationality character varying(10) NOT NULL,
    tariff character varying(10) NOT NULL,
    month smallint NOT NULL,
    gross_revenue_ht numeric(15,4) DEFAULT 0 NOT NULL,
    discount_amount numeric(15,4) DEFAULT 0 NOT NULL,
    scholarship_deduction numeric(15,4) DEFAULT 0 NOT NULL,
    net_revenue_ht numeric(15,4) DEFAULT 0 NOT NULL,
    vat_amount numeric(15,4) DEFAULT 0 NOT NULL,
    calculated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    calculated_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.monthly_revenue OWNER TO app_user;

--
-- Name: monthly_revenue_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.monthly_revenue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.monthly_revenue_id_seq OWNER TO app_user;

--
-- Name: monthly_revenue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.monthly_revenue_id_seq OWNED BY public.monthly_revenue.id;


--
-- Name: monthly_staff_costs; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.monthly_staff_costs (
    id integer NOT NULL,
    version_id integer NOT NULL,
    employee_id integer NOT NULL,
    month smallint NOT NULL,
    base_gross numeric(15,4) NOT NULL,
    adjusted_gross numeric(15,4) NOT NULL,
    housing_allowance numeric(15,4) DEFAULT 0 NOT NULL,
    transport_allowance numeric(15,4) DEFAULT 0 NOT NULL,
    responsibility_premium numeric(15,4) DEFAULT 0 NOT NULL,
    hsa_amount numeric(15,4) DEFAULT 0 NOT NULL,
    gosi_amount numeric(15,4) DEFAULT 0 NOT NULL,
    ajeer_amount numeric(15,4) DEFAULT 0 NOT NULL,
    eos_monthly_accrual numeric(15,4) DEFAULT 0 NOT NULL,
    total_cost numeric(15,4) NOT NULL,
    calculated_at timestamp with time zone DEFAULT now() NOT NULL,
    calculated_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.monthly_staff_costs OWNER TO app_user;

--
-- Name: monthly_staff_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.monthly_staff_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.monthly_staff_costs_id_seq OWNER TO app_user;

--
-- Name: monthly_staff_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.monthly_staff_costs_id_seq OWNED BY public.monthly_staff_costs.id;


--
-- Name: nationalities; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.nationalities (
    id integer NOT NULL,
    code character varying(5) NOT NULL,
    label character varying(100) NOT NULL,
    vat_exempt boolean DEFAULT false NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer NOT NULL,
    updated_by integer NOT NULL,
    CONSTRAINT chk_nationality_code CHECK (((code)::text ~ '^[A-Z]{2,5}$'::text))
);


ALTER TABLE public.nationalities OWNER TO app_user;

--
-- Name: nationalities_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.nationalities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nationalities_id_seq OWNER TO app_user;

--
-- Name: nationalities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.nationalities_id_seq OWNED BY public.nationalities.id;


--
-- Name: nationality_breakdown; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.nationality_breakdown (
    id integer NOT NULL,
    version_id integer NOT NULL,
    academic_period character varying(3) NOT NULL,
    grade_level character varying(10) NOT NULL,
    nationality character varying(10) NOT NULL,
    weight numeric(5,4) DEFAULT 0 NOT NULL,
    headcount integer DEFAULT 0 NOT NULL,
    is_overridden boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.nationality_breakdown OWNER TO app_user;

--
-- Name: nationality_breakdown_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.nationality_breakdown_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nationality_breakdown_id_seq OWNER TO app_user;

--
-- Name: nationality_breakdown_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.nationality_breakdown_id_seq OWNED BY public.nationality_breakdown.id;


--
-- Name: other_revenue_items; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.other_revenue_items (
    id integer NOT NULL,
    version_id integer NOT NULL,
    line_item_name text NOT NULL,
    annual_amount numeric(15,4) NOT NULL,
    distribution_method character varying(20) NOT NULL,
    weight_array jsonb,
    specific_months integer[],
    ifrs_category character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer NOT NULL,
    updated_by integer
);


ALTER TABLE public.other_revenue_items OWNER TO app_user;

--
-- Name: other_revenue_items_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.other_revenue_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.other_revenue_items_id_seq OWNER TO app_user;

--
-- Name: other_revenue_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.other_revenue_items_id_seq OWNED BY public.other_revenue_items.id;


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.refresh_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token_hash character varying(255) NOT NULL,
    family_id uuid NOT NULL,
    is_revoked boolean DEFAULT false NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.refresh_tokens OWNER TO app_user;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.refresh_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.refresh_tokens_id_seq OWNER TO app_user;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.refresh_tokens_id_seq OWNED BY public.refresh_tokens.id;


--
-- Name: schema_version; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.schema_version (
    id integer DEFAULT 1 NOT NULL,
    version text DEFAULT '0.0.1'::text NOT NULL,
    applied_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.schema_version OWNER TO app_user;

--
-- Name: system_config; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.system_config (
    key character varying(100) NOT NULL,
    value text NOT NULL,
    data_type character varying(20) DEFAULT 'string'::character varying NOT NULL,
    description text,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by integer
);


ALTER TABLE public.system_config OWNER TO app_user;

--
-- Name: tariffs; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.tariffs (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    label character varying(100) NOT NULL,
    description character varying(500),
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer NOT NULL,
    updated_by integer NOT NULL,
    CONSTRAINT chk_tariff_code CHECK (((code)::text ~ '^[A-Z0-9+]{2,10}$'::text))
);


ALTER TABLE public.tariffs OWNER TO app_user;

--
-- Name: tariffs_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.tariffs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tariffs_id_seq OWNER TO app_user;

--
-- Name: tariffs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.tariffs_id_seq OWNED BY public.tariffs.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role public.user_role DEFAULT 'Viewer'::public.user_role NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    failed_attempts integer DEFAULT 0 NOT NULL,
    locked_until timestamp with time zone,
    force_password_reset boolean DEFAULT false NOT NULL,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.users OWNER TO app_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO app_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: academic_years id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.academic_years ALTER COLUMN id SET DEFAULT nextval('public.academic_years_id_seq'::regclass);


--
-- Name: actuals_import_log id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.actuals_import_log ALTER COLUMN id SET DEFAULT nextval('public.actuals_import_log_id_seq'::regclass);


--
-- Name: assumptions id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.assumptions ALTER COLUMN id SET DEFAULT nextval('public.assumptions_id_seq'::regclass);


--
-- Name: audit_entries id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.audit_entries ALTER COLUMN id SET DEFAULT nextval('public.audit_entries_id_seq'::regclass);


--
-- Name: budget_versions id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.budget_versions ALTER COLUMN id SET DEFAULT nextval('public.budget_versions_id_seq'::regclass);


--
-- Name: calculation_audit_log id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.calculation_audit_log ALTER COLUMN id SET DEFAULT nextval('public.calculation_audit_log_id_seq'::regclass);


--
-- Name: category_monthly_costs id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.category_monthly_costs ALTER COLUMN id SET DEFAULT nextval('public.category_monthly_costs_id_seq'::regclass);


--
-- Name: chart_of_accounts id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.chart_of_accounts ALTER COLUMN id SET DEFAULT nextval('public.chart_of_accounts_id_seq'::regclass);


--
-- Name: cohort_parameters id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.cohort_parameters ALTER COLUMN id SET DEFAULT nextval('public.cohort_parameters_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: dhg_grille_config id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.dhg_grille_config ALTER COLUMN id SET DEFAULT nextval('public.dhg_grille_config_id_seq'::regclass);


--
-- Name: dhg_requirements id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.dhg_requirements ALTER COLUMN id SET DEFAULT nextval('public.dhg_requirements_id_seq'::regclass);


--
-- Name: discount_policies id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.discount_policies ALTER COLUMN id SET DEFAULT nextval('public.discount_policies_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: enrollment_detail id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_detail ALTER COLUMN id SET DEFAULT nextval('public.enrollment_detail_id_seq'::regclass);


--
-- Name: enrollment_headcount id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_headcount ALTER COLUMN id SET DEFAULT nextval('public.enrollment_headcount_id_seq'::regclass);


--
-- Name: eos_provisions id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.eos_provisions ALTER COLUMN id SET DEFAULT nextval('public.eos_provisions_id_seq'::regclass);


--
-- Name: fee_grids id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.fee_grids ALTER COLUMN id SET DEFAULT nextval('public.fee_grids_id_seq'::regclass);


--
-- Name: fiscal_periods id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.fiscal_periods ALTER COLUMN id SET DEFAULT nextval('public.fiscal_periods_id_seq'::regclass);


--
-- Name: grade_levels id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.grade_levels ALTER COLUMN id SET DEFAULT nextval('public.grade_levels_id_seq'::regclass);


--
-- Name: monthly_budget_summary id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_budget_summary ALTER COLUMN id SET DEFAULT nextval('public.monthly_budget_summary_id_seq'::regclass);


--
-- Name: monthly_other_revenue id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_other_revenue ALTER COLUMN id SET DEFAULT nextval('public.monthly_other_revenue_id_seq'::regclass);


--
-- Name: monthly_revenue id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_revenue ALTER COLUMN id SET DEFAULT nextval('public.monthly_revenue_id_seq'::regclass);


--
-- Name: monthly_staff_costs id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_staff_costs ALTER COLUMN id SET DEFAULT nextval('public.monthly_staff_costs_id_seq'::regclass);


--
-- Name: nationalities id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.nationalities ALTER COLUMN id SET DEFAULT nextval('public.nationalities_id_seq'::regclass);


--
-- Name: nationality_breakdown id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.nationality_breakdown ALTER COLUMN id SET DEFAULT nextval('public.nationality_breakdown_id_seq'::regclass);


--
-- Name: other_revenue_items id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.other_revenue_items ALTER COLUMN id SET DEFAULT nextval('public.other_revenue_items_id_seq'::regclass);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('public.refresh_tokens_id_seq'::regclass);


--
-- Name: tariffs id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.tariffs ALTER COLUMN id SET DEFAULT nextval('public.tariffs_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
f0ee2678-c855-4e02-a119-201367c0df8e	c08c6c76832d20257875a469ba00ec7f46396d9de0b80c75bd21cee14307e7d8	2026-03-08 19:37:29.938412+00	20260308180000_cohort_nationality	\N	\N	2026-03-08 19:37:29.916057+00	1
530eaf6c-d507-4a52-b85f-03166bd05321	1da64488e702dd1c9f706318a8eb93ceceeb428087dbed724fb1cad7dc34a84c	2026-03-07 22:17:22.941822+00	20260305155638_init	\N	\N	2026-03-07 22:17:22.934931+00	1
404893ed-afd9-40d8-9bef-45be0c50c360	cb60d75c908faa8e383f034413250a79afff01051787975c87e3d48faf53cdfa	2026-03-07 22:17:22.973549+00	20260305200000_auth_and_versions	\N	\N	2026-03-07 22:17:22.942483+00	1
84136bcc-f892-496f-87d5-84050f4404d3	be31ffebc34d9f4624fd7f79cd19bf15b697f201442859d5823ab3b363b5dc3f	2026-03-07 22:17:22.996449+00	20260306120000_master_data	\N	\N	2026-03-07 22:17:22.974023+00	1
4f00dc94-364f-43c2-adcd-7876c7814ce2	9994e41ae6b54149ef1f1fd8f5c876376748a5c35e71741b2f560286e8d3397e	2026-03-09 19:02:18.652333+00	20260309100000_add_staffing_models	\N	\N	2026-03-09 19:02:18.610246+00	1
454f6b9d-3d65-4d0c-8cda-05aadae9df4e	5814805fac983e8a6bee3d69ac91aee8981bfcf0f366bd4d8b964c3c176b6876	2026-03-07 22:17:23.006664+00	20260307120000_add_enrollment_tables	\N	\N	2026-03-07 22:17:22.997003+00	1
c37fa2c8-9339-4a8c-ad9d-b0db53771dad	d1ea2dc5c79b52579ce172bccd7670bb76ec5c0c1a7a79c54a019bae32debd09	\N	20260307141339_revenue_tables	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260307141339_revenue_tables\n\nDatabase error code: 42P01\n\nDatabase error:\nERROR: relation "calculation_audit_log" does not exist\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42P01), message: "relation \\"calculation_audit_log\\" does not exist", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("namespace.c"), line: Some(434), routine: Some("RangeVarGetRelidExtended") }\n\n	2026-03-07 22:18:58.114561+00	2026-03-07 22:17:23.007153+00	0
da0b3ab0-acc6-4c86-b27c-ab5492ccb34c	f6cbbf9e25802c74f0f40811ab5de3116d3807598813e8070ae054400924f182	2026-03-07 22:19:05.44711+00	20260307141339_revenue_tables	\N	\N	2026-03-07 22:19:05.423216+00	1
82af136e-6e6e-4794-b4ba-26f38a3ed16c	684b0b7df8caf7ac530d8eea35c2bf332297e85f91c3806dcfbf02f1fbc28148	2026-03-09 19:02:18.658792+00	20260309120000_add_category_monthly_costs	\N	\N	2026-03-09 19:02:18.652903+00	1
30077b35-b33c-4239-a1b7-d73376d76f0b	e2997bc1c1a5b5d5c2ab518cbbbd3bbdac02c7e97a95e498246fc57ecb6b83ac	2026-03-07 22:19:05.450199+00	20260307180000_fix_audit_entries_role	\N	\N	2026-03-07 22:19:05.44761+00	1
9ae373e3-f0a2-4244-a93d-7099be31bcbd	a6ffa9fe9dea596e10c21ebe7ba4106b460a34dee7f28dc4008d7409b5009b66	2026-03-07 22:19:05.458064+00	20260307180100_add_dhg_and_calc_audit	\N	\N	2026-03-07 22:19:05.450639+00	1
3d150b57-ff1d-4e50-a494-5d7026b5eda8	189e682460e4c77cff291454c3d1f84324e1ad587c83902adcba9b5bf13cb612	2026-03-08 13:25:30.496883+00	20260308100000_add_monthly_other_revenue	\N	\N	2026-03-08 13:25:30.481529+00	1
00ba41b6-4fab-4d6d-af33-492ada81b160	cd7ba9ca6ee93340e4bb56be7b6126d5a28cc29b9cb1d7916094dd3195ed65cc	2026-03-09 19:02:18.683652+00	20260309140000_add_indexes_and_schema_fixes	\N	\N	2026-03-09 19:02:18.659325+00	1
c9f8b30c-269b-4887-97c2-82248438686f	1447ed51794591d933ce67e4a3470c3ff034e6d7bc1649746b621bf7bb642bf0	2026-03-08 17:38:08.282969+00	20260308173000_align_runtime_schema	\N	\N	2026-03-08 17:38:08.253525+00	1
\.


--
-- Data for Name: academic_years; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.academic_years (id, fiscal_year, ay1_start, ay1_end, ay2_start, ay2_end, summer_start, summer_end, academic_weeks, version, created_at, updated_at, created_by, updated_by) FROM stdin;
1	FY2022	2022-01-01	2022-06-30	2022-09-01	2022-12-31	2022-07-01	2022-08-31	36	1	2026-03-09 20:19:33.082+00	2026-03-09 20:19:33.082+00	2	2
2	FY2023	2023-01-01	2023-06-30	2023-09-01	2023-12-31	2023-07-01	2023-08-31	36	1	2026-03-09 20:19:33.083+00	2026-03-09 20:19:33.083+00	2	2
3	FY2024	2024-01-01	2024-06-30	2024-09-01	2024-12-31	2024-07-01	2024-08-31	36	1	2026-03-09 20:19:33.084+00	2026-03-09 20:19:33.084+00	2	2
4	FY2025	2025-01-01	2025-06-30	2025-09-01	2025-12-31	2025-07-01	2025-08-31	36	1	2026-03-09 20:19:33.085+00	2026-03-09 20:19:33.085+00	2	2
5	FY2026	2026-01-01	2026-06-30	2026-09-01	2026-12-31	2026-07-01	2026-08-31	36	1	2026-03-09 20:19:33.086+00	2026-03-09 20:19:33.086+00	2	2
6	FY2027	2027-01-01	2027-06-30	2027-09-01	2027-12-31	2027-07-01	2027-08-31	36	1	2026-03-09 20:19:33.086+00	2026-03-09 20:19:33.086+00	2	2
\.


--
-- Data for Name: actuals_import_log; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.actuals_import_log (id, version_id, module, source_file, validation_status, rows_imported, imported_by_id, imported_at) FROM stdin;
\.


--
-- Data for Name: assumptions; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.assumptions (id, key, value, unit, section, label, value_type, version, created_at, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: audit_entries; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.audit_entries (id, user_id, operation, table_name, record_id, old_values, new_values, ip_address, created_at, user_email, session_id, audit_note) FROM stdin;
1	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	192.168.65.1	2026-03-07 22:19:22.081+00	\N	\N	\N
2	1	LOGIN_SUCCESS	users	\N	\N	\N	192.168.65.1	2026-03-07 22:19:22.089+00	\N	\N	\N
3	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	192.168.65.1	2026-03-07 22:19:28.218+00	\N	\N	\N
4	1	LOGIN_SUCCESS	users	\N	\N	\N	192.168.65.1	2026-03-07 22:19:28.22+00	\N	\N	\N
5	1	SESSION_FORCE_REVOKED	refresh_tokens	\N	\N	{"reason": "max_sessions_exceeded", "familyId": "985e34a0-e0c5-429f-a1da-5df8b6852060"}	172.22.0.4	2026-03-07 22:20:03.65+00	\N	\N	\N
6	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	172.22.0.4	2026-03-07 22:20:03.651+00	\N	\N	\N
7	1	LOGIN_SUCCESS	users	\N	\N	\N	172.22.0.4	2026-03-07 22:20:03.653+00	\N	\N	\N
8	1	SESSION_FORCE_REVOKED	refresh_tokens	\N	\N	{"reason": "max_sessions_exceeded", "familyId": "013b4daf-e306-441e-befd-b4f1162264d6"}	172.22.0.4	2026-03-07 22:23:31.313+00	\N	\N	\N
9	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	172.22.0.4	2026-03-07 22:23:31.316+00	\N	\N	\N
10	1	LOGIN_SUCCESS	users	\N	\N	\N	172.22.0.4	2026-03-07 22:23:31.319+00	\N	\N	\N
11	1	VERSION_CREATED	budget_versions	1	\N	{"name": "test 2 2026", "type": "Budget", "fiscalYear": 2026, "description": "test"}	172.22.0.4	2026-03-07 22:23:59.743+00	\N	\N	\N
12	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	172.22.0.4	2026-03-07 23:11:44.608+00	\N	\N	\N
13	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	172.22.0.4	2026-03-07 23:11:47.975+00	\N	\N	\N
14	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	172.22.0.4	2026-03-08 01:31:49.107+00	\N	\N	\N
15	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	172.22.0.4	2026-03-08 06:39:34.495+00	\N	\N	\N
16	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	172.22.0.4	2026-03-08 11:01:49.98+00	\N	\N	\N
17	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 13:25:44.011+00	\N	\N	\N
18	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 13:25:48.124+00	\N	\N	\N
19	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 13:41:08.194+00	\N	\N	\N
20	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 13:41:09.107+00	\N	\N	\N
21	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 16:19:46.263+00	\N	\N	\N
22	1	LOGOUT	users	\N	\N	\N	127.0.0.1	2026-03-08 16:31:29.198+00	\N	\N	\N
23	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 16:31:36.428+00	\N	\N	\N
24	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-08 16:31:36.431+00	\N	\N	\N
25	1	LOGIN_FAILED	users	\N	\N	\N	127.0.0.1	2026-03-08 17:38:19.157+00	admin@efir.edu.sa	\N	\N
26	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 17:38:19.161+00	\N	\N	\N
27	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-08 17:38:19.166+00	admin@efir.edu.sa	\N	\N
28	1	SESSION_FORCE_REVOKED	refresh_tokens	\N	\N	{"reason": "max_sessions_exceeded", "familyId": "2d19ba37-8cb8-40b8-b663-baecb7921c2c"}	127.0.0.1	2026-03-08 17:38:37.105+00	admin@efir.edu.sa	\N	\N
29	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 17:38:37.11+00	\N	\N	\N
30	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-08 17:38:37.112+00	admin@efir.edu.sa	\N	\N
31	1	SESSION_FORCE_REVOKED	refresh_tokens	\N	\N	{"reason": "max_sessions_exceeded", "familyId": "1940d1de-1dd7-4c78-a9fe-dc6584763918"}	127.0.0.1	2026-03-08 17:40:33.255+00	admin@efir.edu.sa	\N	\N
32	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 17:40:33.258+00	\N	\N	\N
33	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-08 17:40:33.261+00	admin@efir.edu.sa	\N	\N
34	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 18:50:51.808+00	\N	\N	\N
35	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 18:53:09.795+00	\N	\N	\N
36	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 18:53:09.863+00	\N	\N	\N
37	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 18:54:16.972+00	\N	\N	\N
38	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 18:54:16.98+00	\N	\N	\N
40	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:05:46.117+00	\N	\N	\N
39	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:05:46.116+00	\N	\N	\N
41	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:06:46.924+00	\N	\N	\N
42	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:12:08.689+00	\N	\N	\N
43	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:12:28.16+00	\N	\N	\N
44	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:12:44.399+00	\N	\N	\N
45	1	SESSION_FORCE_REVOKED	refresh_tokens	\N	\N	{"reason": "max_sessions_exceeded", "familyId": "0178110a-99e3-47ea-bd26-1231006ea6e4"}	127.0.0.1	2026-03-08 19:12:49.961+00	admin@efir.edu.sa	\N	\N
46	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:12:49.967+00	\N	\N	\N
47	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-08 19:12:49.969+00	admin@efir.edu.sa	\N	\N
48	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:13:47.105+00	\N	\N	\N
49	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:14:09.53+00	\N	\N	\N
50	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:16:43.214+00	\N	\N	\N
51	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:17:10.375+00	\N	\N	\N
52	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:17:29.01+00	\N	\N	\N
53	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:17:49.424+00	\N	\N	\N
54	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:18:09.114+00	\N	\N	\N
55	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:18:30.499+00	\N	\N	\N
56	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:19:47.675+00	\N	\N	\N
57	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:20:13.046+00	\N	\N	\N
58	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:21:31.207+00	\N	\N	\N
59	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:34:16.088+00	\N	\N	\N
60	1	SESSION_FORCE_REVOKED	refresh_tokens	\N	\N	{"reason": "max_sessions_exceeded", "familyId": "4807eb79-5993-42e9-90c5-49d54c324151"}	127.0.0.1	2026-03-08 19:35:44.624+00	admin@efir.edu.sa	\N	\N
61	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:35:44.627+00	\N	\N	\N
62	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-08 19:35:44.633+00	admin@efir.edu.sa	\N	\N
63	1	SESSION_FORCE_REVOKED	refresh_tokens	\N	\N	{"reason": "max_sessions_exceeded", "familyId": "b1e8735b-70bb-4962-8ae2-3fa247728ec9"}	127.0.0.1	2026-03-08 19:38:50.933+00	admin@efir.edu.sa	\N	\N
64	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 19:38:50.94+00	\N	\N	\N
65	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-08 19:38:50.945+00	admin@efir.edu.sa	\N	\N
66	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 20:16:48.538+00	\N	\N	\N
67	1	SESSION_FORCE_REVOKED	refresh_tokens	\N	\N	{"reason": "max_sessions_exceeded", "familyId": "32ec98e7-b1a8-42b3-a445-9952934e2a01"}	127.0.0.1	2026-03-08 20:17:12.892+00	admin@efir.edu.sa	\N	\N
68	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 20:17:12.897+00	\N	\N	\N
69	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-08 20:17:12.899+00	admin@efir.edu.sa	\N	\N
70	1	ALL_SESSIONS_REVOKED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:13:22.898+00	\N	\N	\N
71	1	TOKEN_FAMILY_REVOKED	refresh_tokens	\N	\N	{"reason": "replay_detected", "familyId": "0178110a-99e3-47ea-bd26-1231006ea6e4"}	127.0.0.1	2026-03-08 21:13:22.901+00	\N	\N	\N
72	1	ALL_SESSIONS_REVOKED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:13:23.232+00	\N	\N	\N
73	1	TOKEN_FAMILY_REVOKED	refresh_tokens	\N	\N	{"reason": "replay_detected", "familyId": "6cf6edcc-3c4d-42a3-917d-8c203dedf738"}	127.0.0.1	2026-03-08 21:13:23.233+00	\N	\N	\N
74	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:50:04.8+00	\N	\N	\N
75	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-08 21:50:04.807+00	admin@efir.edu.sa	\N	\N
76	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:54:19.159+00	\N	\N	\N
77	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:54:25.113+00	\N	\N	\N
78	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:54:38.106+00	\N	\N	\N
79	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:54:44.099+00	\N	\N	\N
80	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:54:50.065+00	\N	\N	\N
81	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:55:01.154+00	\N	\N	\N
82	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:55:14.162+00	\N	\N	\N
83	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:55:20.126+00	\N	\N	\N
84	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:55:54.135+00	\N	\N	\N
85	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:55:55.07+00	\N	\N	\N
86	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:56:00.098+00	\N	\N	\N
87	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:56:13.179+00	\N	\N	\N
88	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:56:24.1+00	\N	\N	\N
89	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:56:33.239+00	\N	\N	\N
90	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:57:00.134+00	\N	\N	\N
91	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:57:05.122+00	\N	\N	\N
92	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 21:57:33.142+00	\N	\N	\N
93	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 22:01:45.344+00	\N	\N	\N
94	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 22:02:16.246+00	\N	\N	\N
95	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 22:47:50.437+00	\N	\N	\N
96	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-08 22:51:03.298+00	\N	\N	\N
97	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 06:18:58.219+00	\N	\N	\N
100	\N	LOGOUT	users	\N	\N	\N	127.0.0.1	2026-03-09 14:38:25.738+00	\N	\N	\N
98	\N	LOGOUT	users	\N	\N	\N	127.0.0.1	2026-03-09 14:38:25.738+00	\N	\N	\N
99	\N	LOGOUT	users	\N	\N	\N	127.0.0.1	2026-03-09 14:38:25.738+00	\N	\N	\N
101	\N	LOGOUT	users	\N	\N	\N	127.0.0.1	2026-03-09 14:38:25.738+00	\N	\N	\N
102	\N	LOGOUT	users	\N	\N	\N	127.0.0.1	2026-03-09 14:38:25.738+00	\N	\N	\N
103	\N	LOGOUT	users	\N	\N	\N	127.0.0.1	2026-03-09 14:38:25.738+00	\N	\N	\N
104	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:06:34.843+00	\N	\N	\N
105	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-09 16:06:34.852+00	admin@efir.edu.sa	\N	\N
106	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:08:03.208+00	\N	\N	\N
107	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:08:57.888+00	\N	\N	\N
108	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:09:10.855+00	\N	\N	\N
109	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:09:53.428+00	\N	\N	\N
110	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:12:34.377+00	\N	\N	\N
111	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:15:45.46+00	\N	\N	\N
112	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:18:24.267+00	\N	\N	\N
113	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:19:18.153+00	\N	\N	\N
114	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:21:31.712+00	\N	\N	\N
115	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:30:11.539+00	\N	\N	\N
116	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:30:12.282+00	\N	\N	\N
117	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:30:14.04+00	\N	\N	\N
118	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:30:16.567+00	\N	\N	\N
119	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:30:17.999+00	\N	\N	\N
120	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:30:19.553+00	\N	\N	\N
121	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:31:57.77+00	\N	\N	\N
122	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 16:33:29.123+00	\N	\N	\N
123	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 17:50:01.859+00	\N	\N	\N
124	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 17:50:02.487+00	\N	\N	\N
125	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 17:50:03.47+00	\N	\N	\N
126	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 17:54:05.51+00	\N	\N	\N
127	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 17:57:44.53+00	\N	\N	\N
128	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:01:21.674+00	\N	\N	\N
129	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:01:22.455+00	\N	\N	\N
130	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:02:49.514+00	\N	\N	\N
131	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:17:09.565+00	\N	\N	\N
132	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:17:14.5+00	\N	\N	\N
133	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:17:38.524+00	\N	\N	\N
134	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:45:34.618+00	\N	\N	\N
135	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:46:28.527+00	\N	\N	\N
136	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:47:29.522+00	\N	\N	\N
137	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:52:43.602+00	\N	\N	\N
138	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:53:05.586+00	\N	\N	\N
139	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 19:57:11.567+00	\N	\N	\N
140	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 20:00:57.624+00	\N	\N	\N
141	1	TOKEN_ROTATION	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 20:03:42.466+00	\N	\N	\N
142	1	TOKEN_FAMILY_CREATED	refresh_tokens	\N	\N	\N	127.0.0.1	2026-03-09 20:03:48.079+00	\N	\N	\N
143	1	LOGIN_SUCCESS	users	\N	\N	\N	127.0.0.1	2026-03-09 20:03:48.081+00	admin@efir.edu.sa	\N	\N
\.


--
-- Data for Name: budget_versions; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.budget_versions (id, fiscal_year, name, type, status, description, data_source, source_version_id, modification_count, stale_modules, created_by_id, published_at, locked_at, archived_at, created_at, updated_at, updated_by_id) FROM stdin;
1	2026	test 2 2026	Budget	Draft	test	CALCULATED	\N	0	{}	1	\N	\N	\N	2026-03-07 22:23:59.739+00	2026-03-07 22:23:59.739+00	\N
2	2026	Migration FY2026	Budget	Draft	\N	IMPORTED	\N	0	{}	2	\N	\N	\N	2026-03-09 20:15:46.283+00	2026-03-09 20:15:46.283+00	\N
3	2022	Actual FY2022	Actual	Locked	\N	IMPORTED	\N	0	{}	2	\N	2026-03-09 20:15:46.284+00	\N	2026-03-09 20:15:46.284+00	2026-03-09 20:15:46.284+00	\N
4	2023	Actual FY2023	Actual	Locked	\N	IMPORTED	\N	0	{}	2	\N	2026-03-09 20:15:46.284+00	\N	2026-03-09 20:15:46.285+00	2026-03-09 20:15:46.285+00	\N
5	2024	Actual FY2024	Actual	Locked	\N	IMPORTED	\N	0	{}	2	\N	2026-03-09 20:15:46.285+00	\N	2026-03-09 20:15:46.285+00	2026-03-09 20:15:46.285+00	\N
6	2025	Actual FY2025	Actual	Locked	\N	IMPORTED	\N	0	{}	2	\N	2026-03-09 20:15:46.285+00	\N	2026-03-09 20:15:46.286+00	2026-03-09 20:15:46.286+00	\N
7	2026	Actual FY2026	Actual	Locked	\N	IMPORTED	\N	0	{}	2	\N	2026-03-09 20:15:46.286+00	\N	2026-03-09 20:15:46.286+00	2026-03-09 20:15:46.286+00	\N
\.


--
-- Data for Name: calculation_audit_log; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.calculation_audit_log (id, version_id, run_id, module, status, started_at, completed_at, duration_ms, input_summary, output_summary, triggered_by) FROM stdin;
\.


--
-- Data for Name: category_monthly_costs; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.category_monthly_costs (id, version_id, month, category, amount, calculated_at, calculated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chart_of_accounts; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.chart_of_accounts (id, account_code, account_name, type, ifrs_category, center_type, description, status, version, created_at, updated_at, created_by, updated_by) FROM stdin;
2	R001	Tuition HT — Maternelle	REVENUE	Tuition Revenue	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.087+00	2026-03-09 20:19:33.087+00	2	2
3	R002	Tuition HT — Elementaire	REVENUE	Tuition Revenue	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.088+00	2026-03-09 20:19:33.088+00	2	2
4	R003	Tuition HT — College	REVENUE	Tuition Revenue	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.088+00	2026-03-09 20:19:33.088+00	2	2
5	R004	Tuition HT — Lycee	REVENUE	Tuition Revenue	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.089+00	2026-03-09 20:19:33.089+00	2	2
6	R005	DAI Revenue	REVENUE	Registration Fees	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.089+00	2026-03-09 20:19:33.089+00	2	2
7	R006	DPI Revenue	REVENUE	Registration Fees	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.09+00	2026-03-09 20:19:33.09+00	2	2
8	R007	Frais de Dossier	REVENUE	Registration Fees	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.091+00	2026-03-09 20:19:33.091+00	2	2
9	R008	Examination Fees — BAC	REVENUE	Examination Fees	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.091+00	2026-03-09 20:19:33.091+00	2	2
10	R009	Examination Fees — DNB	REVENUE	Examination Fees	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.092+00	2026-03-09 20:19:33.092+00	2	2
11	R010	Examination Fees — EAF	REVENUE	Examination Fees	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.092+00	2026-03-09 20:19:33.092+00	2	2
12	R011	Examination Fees — SIELE	REVENUE	Examination Fees	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.093+00	2026-03-09 20:19:33.093+00	2	2
13	R012	After-School Activities	REVENUE	Activities & Services	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.093+00	2026-03-09 20:19:33.093+00	2	2
14	R013	Daycare Revenue	REVENUE	Activities & Services	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.093+00	2026-03-09 20:19:33.093+00	2	2
15	R014	Class Photos Revenue	REVENUE	Activities & Services	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.094+00	2026-03-09 20:19:33.094+00	2	2
16	R015	PSG Academy Rental	REVENUE	Activities & Services	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.094+00	2026-03-09 20:19:33.094+00	2	2
17	R016	Evaluation Fees	REVENUE	Registration Fees	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.095+00	2026-03-09 20:19:33.095+00	2	2
18	R017	Bourses AEFE	REVENUE	Other Revenue	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.095+00	2026-03-09 20:19:33.095+00	2	2
19	R018	Bourses AESH	REVENUE	Other Revenue	PROFIT_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.096+00	2026-03-09 20:19:33.096+00	2	2
20	SC001	Base Salary — Residents	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.096+00	2026-03-09 20:19:33.096+00	2	2
21	SC002	Base Salary — Contrats Locaux	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.097+00	2026-03-09 20:19:33.097+00	2	2
22	SC003	Housing Allowance	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.097+00	2026-03-09 20:19:33.097+00	2	2
23	SC004	Transport Allowance	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.098+00	2026-03-09 20:19:33.098+00	2	2
24	SC005	Responsibility Premium	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.098+00	2026-03-09 20:19:33.098+00	2	2
25	SC006	HSA Payments	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.099+00	2026-03-09 20:19:33.099+00	2	2
26	SC007	Augmentation Costs	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.099+00	2026-03-09 20:19:33.099+00	2	2
27	SC008	GOSI Employer Contribution	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.099+00	2026-03-09 20:19:33.099+00	2	2
28	SC009	GOSI Employee Contribution	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.1+00	2026-03-09 20:19:33.1+00	2	2
29	SC010	Ajeer Levy	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.1+00	2026-03-09 20:19:33.1+00	2	2
30	SC011	Ajeer Monthly Fee	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.101+00	2026-03-09 20:19:33.101+00	2	2
31	SC012	End of Service — Accrual	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.101+00	2026-03-09 20:19:33.101+00	2	2
32	SC013	Recruitment Costs	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.102+00	2026-03-09 20:19:33.102+00	2	2
33	SC014	Training & Development	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.102+00	2026-03-09 20:19:33.102+00	2	2
34	SC015	Staff Insurance	EXPENSE	Staff Costs	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.103+00	2026-03-09 20:19:33.103+00	2	2
35	OX001	Building Rent	EXPENSE	Occupancy	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.103+00	2026-03-09 20:19:33.103+00	2	2
36	OX002	Building Maintenance	EXPENSE	Occupancy	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.103+00	2026-03-09 20:19:33.103+00	2	2
37	OX003	Utilities — Electricity	EXPENSE	Occupancy	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.104+00	2026-03-09 20:19:33.104+00	2	2
38	OX004	Utilities — Water	EXPENSE	Occupancy	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.104+00	2026-03-09 20:19:33.104+00	2	2
39	OX005	Utilities — Gas	EXPENSE	Occupancy	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.105+00	2026-03-09 20:19:33.105+00	2	2
40	OX006	Security Services	EXPENSE	Occupancy	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.105+00	2026-03-09 20:19:33.105+00	2	2
41	OX007	Cleaning Services	EXPENSE	Occupancy	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.106+00	2026-03-09 20:19:33.106+00	2	2
42	OX008	Insurance — Property	EXPENSE	Insurance	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.106+00	2026-03-09 20:19:33.106+00	2	2
43	OX009	Insurance — Liability	EXPENSE	Insurance	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.107+00	2026-03-09 20:19:33.107+00	2	2
44	OX010	Insurance — Vehicle	EXPENSE	Insurance	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.107+00	2026-03-09 20:19:33.107+00	2	2
45	OX011	IT Infrastructure	EXPENSE	Technology	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.107+00	2026-03-09 20:19:33.107+00	2	2
46	OX012	Software Licenses	EXPENSE	Technology	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.108+00	2026-03-09 20:19:33.108+00	2	2
47	OX013	Network & Internet	EXPENSE	Technology	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.108+00	2026-03-09 20:19:33.108+00	2	2
48	OX014	IT Equipment	EXPENSE	Technology	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.109+00	2026-03-09 20:19:33.109+00	2	2
49	OX015	IT Support Services	EXPENSE	Technology	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.109+00	2026-03-09 20:19:33.109+00	2	2
50	OX016	Textbooks & Curriculum	EXPENSE	Educational	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.109+00	2026-03-09 20:19:33.109+00	2	2
51	OX017	Library Resources	EXPENSE	Educational	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.11+00	2026-03-09 20:19:33.11+00	2	2
52	OX018	Laboratory Supplies	EXPENSE	Educational	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.111+00	2026-03-09 20:19:33.111+00	2	2
53	OX019	Sports Equipment	EXPENSE	Educational	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.112+00	2026-03-09 20:19:33.112+00	2	2
54	OX020	Art & Music Supplies	EXPENSE	Educational	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.113+00	2026-03-09 20:19:33.113+00	2	2
55	OX021	Office Supplies	EXPENSE	Administrative	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.113+00	2026-03-09 20:19:33.113+00	2	2
56	OX022	Printing & Stationery	EXPENSE	Administrative	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.114+00	2026-03-09 20:19:33.114+00	2	2
57	OX023	Postage & Courier	EXPENSE	Administrative	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.115+00	2026-03-09 20:19:33.115+00	2	2
58	OX024	Legal Fees	EXPENSE	Professional Services	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.115+00	2026-03-09 20:19:33.115+00	2	2
59	OX025	Audit Fees	EXPENSE	Professional Services	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.116+00	2026-03-09 20:19:33.116+00	2	2
60	OX026	Consultancy Fees	EXPENSE	Professional Services	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.116+00	2026-03-09 20:19:33.116+00	2	2
61	OX027	Bank Charges	EXPENSE	Financial	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.117+00	2026-03-09 20:19:33.117+00	2	2
62	OX028	Currency Exchange Loss	EXPENSE	Financial	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.117+00	2026-03-09 20:19:33.117+00	2	2
63	OX029	Marketing & Communications	EXPENSE	Marketing	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.118+00	2026-03-09 20:19:33.118+00	2	2
64	OX030	Events & Activities	EXPENSE	Marketing	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.119+00	2026-03-09 20:19:33.119+00	2	2
65	OX031	Travel — Staff	EXPENSE	Travel	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.119+00	2026-03-09 20:19:33.119+00	2	2
66	OX032	Travel — Management	EXPENSE	Travel	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.12+00	2026-03-09 20:19:33.12+00	2	2
67	OX033	Vehicle Fuel	EXPENSE	Transport	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.12+00	2026-03-09 20:19:33.12+00	2	2
68	OX034	Vehicle Maintenance	EXPENSE	Transport	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.121+00	2026-03-09 20:19:33.121+00	2	2
69	OX035	School Bus Costs	EXPENSE	Transport	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.121+00	2026-03-09 20:19:33.121+00	2	2
70	OX036	AEFE Fees	EXPENSE	Regulatory	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.122+00	2026-03-09 20:19:33.122+00	2	2
71	OX037	Government Licenses	EXPENSE	Regulatory	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.122+00	2026-03-09 20:19:33.122+00	2	2
72	OX038	Accreditation Fees	EXPENSE	Regulatory	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.123+00	2026-03-09 20:19:33.123+00	2	2
73	OX039	Depreciation — Furniture	EXPENSE	Depreciation	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.123+00	2026-03-09 20:19:33.123+00	2	2
74	OX040	Depreciation — Equipment	EXPENSE	Depreciation	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.124+00	2026-03-09 20:19:33.124+00	2	2
75	OX041	Depreciation — Vehicles	EXPENSE	Depreciation	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.124+00	2026-03-09 20:19:33.124+00	2	2
76	OX042	Contingency Reserve	EXPENSE	Contingency	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.125+00	2026-03-09 20:19:33.125+00	2	2
77	OX043	Miscellaneous OPEX	EXPENSE	Miscellaneous	COST_CENTER	\N	ACTIVE	1	2026-03-09 20:19:33.125+00	2026-03-09 20:19:33.125+00	2	2
\.


--
-- Data for Name: cohort_parameters; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.cohort_parameters (id, version_id, grade_level, retention_rate, lateral_entry_count, lateral_weight_fr, lateral_weight_nat, lateral_weight_aut, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.departments (id, code, label, band_mapping, version, created_at, updated_at, created_by, updated_by) FROM stdin;
1	TEST	Test	NON_ACADEMIC	1	2026-03-09 20:16:02.122+00	2026-03-09 20:16:02.122+00	1	1
2	TEACHING	Teaching	NON_ACADEMIC	1	2026-03-09 20:19:33.079+00	2026-03-09 20:19:33.079+00	2	2
3	ADMIN	Administration	NON_ACADEMIC	1	2026-03-09 20:19:33.08+00	2026-03-09 20:19:33.08+00	2	2
4	SUPPORT	Support	NON_ACADEMIC	1	2026-03-09 20:19:33.08+00	2026-03-09 20:19:33.08+00	2	2
5	MGMT	Management	NON_ACADEMIC	1	2026-03-09 20:19:33.081+00	2026-03-09 20:19:33.081+00	2	2
6	MAINT	Maintenance	NON_ACADEMIC	1	2026-03-09 20:19:33.082+00	2026-03-09 20:19:33.082+00	2	2
\.


--
-- Data for Name: dhg_grille_config; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.dhg_grille_config (id, grade_level, subject, dhg_type, hours_per_week_per_section, effective_from_year, created_at, updated_at) FROM stdin;
1	PS	Mobiliser le langage	Structural	6.00	2026	2026-03-09 20:15:46.551+00	2026-03-09 20:15:46.551+00
2	MS	Mobiliser le langage	Structural	6.00	2026	2026-03-09 20:15:46.552+00	2026-03-09 20:15:46.552+00
3	GS	Mobiliser le langage	Structural	6.50	2026	2026-03-09 20:15:46.552+00	2026-03-09 20:15:46.552+00
4	PS	Activites physiques	Structural	5.00	2026	2026-03-09 20:15:46.553+00	2026-03-09 20:15:46.553+00
5	MS	Activites physiques	Structural	5.00	2026	2026-03-09 20:15:46.553+00	2026-03-09 20:15:46.553+00
6	GS	Activites physiques	Structural	4.00	2026	2026-03-09 20:15:46.554+00	2026-03-09 20:15:46.554+00
7	PS	Activites artistiques	Structural	3.00	2026	2026-03-09 20:15:46.554+00	2026-03-09 20:15:46.554+00
8	MS	Activites artistiques	Structural	3.00	2026	2026-03-09 20:15:46.554+00	2026-03-09 20:15:46.554+00
9	GS	Activites artistiques	Structural	3.00	2026	2026-03-09 20:15:46.555+00	2026-03-09 20:15:46.555+00
10	PS	Construire les premiers outils	Structural	4.00	2026	2026-03-09 20:15:46.555+00	2026-03-09 20:15:46.555+00
11	MS	Construire les premiers outils	Structural	5.00	2026	2026-03-09 20:15:46.555+00	2026-03-09 20:15:46.555+00
12	GS	Construire les premiers outils	Structural	5.50	2026	2026-03-09 20:15:46.556+00	2026-03-09 20:15:46.556+00
13	PS	Explorer le monde	Structural	4.00	2026	2026-03-09 20:15:46.556+00	2026-03-09 20:15:46.556+00
14	MS	Explorer le monde	Structural	4.00	2026	2026-03-09 20:15:46.557+00	2026-03-09 20:15:46.557+00
15	GS	Explorer le monde	Structural	4.50	2026	2026-03-09 20:15:46.557+00	2026-03-09 20:15:46.557+00
16	PS	Arabe	Structural	2.00	2026	2026-03-09 20:15:46.557+00	2026-03-09 20:15:46.557+00
17	MS	Arabe	Structural	2.00	2026	2026-03-09 20:15:46.558+00	2026-03-09 20:15:46.558+00
18	GS	Arabe	Structural	2.50	2026	2026-03-09 20:15:46.558+00	2026-03-09 20:15:46.558+00
19	PS	Anglais	Structural	1.00	2026	2026-03-09 20:15:46.558+00	2026-03-09 20:15:46.558+00
20	MS	Anglais	Structural	1.50	2026	2026-03-09 20:15:46.559+00	2026-03-09 20:15:46.559+00
21	GS	Anglais	Structural	2.00	2026	2026-03-09 20:15:46.559+00	2026-03-09 20:15:46.559+00
22	CP	Francais	Structural	10.00	2026	2026-03-09 20:15:46.559+00	2026-03-09 20:15:46.559+00
23	CE1	Francais	Structural	8.00	2026	2026-03-09 20:15:46.56+00	2026-03-09 20:15:46.56+00
24	CE2	Francais	Structural	8.00	2026	2026-03-09 20:15:46.56+00	2026-03-09 20:15:46.56+00
25	CM1	Francais	Structural	7.50	2026	2026-03-09 20:15:46.56+00	2026-03-09 20:15:46.56+00
26	CM2	Francais	Structural	7.50	2026	2026-03-09 20:15:46.561+00	2026-03-09 20:15:46.561+00
27	CP	Mathematiques	Structural	5.00	2026	2026-03-09 20:15:46.561+00	2026-03-09 20:15:46.561+00
28	CE1	Mathematiques	Structural	5.00	2026	2026-03-09 20:15:46.561+00	2026-03-09 20:15:46.561+00
29	CE2	Mathematiques	Structural	5.00	2026	2026-03-09 20:15:46.562+00	2026-03-09 20:15:46.562+00
30	CM1	Mathematiques	Structural	5.00	2026	2026-03-09 20:15:46.562+00	2026-03-09 20:15:46.562+00
31	CM2	Mathematiques	Structural	5.00	2026	2026-03-09 20:15:46.563+00	2026-03-09 20:15:46.563+00
32	CP	EPS	Structural	3.00	2026	2026-03-09 20:15:46.563+00	2026-03-09 20:15:46.563+00
33	CE1	EPS	Structural	3.00	2026	2026-03-09 20:15:46.563+00	2026-03-09 20:15:46.563+00
34	CE2	EPS	Structural	3.00	2026	2026-03-09 20:15:46.564+00	2026-03-09 20:15:46.564+00
35	CM1	EPS	Structural	3.00	2026	2026-03-09 20:15:46.564+00	2026-03-09 20:15:46.564+00
36	CM2	EPS	Structural	3.00	2026	2026-03-09 20:15:46.564+00	2026-03-09 20:15:46.564+00
37	CP	Sciences et Technologie	Structural	1.00	2026	2026-03-09 20:15:46.565+00	2026-03-09 20:15:46.565+00
38	CE1	Sciences et Technologie	Structural	1.50	2026	2026-03-09 20:15:46.565+00	2026-03-09 20:15:46.565+00
39	CE2	Sciences et Technologie	Structural	1.50	2026	2026-03-09 20:15:46.565+00	2026-03-09 20:15:46.565+00
40	CM1	Sciences et Technologie	Structural	2.00	2026	2026-03-09 20:15:46.566+00	2026-03-09 20:15:46.566+00
41	CM2	Sciences et Technologie	Structural	2.00	2026	2026-03-09 20:15:46.566+00	2026-03-09 20:15:46.566+00
42	CP	Histoire-Geographie-EMC	Structural	0.50	2026	2026-03-09 20:15:46.566+00	2026-03-09 20:15:46.566+00
43	CE1	Histoire-Geographie-EMC	Structural	1.00	2026	2026-03-09 20:15:46.567+00	2026-03-09 20:15:46.567+00
44	CE2	Histoire-Geographie-EMC	Structural	1.50	2026	2026-03-09 20:15:46.567+00	2026-03-09 20:15:46.567+00
45	CM1	Histoire-Geographie-EMC	Structural	2.50	2026	2026-03-09 20:15:46.568+00	2026-03-09 20:15:46.568+00
46	CM2	Histoire-Geographie-EMC	Structural	2.50	2026	2026-03-09 20:15:46.568+00	2026-03-09 20:15:46.568+00
47	CP	Arts Plastiques	Structural	1.00	2026	2026-03-09 20:15:46.568+00	2026-03-09 20:15:46.568+00
48	CE1	Arts Plastiques	Structural	1.00	2026	2026-03-09 20:15:46.569+00	2026-03-09 20:15:46.569+00
49	CE2	Arts Plastiques	Structural	1.00	2026	2026-03-09 20:15:46.569+00	2026-03-09 20:15:46.569+00
50	CM1	Arts Plastiques	Structural	1.00	2026	2026-03-09 20:15:46.569+00	2026-03-09 20:15:46.569+00
51	CM2	Arts Plastiques	Structural	1.00	2026	2026-03-09 20:15:46.57+00	2026-03-09 20:15:46.57+00
52	CP	Education Musicale	Structural	1.00	2026	2026-03-09 20:15:46.57+00	2026-03-09 20:15:46.57+00
53	CE1	Education Musicale	Structural	1.00	2026	2026-03-09 20:15:46.57+00	2026-03-09 20:15:46.57+00
54	CE2	Education Musicale	Structural	1.00	2026	2026-03-09 20:15:46.571+00	2026-03-09 20:15:46.571+00
55	CM1	Education Musicale	Structural	1.00	2026	2026-03-09 20:15:46.571+00	2026-03-09 20:15:46.571+00
56	CM2	Education Musicale	Structural	1.00	2026	2026-03-09 20:15:46.571+00	2026-03-09 20:15:46.571+00
57	CP	Arabe	Structural	2.00	2026	2026-03-09 20:15:46.572+00	2026-03-09 20:15:46.572+00
58	CE1	Arabe	Structural	2.50	2026	2026-03-09 20:15:46.572+00	2026-03-09 20:15:46.572+00
59	CE2	Arabe	Structural	2.50	2026	2026-03-09 20:15:46.572+00	2026-03-09 20:15:46.572+00
60	CM1	Arabe	Structural	2.50	2026	2026-03-09 20:15:46.573+00	2026-03-09 20:15:46.573+00
61	CM2	Arabe	Structural	2.50	2026	2026-03-09 20:15:46.573+00	2026-03-09 20:15:46.573+00
62	CP	Anglais	Structural	1.50	2026	2026-03-09 20:15:46.574+00	2026-03-09 20:15:46.574+00
63	CE1	Anglais	Structural	2.00	2026	2026-03-09 20:15:46.574+00	2026-03-09 20:15:46.574+00
64	CE2	Anglais	Structural	2.00	2026	2026-03-09 20:15:46.574+00	2026-03-09 20:15:46.574+00
65	CM1	Anglais	Structural	2.00	2026	2026-03-09 20:15:46.575+00	2026-03-09 20:15:46.575+00
66	CM2	Anglais	Structural	2.00	2026	2026-03-09 20:15:46.575+00	2026-03-09 20:15:46.575+00
67	6EME	Francais	Structural	4.50	2026	2026-03-09 20:15:46.575+00	2026-03-09 20:15:46.575+00
68	6EME	Mathematiques	Structural	4.50	2026	2026-03-09 20:15:46.576+00	2026-03-09 20:15:46.576+00
69	6EME	Histoire-Geographie-EMC	Structural	3.00	2026	2026-03-09 20:15:46.576+00	2026-03-09 20:15:46.576+00
70	6EME	SVT	Structural	1.50	2026	2026-03-09 20:15:46.576+00	2026-03-09 20:15:46.576+00
71	6EME	Physique-Chimie	Structural	1.00	2026	2026-03-09 20:15:46.577+00	2026-03-09 20:15:46.577+00
72	6EME	Technologie	Structural	1.50	2026	2026-03-09 20:15:46.577+00	2026-03-09 20:15:46.577+00
73	6EME	Anglais	Structural	4.00	2026	2026-03-09 20:15:46.578+00	2026-03-09 20:15:46.578+00
74	6EME	Arabe	Structural	3.00	2026	2026-03-09 20:15:46.578+00	2026-03-09 20:15:46.578+00
75	6EME	Arts Plastiques	Structural	1.00	2026	2026-03-09 20:15:46.578+00	2026-03-09 20:15:46.578+00
76	6EME	Education Musicale	Structural	1.00	2026	2026-03-09 20:15:46.579+00	2026-03-09 20:15:46.579+00
77	6EME	EPS	Structural	4.00	2026	2026-03-09 20:15:46.579+00	2026-03-09 20:15:46.579+00
78	5EME	Francais	Structural	4.50	2026	2026-03-09 20:15:46.579+00	2026-03-09 20:15:46.579+00
79	5EME	Mathematiques	Structural	3.50	2026	2026-03-09 20:15:46.58+00	2026-03-09 20:15:46.58+00
80	5EME	Histoire-Geographie-EMC	Structural	3.00	2026	2026-03-09 20:15:46.58+00	2026-03-09 20:15:46.58+00
81	5EME	SVT	Structural	1.50	2026	2026-03-09 20:15:46.58+00	2026-03-09 20:15:46.58+00
82	5EME	Physique-Chimie	Structural	1.50	2026	2026-03-09 20:15:46.581+00	2026-03-09 20:15:46.581+00
83	5EME	Technologie	Structural	1.50	2026	2026-03-09 20:15:46.581+00	2026-03-09 20:15:46.581+00
84	5EME	Anglais	Structural	3.00	2026	2026-03-09 20:15:46.581+00	2026-03-09 20:15:46.581+00
85	5EME	Arabe	Structural	3.00	2026	2026-03-09 20:15:46.582+00	2026-03-09 20:15:46.582+00
86	5EME	Arts Plastiques	Structural	1.00	2026	2026-03-09 20:15:46.582+00	2026-03-09 20:15:46.582+00
87	5EME	Education Musicale	Structural	1.00	2026	2026-03-09 20:15:46.582+00	2026-03-09 20:15:46.582+00
88	5EME	EPS	Structural	3.00	2026	2026-03-09 20:15:46.583+00	2026-03-09 20:15:46.583+00
89	5EME	Espagnol	Structural	2.50	2026	2026-03-09 20:15:46.583+00	2026-03-09 20:15:46.583+00
90	4EME	Francais	Structural	4.50	2026	2026-03-09 20:15:46.583+00	2026-03-09 20:15:46.583+00
91	4EME	Mathematiques	Structural	3.50	2026	2026-03-09 20:15:46.584+00	2026-03-09 20:15:46.584+00
92	4EME	Histoire-Geographie-EMC	Structural	3.00	2026	2026-03-09 20:15:46.584+00	2026-03-09 20:15:46.584+00
93	4EME	SVT	Structural	1.50	2026	2026-03-09 20:15:46.585+00	2026-03-09 20:15:46.585+00
94	4EME	Physique-Chimie	Structural	1.50	2026	2026-03-09 20:15:46.585+00	2026-03-09 20:15:46.585+00
95	4EME	Technologie	Structural	1.50	2026	2026-03-09 20:15:46.585+00	2026-03-09 20:15:46.585+00
96	4EME	Anglais	Structural	3.00	2026	2026-03-09 20:15:46.586+00	2026-03-09 20:15:46.586+00
97	4EME	Arabe	Structural	3.00	2026	2026-03-09 20:15:46.586+00	2026-03-09 20:15:46.586+00
98	4EME	Espagnol	Structural	2.50	2026	2026-03-09 20:15:46.586+00	2026-03-09 20:15:46.586+00
99	4EME	Arts Plastiques	Structural	1.00	2026	2026-03-09 20:15:46.587+00	2026-03-09 20:15:46.587+00
100	4EME	Education Musicale	Structural	1.00	2026	2026-03-09 20:15:46.587+00	2026-03-09 20:15:46.587+00
101	4EME	EPS	Structural	3.00	2026	2026-03-09 20:15:46.588+00	2026-03-09 20:15:46.588+00
102	3EME	Francais	Structural	4.00	2026	2026-03-09 20:15:46.588+00	2026-03-09 20:15:46.588+00
103	3EME	Mathematiques	Structural	3.50	2026	2026-03-09 20:15:46.588+00	2026-03-09 20:15:46.588+00
104	3EME	Histoire-Geographie-EMC	Structural	3.50	2026	2026-03-09 20:15:46.589+00	2026-03-09 20:15:46.589+00
105	3EME	SVT	Structural	1.50	2026	2026-03-09 20:15:46.589+00	2026-03-09 20:15:46.589+00
106	3EME	Physique-Chimie	Structural	1.50	2026	2026-03-09 20:15:46.589+00	2026-03-09 20:15:46.589+00
107	3EME	Technologie	Structural	1.50	2026	2026-03-09 20:15:46.59+00	2026-03-09 20:15:46.59+00
108	3EME	Anglais	Structural	3.00	2026	2026-03-09 20:15:46.59+00	2026-03-09 20:15:46.59+00
109	3EME	Arabe	Structural	3.00	2026	2026-03-09 20:15:46.59+00	2026-03-09 20:15:46.59+00
110	3EME	Espagnol	Structural	2.50	2026	2026-03-09 20:15:46.591+00	2026-03-09 20:15:46.591+00
111	3EME	Arts Plastiques	Structural	1.00	2026	2026-03-09 20:15:46.591+00	2026-03-09 20:15:46.591+00
112	3EME	Education Musicale	Structural	1.00	2026	2026-03-09 20:15:46.591+00	2026-03-09 20:15:46.591+00
113	3EME	EPS	Structural	3.00	2026	2026-03-09 20:15:46.592+00	2026-03-09 20:15:46.592+00
114	2NDE	Francais	Structural	4.00	2026	2026-03-09 20:15:46.592+00	2026-03-09 20:15:46.592+00
115	2NDE	Mathematiques	Structural	4.00	2026	2026-03-09 20:15:46.592+00	2026-03-09 20:15:46.592+00
116	2NDE	Histoire-Geographie	Structural	3.00	2026	2026-03-09 20:15:46.593+00	2026-03-09 20:15:46.593+00
117	2NDE	SVT	Structural	1.50	2026	2026-03-09 20:15:46.593+00	2026-03-09 20:15:46.593+00
118	2NDE	Physique-Chimie	Structural	3.00	2026	2026-03-09 20:15:46.594+00	2026-03-09 20:15:46.594+00
119	2NDE	SES	Structural	1.50	2026	2026-03-09 20:15:46.594+00	2026-03-09 20:15:46.594+00
120	2NDE	Anglais	Structural	3.00	2026	2026-03-09 20:15:46.594+00	2026-03-09 20:15:46.594+00
121	2NDE	Arabe	Structural	3.00	2026	2026-03-09 20:15:46.595+00	2026-03-09 20:15:46.595+00
122	2NDE	Espagnol	Structural	2.50	2026	2026-03-09 20:15:46.595+00	2026-03-09 20:15:46.595+00
123	2NDE	EPS	Structural	2.00	2026	2026-03-09 20:15:46.595+00	2026-03-09 20:15:46.595+00
124	2NDE	SNT	Structural	1.50	2026	2026-03-09 20:15:46.596+00	2026-03-09 20:15:46.596+00
125	2NDE	EMC	Structural	0.50	2026	2026-03-09 20:15:46.596+00	2026-03-09 20:15:46.596+00
126	1ERE	Francais	Structural	4.00	2026	2026-03-09 20:15:46.596+00	2026-03-09 20:15:46.596+00
127	1ERE	Mathematiques	Structural	4.00	2026	2026-03-09 20:15:46.597+00	2026-03-09 20:15:46.597+00
128	1ERE	Histoire-Geographie	Structural	3.00	2026	2026-03-09 20:15:46.597+00	2026-03-09 20:15:46.597+00
129	1ERE	Specialite 1	Structural	4.00	2026	2026-03-09 20:15:46.598+00	2026-03-09 20:15:46.598+00
130	1ERE	Specialite 2	Structural	4.00	2026	2026-03-09 20:15:46.598+00	2026-03-09 20:15:46.598+00
131	1ERE	Specialite 3	Structural	4.00	2026	2026-03-09 20:15:46.598+00	2026-03-09 20:15:46.598+00
132	1ERE	Anglais	Structural	2.50	2026	2026-03-09 20:15:46.599+00	2026-03-09 20:15:46.599+00
133	1ERE	Arabe	Structural	2.50	2026	2026-03-09 20:15:46.599+00	2026-03-09 20:15:46.599+00
134	1ERE	Espagnol	Structural	2.00	2026	2026-03-09 20:15:46.599+00	2026-03-09 20:15:46.599+00
135	1ERE	EPS	Structural	2.00	2026	2026-03-09 20:15:46.6+00	2026-03-09 20:15:46.6+00
136	1ERE	EMC	Structural	0.50	2026	2026-03-09 20:15:46.6+00	2026-03-09 20:15:46.6+00
137	1ERE	Enseignement Scientifique	Structural	2.00	2026	2026-03-09 20:15:46.6+00	2026-03-09 20:15:46.6+00
138	TERM	Philosophie	Structural	4.00	2026	2026-03-09 20:15:46.601+00	2026-03-09 20:15:46.601+00
139	TERM	Mathematiques	Structural	3.50	2026	2026-03-09 20:15:46.601+00	2026-03-09 20:15:46.601+00
140	TERM	Histoire-Geographie	Structural	3.00	2026	2026-03-09 20:15:46.601+00	2026-03-09 20:15:46.601+00
141	TERM	Specialite 1	Structural	6.00	2026	2026-03-09 20:15:46.602+00	2026-03-09 20:15:46.602+00
142	TERM	Specialite 2	Structural	6.00	2026	2026-03-09 20:15:46.602+00	2026-03-09 20:15:46.602+00
143	TERM	Anglais	Structural	2.00	2026	2026-03-09 20:15:46.602+00	2026-03-09 20:15:46.602+00
144	TERM	Arabe	Structural	2.00	2026	2026-03-09 20:15:46.603+00	2026-03-09 20:15:46.603+00
145	TERM	Espagnol	Structural	2.00	2026	2026-03-09 20:15:46.603+00	2026-03-09 20:15:46.603+00
146	TERM	EPS	Structural	2.00	2026	2026-03-09 20:15:46.603+00	2026-03-09 20:15:46.603+00
147	TERM	EMC	Structural	0.50	2026	2026-03-09 20:15:46.604+00	2026-03-09 20:15:46.604+00
148	TERM	Enseignement Scientifique	Structural	2.00	2026	2026-03-09 20:15:46.604+00	2026-03-09 20:15:46.604+00
\.


--
-- Data for Name: dhg_requirements; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.dhg_requirements (id, version_id, academic_period, grade_level, headcount, max_class_size, sections_needed, utilization, alert, recruitment_slots, created_at, updated_at, total_weekly_hours, total_annual_hours, fte) FROM stdin;
\.


--
-- Data for Name: discount_policies; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.discount_policies (id, version_id, tariff, nationality, discount_rate, created_at, updated_at, created_by, updated_by) FROM stdin;
1	2	Plein	\N	0.000000	2026-03-09 20:15:46.535+00	2026-03-09 20:15:46.535+00	2	\N
2	2	RP	\N	0.250000	2026-03-09 20:15:46.537+00	2026-03-09 20:15:46.537+00	2	\N
3	2	R3P	\N	0.100000	2026-03-09 20:15:46.538+00	2026-03-09 20:15:46.538+00	2	\N
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.employees (id, version_id, employee_code, name, function_role, department, status, joining_date, payment_method, is_saudi, is_ajeer, is_teaching, hourly_percentage, base_salary, housing_allowance, transport_allowance, responsibility_premium, hsa_amount, augmentation, augmentation_effective_date, ajeer_annual_levy, ajeer_monthly_fee, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: enrollment_detail; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.enrollment_detail (id, version_id, academic_period, grade_level, nationality, tariff, headcount, created_at, updated_at, created_by, updated_by) FROM stdin;
1	2	AY1	PS	FR	Plein	39	2026-03-09 20:15:46.304+00	2026-03-09 20:15:46.304+00	2	\N
2	2	AY1	PS	FR	RP	6	2026-03-09 20:15:46.305+00	2026-03-09 20:15:46.305+00	2	\N
3	2	AY1	PS	FR	R3P	5	2026-03-09 20:15:46.306+00	2026-03-09 20:15:46.306+00	2	\N
4	2	AY1	PS	NAT	Plein	25	2026-03-09 20:15:46.306+00	2026-03-09 20:15:46.306+00	2	\N
5	2	AY1	PS	NAT	RP	4	2026-03-09 20:15:46.307+00	2026-03-09 20:15:46.307+00	2	\N
6	2	AY1	PS	AUT	Plein	18	2026-03-09 20:15:46.308+00	2026-03-09 20:15:46.308+00	2	\N
7	2	AY1	PS	AUT	RP	3	2026-03-09 20:15:46.308+00	2026-03-09 20:15:46.308+00	2	\N
8	2	AY1	MS	FR	Plein	41	2026-03-09 20:15:46.309+00	2026-03-09 20:15:46.309+00	2	\N
9	2	AY1	MS	FR	RP	6	2026-03-09 20:15:46.309+00	2026-03-09 20:15:46.309+00	2	\N
10	2	AY1	MS	FR	R3P	5	2026-03-09 20:15:46.309+00	2026-03-09 20:15:46.309+00	2	\N
11	2	AY1	MS	NAT	Plein	25	2026-03-09 20:15:46.31+00	2026-03-09 20:15:46.31+00	2	\N
12	2	AY1	MS	NAT	RP	4	2026-03-09 20:15:46.31+00	2026-03-09 20:15:46.31+00	2	\N
13	2	AY1	MS	AUT	Plein	19	2026-03-09 20:15:46.311+00	2026-03-09 20:15:46.311+00	2	\N
14	2	AY1	MS	AUT	RP	3	2026-03-09 20:15:46.311+00	2026-03-09 20:15:46.311+00	2	\N
15	2	AY1	GS	FR	Plein	42	2026-03-09 20:15:46.312+00	2026-03-09 20:15:46.312+00	2	\N
16	2	AY1	GS	FR	RP	6	2026-03-09 20:15:46.312+00	2026-03-09 20:15:46.312+00	2	\N
17	2	AY1	GS	FR	R3P	5	2026-03-09 20:15:46.313+00	2026-03-09 20:15:46.313+00	2	\N
18	2	AY1	GS	NAT	Plein	26	2026-03-09 20:15:46.313+00	2026-03-09 20:15:46.313+00	2	\N
19	2	AY1	GS	NAT	RP	4	2026-03-09 20:15:46.313+00	2026-03-09 20:15:46.313+00	2	\N
20	2	AY1	GS	AUT	Plein	19	2026-03-09 20:15:46.314+00	2026-03-09 20:15:46.314+00	2	\N
21	2	AY1	GS	AUT	RP	4	2026-03-09 20:15:46.314+00	2026-03-09 20:15:46.314+00	2	\N
22	2	AY1	CP	FR	Plein	42	2026-03-09 20:15:46.315+00	2026-03-09 20:15:46.315+00	2	\N
23	2	AY1	CP	FR	RP	6	2026-03-09 20:15:46.315+00	2026-03-09 20:15:46.315+00	2	\N
24	2	AY1	CP	FR	R3P	5	2026-03-09 20:15:46.316+00	2026-03-09 20:15:46.316+00	2	\N
25	2	AY1	CP	NAT	Plein	26	2026-03-09 20:15:46.316+00	2026-03-09 20:15:46.316+00	2	\N
26	2	AY1	CP	NAT	RP	4	2026-03-09 20:15:46.316+00	2026-03-09 20:15:46.316+00	2	\N
27	2	AY1	CP	NAT	R3P	3	2026-03-09 20:15:46.317+00	2026-03-09 20:15:46.317+00	2	\N
28	2	AY1	CP	AUT	Plein	19	2026-03-09 20:15:46.318+00	2026-03-09 20:15:46.318+00	2	\N
29	2	AY1	CP	AUT	RP	5	2026-03-09 20:15:46.318+00	2026-03-09 20:15:46.318+00	2	\N
30	2	AY1	CE1	FR	Plein	43	2026-03-09 20:15:46.318+00	2026-03-09 20:15:46.318+00	2	\N
31	2	AY1	CE1	FR	RP	7	2026-03-09 20:15:46.319+00	2026-03-09 20:15:46.319+00	2	\N
32	2	AY1	CE1	FR	R3P	6	2026-03-09 20:15:46.319+00	2026-03-09 20:15:46.319+00	2	\N
33	2	AY1	CE1	NAT	Plein	27	2026-03-09 20:15:46.32+00	2026-03-09 20:15:46.32+00	2	\N
34	2	AY1	CE1	NAT	RP	4	2026-03-09 20:15:46.32+00	2026-03-09 20:15:46.32+00	2	\N
35	2	AY1	CE1	NAT	R3P	3	2026-03-09 20:15:46.321+00	2026-03-09 20:15:46.321+00	2	\N
36	2	AY1	CE1	AUT	Plein	20	2026-03-09 20:15:46.322+00	2026-03-09 20:15:46.322+00	2	\N
37	2	AY1	CE1	AUT	RP	3	2026-03-09 20:15:46.323+00	2026-03-09 20:15:46.323+00	2	\N
38	2	AY1	CE2	FR	Plein	44	2026-03-09 20:15:46.323+00	2026-03-09 20:15:46.323+00	2	\N
39	2	AY1	CE2	FR	RP	7	2026-03-09 20:15:46.324+00	2026-03-09 20:15:46.324+00	2	\N
40	2	AY1	CE2	FR	R3P	6	2026-03-09 20:15:46.325+00	2026-03-09 20:15:46.325+00	2	\N
41	2	AY1	CE2	NAT	Plein	28	2026-03-09 20:15:46.325+00	2026-03-09 20:15:46.325+00	2	\N
42	2	AY1	CE2	NAT	RP	4	2026-03-09 20:15:46.325+00	2026-03-09 20:15:46.325+00	2	\N
43	2	AY1	CE2	NAT	R3P	4	2026-03-09 20:15:46.326+00	2026-03-09 20:15:46.326+00	2	\N
44	2	AY1	CE2	AUT	Plein	20	2026-03-09 20:15:46.326+00	2026-03-09 20:15:46.326+00	2	\N
45	2	AY1	CE2	AUT	RP	3	2026-03-09 20:15:46.327+00	2026-03-09 20:15:46.327+00	2	\N
46	2	AY1	CM1	FR	Plein	46	2026-03-09 20:15:46.327+00	2026-03-09 20:15:46.327+00	2	\N
47	2	AY1	CM1	FR	RP	7	2026-03-09 20:15:46.327+00	2026-03-09 20:15:46.327+00	2	\N
48	2	AY1	CM1	FR	R3P	6	2026-03-09 20:15:46.328+00	2026-03-09 20:15:46.328+00	2	\N
49	2	AY1	CM1	NAT	Plein	28	2026-03-09 20:15:46.328+00	2026-03-09 20:15:46.328+00	2	\N
50	2	AY1	CM1	NAT	RP	4	2026-03-09 20:15:46.329+00	2026-03-09 20:15:46.329+00	2	\N
51	2	AY1	CM1	NAT	R3P	4	2026-03-09 20:15:46.329+00	2026-03-09 20:15:46.329+00	2	\N
52	2	AY1	CM1	AUT	Plein	21	2026-03-09 20:15:46.33+00	2026-03-09 20:15:46.33+00	2	\N
53	2	AY1	CM1	AUT	RP	3	2026-03-09 20:15:46.33+00	2026-03-09 20:15:46.33+00	2	\N
54	2	AY1	CM2	FR	Plein	47	2026-03-09 20:15:46.33+00	2026-03-09 20:15:46.33+00	2	\N
55	2	AY1	CM2	FR	RP	7	2026-03-09 20:15:46.331+00	2026-03-09 20:15:46.331+00	2	\N
56	2	AY1	CM2	FR	R3P	6	2026-03-09 20:15:46.332+00	2026-03-09 20:15:46.332+00	2	\N
57	2	AY1	CM2	NAT	Plein	29	2026-03-09 20:15:46.332+00	2026-03-09 20:15:46.332+00	2	\N
58	2	AY1	CM2	NAT	RP	4	2026-03-09 20:15:46.333+00	2026-03-09 20:15:46.333+00	2	\N
59	2	AY1	CM2	NAT	R3P	4	2026-03-09 20:15:46.333+00	2026-03-09 20:15:46.333+00	2	\N
60	2	AY1	CM2	AUT	Plein	21	2026-03-09 20:15:46.333+00	2026-03-09 20:15:46.333+00	2	\N
61	2	AY1	CM2	AUT	RP	4	2026-03-09 20:15:46.334+00	2026-03-09 20:15:46.334+00	2	\N
62	2	AY1	6EME	FR	Plein	50	2026-03-09 20:15:46.334+00	2026-03-09 20:15:46.334+00	2	\N
63	2	AY1	6EME	FR	RP	8	2026-03-09 20:15:46.335+00	2026-03-09 20:15:46.335+00	2	\N
64	2	AY1	6EME	FR	R3P	6	2026-03-09 20:15:46.335+00	2026-03-09 20:15:46.335+00	2	\N
65	2	AY1	6EME	NAT	Plein	31	2026-03-09 20:15:46.336+00	2026-03-09 20:15:46.336+00	2	\N
66	2	AY1	6EME	NAT	RP	5	2026-03-09 20:15:46.336+00	2026-03-09 20:15:46.336+00	2	\N
67	2	AY1	6EME	NAT	R3P	4	2026-03-09 20:15:46.337+00	2026-03-09 20:15:46.337+00	2	\N
68	2	AY1	6EME	AUT	Plein	23	2026-03-09 20:15:46.337+00	2026-03-09 20:15:46.337+00	2	\N
69	2	AY1	6EME	AUT	RP	4	2026-03-09 20:15:46.338+00	2026-03-09 20:15:46.338+00	2	\N
70	2	AY1	5EME	FR	Plein	51	2026-03-09 20:15:46.338+00	2026-03-09 20:15:46.338+00	2	\N
71	2	AY1	5EME	FR	RP	8	2026-03-09 20:15:46.339+00	2026-03-09 20:15:46.339+00	2	\N
72	2	AY1	5EME	FR	R3P	7	2026-03-09 20:15:46.339+00	2026-03-09 20:15:46.339+00	2	\N
73	2	AY1	5EME	NAT	Plein	32	2026-03-09 20:15:46.339+00	2026-03-09 20:15:46.339+00	2	\N
74	2	AY1	5EME	NAT	RP	5	2026-03-09 20:15:46.34+00	2026-03-09 20:15:46.34+00	2	\N
75	2	AY1	5EME	NAT	R3P	4	2026-03-09 20:15:46.34+00	2026-03-09 20:15:46.34+00	2	\N
76	2	AY1	5EME	AUT	Plein	24	2026-03-09 20:15:46.341+00	2026-03-09 20:15:46.341+00	2	\N
77	2	AY1	5EME	AUT	RP	3	2026-03-09 20:15:46.341+00	2026-03-09 20:15:46.341+00	2	\N
78	2	AY1	4EME	FR	Plein	52	2026-03-09 20:15:46.342+00	2026-03-09 20:15:46.342+00	2	\N
79	2	AY1	4EME	FR	RP	8	2026-03-09 20:15:46.342+00	2026-03-09 20:15:46.342+00	2	\N
80	2	AY1	4EME	FR	R3P	7	2026-03-09 20:15:46.342+00	2026-03-09 20:15:46.342+00	2	\N
81	2	AY1	4EME	NAT	Plein	33	2026-03-09 20:15:46.343+00	2026-03-09 20:15:46.343+00	2	\N
82	2	AY1	4EME	NAT	RP	5	2026-03-09 20:15:46.343+00	2026-03-09 20:15:46.343+00	2	\N
83	2	AY1	4EME	NAT	R3P	4	2026-03-09 20:15:46.344+00	2026-03-09 20:15:46.344+00	2	\N
84	2	AY1	4EME	AUT	Plein	24	2026-03-09 20:15:46.344+00	2026-03-09 20:15:46.344+00	2	\N
85	2	AY1	4EME	AUT	RP	4	2026-03-09 20:15:46.345+00	2026-03-09 20:15:46.345+00	2	\N
86	2	AY1	3EME	FR	Plein	53	2026-03-09 20:15:46.345+00	2026-03-09 20:15:46.345+00	2	\N
87	2	AY1	3EME	FR	RP	8	2026-03-09 20:15:46.346+00	2026-03-09 20:15:46.346+00	2	\N
88	2	AY1	3EME	FR	R3P	7	2026-03-09 20:15:46.346+00	2026-03-09 20:15:46.346+00	2	\N
89	2	AY1	3EME	NAT	Plein	33	2026-03-09 20:15:46.347+00	2026-03-09 20:15:46.347+00	2	\N
90	2	AY1	3EME	NAT	RP	5	2026-03-09 20:15:46.347+00	2026-03-09 20:15:46.347+00	2	\N
91	2	AY1	3EME	NAT	R3P	4	2026-03-09 20:15:46.348+00	2026-03-09 20:15:46.348+00	2	\N
92	2	AY1	3EME	AUT	Plein	24	2026-03-09 20:15:46.348+00	2026-03-09 20:15:46.348+00	2	\N
93	2	AY1	3EME	AUT	RP	5	2026-03-09 20:15:46.348+00	2026-03-09 20:15:46.348+00	2	\N
94	2	AY1	2NDE	FR	Plein	48	2026-03-09 20:15:46.349+00	2026-03-09 20:15:46.349+00	2	\N
95	2	AY1	2NDE	FR	RP	7	2026-03-09 20:15:46.349+00	2026-03-09 20:15:46.349+00	2	\N
96	2	AY1	2NDE	FR	R3P	6	2026-03-09 20:15:46.35+00	2026-03-09 20:15:46.35+00	2	\N
97	2	AY1	2NDE	NAT	Plein	30	2026-03-09 20:15:46.35+00	2026-03-09 20:15:46.35+00	2	\N
98	2	AY1	2NDE	NAT	RP	5	2026-03-09 20:15:46.351+00	2026-03-09 20:15:46.351+00	2	\N
99	2	AY1	2NDE	NAT	R3P	4	2026-03-09 20:15:46.351+00	2026-03-09 20:15:46.351+00	2	\N
100	2	AY1	2NDE	AUT	Plein	22	2026-03-09 20:15:46.352+00	2026-03-09 20:15:46.352+00	2	\N
101	2	AY1	2NDE	AUT	RP	3	2026-03-09 20:15:46.352+00	2026-03-09 20:15:46.352+00	2	\N
102	2	AY1	1ERE	FR	Plein	46	2026-03-09 20:15:46.352+00	2026-03-09 20:15:46.352+00	2	\N
103	2	AY1	1ERE	FR	RP	7	2026-03-09 20:15:46.353+00	2026-03-09 20:15:46.353+00	2	\N
104	2	AY1	1ERE	FR	R3P	6	2026-03-09 20:15:46.353+00	2026-03-09 20:15:46.353+00	2	\N
105	2	AY1	1ERE	NAT	Plein	29	2026-03-09 20:15:46.354+00	2026-03-09 20:15:46.354+00	2	\N
106	2	AY1	1ERE	NAT	RP	4	2026-03-09 20:15:46.354+00	2026-03-09 20:15:46.354+00	2	\N
107	2	AY1	1ERE	NAT	R3P	4	2026-03-09 20:15:46.355+00	2026-03-09 20:15:46.355+00	2	\N
108	2	AY1	1ERE	AUT	Plein	21	2026-03-09 20:15:46.355+00	2026-03-09 20:15:46.355+00	2	\N
109	2	AY1	1ERE	AUT	RP	3	2026-03-09 20:15:46.355+00	2026-03-09 20:15:46.355+00	2	\N
110	2	AY1	TERM	FR	Plein	30	2026-03-09 20:15:46.356+00	2026-03-09 20:15:46.356+00	2	\N
111	2	AY1	TERM	FR	RP	5	2026-03-09 20:15:46.356+00	2026-03-09 20:15:46.356+00	2	\N
112	2	AY1	TERM	FR	R3P	4	2026-03-09 20:15:46.357+00	2026-03-09 20:15:46.357+00	2	\N
113	2	AY1	TERM	NAT	Plein	19	2026-03-09 20:15:46.357+00	2026-03-09 20:15:46.357+00	2	\N
114	2	AY1	TERM	NAT	RP	3	2026-03-09 20:15:46.358+00	2026-03-09 20:15:46.358+00	2	\N
115	2	AY1	TERM	NAT	R3P	2	2026-03-09 20:15:46.358+00	2026-03-09 20:15:46.358+00	2	\N
116	2	AY1	TERM	AUT	Plein	14	2026-03-09 20:15:46.358+00	2026-03-09 20:15:46.358+00	2	\N
117	2	AY1	TERM	AUT	RP	1	2026-03-09 20:15:46.359+00	2026-03-09 20:15:46.359+00	2	\N
118	2	AY2	PS	FR	Plein	40	2026-03-09 20:15:46.359+00	2026-03-09 20:15:46.359+00	2	\N
119	2	AY2	PS	FR	RP	6	2026-03-09 20:15:46.36+00	2026-03-09 20:15:46.36+00	2	\N
120	2	AY2	PS	FR	R3P	5	2026-03-09 20:15:46.36+00	2026-03-09 20:15:46.36+00	2	\N
121	2	AY2	PS	NAT	Plein	25	2026-03-09 20:15:46.36+00	2026-03-09 20:15:46.36+00	2	\N
122	2	AY2	PS	AUT	Plein	19	2026-03-09 20:15:46.361+00	2026-03-09 20:15:46.361+00	2	\N
123	2	AY2	MS	FR	Plein	41	2026-03-09 20:15:46.361+00	2026-03-09 20:15:46.361+00	2	\N
124	2	AY2	MS	FR	RP	6	2026-03-09 20:15:46.362+00	2026-03-09 20:15:46.362+00	2	\N
125	2	AY2	MS	FR	R3P	5	2026-03-09 20:15:46.362+00	2026-03-09 20:15:46.362+00	2	\N
126	2	AY2	MS	NAT	Plein	26	2026-03-09 20:15:46.362+00	2026-03-09 20:15:46.362+00	2	\N
127	2	AY2	MS	AUT	Plein	20	2026-03-09 20:15:46.363+00	2026-03-09 20:15:46.363+00	2	\N
128	2	AY2	GS	FR	Plein	45	2026-03-09 20:15:46.363+00	2026-03-09 20:15:46.363+00	2	\N
129	2	AY2	GS	FR	RP	7	2026-03-09 20:15:46.364+00	2026-03-09 20:15:46.364+00	2	\N
130	2	AY2	GS	NAT	Plein	28	2026-03-09 20:15:46.364+00	2026-03-09 20:15:46.364+00	2	\N
131	2	AY2	GS	AUT	Plein	21	2026-03-09 20:15:46.365+00	2026-03-09 20:15:46.365+00	2	\N
132	2	AY2	CP	FR	Plein	41	2026-03-09 20:15:46.365+00	2026-03-09 20:15:46.365+00	2	\N
133	2	AY2	CP	FR	RP	6	2026-03-09 20:15:46.365+00	2026-03-09 20:15:46.365+00	2	\N
134	2	AY2	CP	FR	R3P	5	2026-03-09 20:15:46.366+00	2026-03-09 20:15:46.366+00	2	\N
135	2	AY2	CP	NAT	Plein	26	2026-03-09 20:15:46.366+00	2026-03-09 20:15:46.366+00	2	\N
136	2	AY2	CP	NAT	RP	4	2026-03-09 20:15:46.367+00	2026-03-09 20:15:46.367+00	2	\N
137	2	AY2	CP	NAT	R3P	3	2026-03-09 20:15:46.367+00	2026-03-09 20:15:46.367+00	2	\N
138	2	AY2	CP	AUT	Plein	20	2026-03-09 20:15:46.368+00	2026-03-09 20:15:46.368+00	2	\N
139	2	AY2	CE1	FR	Plein	42	2026-03-09 20:15:46.368+00	2026-03-09 20:15:46.368+00	2	\N
140	2	AY2	CE1	FR	RP	6	2026-03-09 20:15:46.368+00	2026-03-09 20:15:46.368+00	2	\N
141	2	AY2	CE1	FR	R3P	5	2026-03-09 20:15:46.369+00	2026-03-09 20:15:46.369+00	2	\N
142	2	AY2	CE1	NAT	Plein	26	2026-03-09 20:15:46.369+00	2026-03-09 20:15:46.369+00	2	\N
143	2	AY2	CE1	NAT	RP	4	2026-03-09 20:15:46.37+00	2026-03-09 20:15:46.37+00	2	\N
144	2	AY2	CE1	NAT	R3P	3	2026-03-09 20:15:46.37+00	2026-03-09 20:15:46.37+00	2	\N
145	2	AY2	CE1	AUT	Plein	21	2026-03-09 20:15:46.37+00	2026-03-09 20:15:46.37+00	2	\N
146	2	AY2	CE2	FR	Plein	43	2026-03-09 20:15:46.371+00	2026-03-09 20:15:46.371+00	2	\N
147	2	AY2	CE2	FR	RP	7	2026-03-09 20:15:46.371+00	2026-03-09 20:15:46.371+00	2	\N
148	2	AY2	CE2	FR	R3P	6	2026-03-09 20:15:46.372+00	2026-03-09 20:15:46.372+00	2	\N
149	2	AY2	CE2	NAT	Plein	27	2026-03-09 20:15:46.372+00	2026-03-09 20:15:46.372+00	2	\N
150	2	AY2	CE2	NAT	RP	4	2026-03-09 20:15:46.372+00	2026-03-09 20:15:46.372+00	2	\N
151	2	AY2	CE2	NAT	R3P	3	2026-03-09 20:15:46.373+00	2026-03-09 20:15:46.373+00	2	\N
152	2	AY2	CE2	AUT	Plein	20	2026-03-09 20:15:46.373+00	2026-03-09 20:15:46.373+00	2	\N
153	2	AY2	CM1	FR	Plein	44	2026-03-09 20:15:46.374+00	2026-03-09 20:15:46.374+00	2	\N
154	2	AY2	CM1	FR	RP	7	2026-03-09 20:15:46.374+00	2026-03-09 20:15:46.374+00	2	\N
155	2	AY2	CM1	FR	R3P	6	2026-03-09 20:15:46.375+00	2026-03-09 20:15:46.375+00	2	\N
156	2	AY2	CM1	NAT	Plein	28	2026-03-09 20:15:46.375+00	2026-03-09 20:15:46.375+00	2	\N
157	2	AY2	CM1	NAT	RP	4	2026-03-09 20:15:46.375+00	2026-03-09 20:15:46.375+00	2	\N
158	2	AY2	CM1	NAT	R3P	4	2026-03-09 20:15:46.376+00	2026-03-09 20:15:46.376+00	2	\N
159	2	AY2	CM1	AUT	Plein	20	2026-03-09 20:15:46.376+00	2026-03-09 20:15:46.376+00	2	\N
160	2	AY2	CM2	FR	Plein	46	2026-03-09 20:15:46.377+00	2026-03-09 20:15:46.377+00	2	\N
161	2	AY2	CM2	FR	RP	7	2026-03-09 20:15:46.377+00	2026-03-09 20:15:46.377+00	2	\N
162	2	AY2	CM2	FR	R3P	6	2026-03-09 20:15:46.377+00	2026-03-09 20:15:46.377+00	2	\N
163	2	AY2	CM2	NAT	Plein	29	2026-03-09 20:15:46.378+00	2026-03-09 20:15:46.378+00	2	\N
164	2	AY2	CM2	NAT	RP	4	2026-03-09 20:15:46.378+00	2026-03-09 20:15:46.378+00	2	\N
165	2	AY2	CM2	NAT	R3P	4	2026-03-09 20:15:46.379+00	2026-03-09 20:15:46.379+00	2	\N
166	2	AY2	CM2	AUT	Plein	20	2026-03-09 20:15:46.379+00	2026-03-09 20:15:46.379+00	2	\N
167	2	AY2	6EME	FR	Plein	49	2026-03-09 20:15:46.38+00	2026-03-09 20:15:46.38+00	2	\N
168	2	AY2	6EME	FR	RP	8	2026-03-09 20:15:46.38+00	2026-03-09 20:15:46.38+00	2	\N
169	2	AY2	6EME	FR	R3P	6	2026-03-09 20:15:46.381+00	2026-03-09 20:15:46.381+00	2	\N
170	2	AY2	6EME	NAT	Plein	30	2026-03-09 20:15:46.381+00	2026-03-09 20:15:46.381+00	2	\N
171	2	AY2	6EME	NAT	RP	5	2026-03-09 20:15:46.381+00	2026-03-09 20:15:46.381+00	2	\N
172	2	AY2	6EME	NAT	R3P	4	2026-03-09 20:15:46.382+00	2026-03-09 20:15:46.382+00	2	\N
173	2	AY2	6EME	AUT	Plein	22	2026-03-09 20:15:46.382+00	2026-03-09 20:15:46.382+00	2	\N
174	2	AY2	5EME	FR	Plein	50	2026-03-09 20:15:46.383+00	2026-03-09 20:15:46.383+00	2	\N
175	2	AY2	5EME	FR	RP	8	2026-03-09 20:15:46.383+00	2026-03-09 20:15:46.383+00	2	\N
176	2	AY2	5EME	FR	R3P	6	2026-03-09 20:15:46.383+00	2026-03-09 20:15:46.383+00	2	\N
177	2	AY2	5EME	NAT	Plein	31	2026-03-09 20:15:46.384+00	2026-03-09 20:15:46.384+00	2	\N
178	2	AY2	5EME	NAT	RP	5	2026-03-09 20:15:46.384+00	2026-03-09 20:15:46.384+00	2	\N
179	2	AY2	5EME	NAT	R3P	4	2026-03-09 20:15:46.385+00	2026-03-09 20:15:46.385+00	2	\N
180	2	AY2	5EME	AUT	Plein	23	2026-03-09 20:15:46.385+00	2026-03-09 20:15:46.385+00	2	\N
181	2	AY2	4EME	FR	Plein	51	2026-03-09 20:15:46.386+00	2026-03-09 20:15:46.386+00	2	\N
182	2	AY2	4EME	FR	RP	8	2026-03-09 20:15:46.386+00	2026-03-09 20:15:46.386+00	2	\N
183	2	AY2	4EME	FR	R3P	7	2026-03-09 20:15:46.386+00	2026-03-09 20:15:46.386+00	2	\N
184	2	AY2	4EME	NAT	Plein	32	2026-03-09 20:15:46.387+00	2026-03-09 20:15:46.387+00	2	\N
185	2	AY2	4EME	NAT	RP	5	2026-03-09 20:15:46.387+00	2026-03-09 20:15:46.387+00	2	\N
186	2	AY2	4EME	NAT	R3P	4	2026-03-09 20:15:46.388+00	2026-03-09 20:15:46.388+00	2	\N
187	2	AY2	4EME	AUT	Plein	23	2026-03-09 20:15:46.388+00	2026-03-09 20:15:46.388+00	2	\N
188	2	AY2	3EME	FR	Plein	52	2026-03-09 20:15:46.388+00	2026-03-09 20:15:46.388+00	2	\N
189	2	AY2	3EME	FR	RP	8	2026-03-09 20:15:46.389+00	2026-03-09 20:15:46.389+00	2	\N
190	2	AY2	3EME	FR	R3P	7	2026-03-09 20:15:46.389+00	2026-03-09 20:15:46.389+00	2	\N
191	2	AY2	3EME	NAT	Plein	32	2026-03-09 20:15:46.39+00	2026-03-09 20:15:46.39+00	2	\N
192	2	AY2	3EME	NAT	RP	5	2026-03-09 20:15:46.39+00	2026-03-09 20:15:46.39+00	2	\N
193	2	AY2	3EME	NAT	R3P	4	2026-03-09 20:15:46.391+00	2026-03-09 20:15:46.391+00	2	\N
194	2	AY2	3EME	AUT	Plein	24	2026-03-09 20:15:46.391+00	2026-03-09 20:15:46.391+00	2	\N
195	2	AY2	2NDE	FR	Plein	47	2026-03-09 20:15:46.391+00	2026-03-09 20:15:46.391+00	2	\N
196	2	AY2	2NDE	FR	RP	7	2026-03-09 20:15:46.392+00	2026-03-09 20:15:46.392+00	2	\N
197	2	AY2	2NDE	FR	R3P	6	2026-03-09 20:15:46.392+00	2026-03-09 20:15:46.392+00	2	\N
198	2	AY2	2NDE	NAT	Plein	29	2026-03-09 20:15:46.393+00	2026-03-09 20:15:46.393+00	2	\N
199	2	AY2	2NDE	NAT	RP	5	2026-03-09 20:15:46.393+00	2026-03-09 20:15:46.393+00	2	\N
200	2	AY2	2NDE	NAT	R3P	4	2026-03-09 20:15:46.393+00	2026-03-09 20:15:46.393+00	2	\N
201	2	AY2	2NDE	AUT	Plein	21	2026-03-09 20:15:46.394+00	2026-03-09 20:15:46.394+00	2	\N
202	2	AY2	1ERE	FR	Plein	45	2026-03-09 20:15:46.394+00	2026-03-09 20:15:46.394+00	2	\N
203	2	AY2	1ERE	FR	RP	7	2026-03-09 20:15:46.395+00	2026-03-09 20:15:46.395+00	2	\N
204	2	AY2	1ERE	FR	R3P	6	2026-03-09 20:15:46.395+00	2026-03-09 20:15:46.395+00	2	\N
205	2	AY2	1ERE	NAT	Plein	28	2026-03-09 20:15:46.395+00	2026-03-09 20:15:46.395+00	2	\N
206	2	AY2	1ERE	NAT	RP	4	2026-03-09 20:15:46.396+00	2026-03-09 20:15:46.396+00	2	\N
207	2	AY2	1ERE	NAT	R3P	4	2026-03-09 20:15:46.396+00	2026-03-09 20:15:46.396+00	2	\N
208	2	AY2	1ERE	AUT	Plein	20	2026-03-09 20:15:46.397+00	2026-03-09 20:15:46.397+00	2	\N
209	2	AY2	TERM	FR	Plein	31	2026-03-09 20:15:46.397+00	2026-03-09 20:15:46.397+00	2	\N
210	2	AY2	TERM	FR	RP	5	2026-03-09 20:15:46.397+00	2026-03-09 20:15:46.397+00	2	\N
211	2	AY2	TERM	NAT	Plein	19	2026-03-09 20:15:46.398+00	2026-03-09 20:15:46.398+00	2	\N
212	2	AY2	TERM	NAT	RP	3	2026-03-09 20:15:46.398+00	2026-03-09 20:15:46.398+00	2	\N
213	2	AY2	TERM	NAT	R3P	2	2026-03-09 20:15:46.399+00	2026-03-09 20:15:46.399+00	2	\N
214	2	AY2	TERM	AUT	Plein	14	2026-03-09 20:15:46.399+00	2026-03-09 20:15:46.399+00	2	\N
\.


--
-- Data for Name: enrollment_headcount; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.enrollment_headcount (id, version_id, academic_period, grade_level, headcount, created_at, updated_at, created_by, updated_by) FROM stdin;
1	2	AY1	PS	100	2026-03-09 20:15:46.288+00	2026-03-09 20:15:46.288+00	2	\N
2	2	AY1	MS	103	2026-03-09 20:15:46.29+00	2026-03-09 20:15:46.29+00	2	\N
3	2	AY1	GS	106	2026-03-09 20:15:46.291+00	2026-03-09 20:15:46.291+00	2	\N
4	2	AY1	CP	110	2026-03-09 20:15:46.291+00	2026-03-09 20:15:46.291+00	2	\N
5	2	AY1	CE1	113	2026-03-09 20:15:46.292+00	2026-03-09 20:15:46.292+00	2	\N
6	2	AY1	CE2	116	2026-03-09 20:15:46.292+00	2026-03-09 20:15:46.292+00	2	\N
7	2	AY1	CM1	119	2026-03-09 20:15:46.293+00	2026-03-09 20:15:46.293+00	2	\N
8	2	AY1	CM2	122	2026-03-09 20:15:46.293+00	2026-03-09 20:15:46.293+00	2	\N
9	2	AY1	6EME	131	2026-03-09 20:15:46.294+00	2026-03-09 20:15:46.294+00	2	\N
10	2	AY1	5EME	134	2026-03-09 20:15:46.294+00	2026-03-09 20:15:46.294+00	2	\N
11	2	AY1	4EME	137	2026-03-09 20:15:46.295+00	2026-03-09 20:15:46.295+00	2	\N
12	2	AY1	3EME	139	2026-03-09 20:15:46.295+00	2026-03-09 20:15:46.295+00	2	\N
13	2	AY1	2NDE	125	2026-03-09 20:15:46.296+00	2026-03-09 20:15:46.296+00	2	\N
14	2	AY1	1ERE	120	2026-03-09 20:15:46.296+00	2026-03-09 20:15:46.296+00	2	\N
15	2	AY1	TERM	78	2026-03-09 20:15:46.296+00	2026-03-09 20:15:46.296+00	2	\N
16	2	AY2	PS	95	2026-03-09 20:15:46.297+00	2026-03-09 20:15:46.297+00	2	\N
17	2	AY2	MS	98	2026-03-09 20:15:46.297+00	2026-03-09 20:15:46.297+00	2	\N
18	2	AY2	GS	101	2026-03-09 20:15:46.298+00	2026-03-09 20:15:46.298+00	2	\N
19	2	AY2	CP	105	2026-03-09 20:15:46.298+00	2026-03-09 20:15:46.298+00	2	\N
20	2	AY2	CE1	107	2026-03-09 20:15:46.299+00	2026-03-09 20:15:46.299+00	2	\N
21	2	AY2	CE2	110	2026-03-09 20:15:46.299+00	2026-03-09 20:15:46.299+00	2	\N
22	2	AY2	CM1	113	2026-03-09 20:15:46.299+00	2026-03-09 20:15:46.299+00	2	\N
23	2	AY2	CM2	116	2026-03-09 20:15:46.3+00	2026-03-09 20:15:46.3+00	2	\N
24	2	AY2	6EME	124	2026-03-09 20:15:46.3+00	2026-03-09 20:15:46.3+00	2	\N
25	2	AY2	5EME	127	2026-03-09 20:15:46.301+00	2026-03-09 20:15:46.301+00	2	\N
26	2	AY2	4EME	130	2026-03-09 20:15:46.301+00	2026-03-09 20:15:46.301+00	2	\N
27	2	AY2	3EME	132	2026-03-09 20:15:46.302+00	2026-03-09 20:15:46.302+00	2	\N
28	2	AY2	2NDE	119	2026-03-09 20:15:46.302+00	2026-03-09 20:15:46.302+00	2	\N
29	2	AY2	1ERE	114	2026-03-09 20:15:46.303+00	2026-03-09 20:15:46.303+00	2	\N
30	2	AY2	TERM	74	2026-03-09 20:15:46.303+00	2026-03-09 20:15:46.303+00	2	\N
31	3	AY1	PS	77	2026-03-09 20:15:46.605+00	2026-03-09 20:15:46.605+00	2	\N
32	3	AY1	MS	82	2026-03-09 20:15:46.605+00	2026-03-09 20:15:46.605+00	2	\N
33	3	AY1	GS	85	2026-03-09 20:15:46.606+00	2026-03-09 20:15:46.606+00	2	\N
34	3	AY1	CP	89	2026-03-09 20:15:46.606+00	2026-03-09 20:15:46.606+00	2	\N
35	3	AY1	CE1	90	2026-03-09 20:15:46.607+00	2026-03-09 20:15:46.607+00	2	\N
36	3	AY1	CE2	92	2026-03-09 20:15:46.607+00	2026-03-09 20:15:46.607+00	2	\N
37	3	AY1	CM1	95	2026-03-09 20:15:46.608+00	2026-03-09 20:15:46.608+00	2	\N
38	3	AY1	CM2	98	2026-03-09 20:15:46.608+00	2026-03-09 20:15:46.608+00	2	\N
39	3	AY1	6EME	105	2026-03-09 20:15:46.609+00	2026-03-09 20:15:46.609+00	2	\N
40	3	AY1	5EME	108	2026-03-09 20:15:46.609+00	2026-03-09 20:15:46.609+00	2	\N
41	3	AY1	4EME	110	2026-03-09 20:15:46.61+00	2026-03-09 20:15:46.61+00	2	\N
42	3	AY1	3EME	112	2026-03-09 20:15:46.61+00	2026-03-09 20:15:46.61+00	2	\N
43	3	AY1	2NDE	100	2026-03-09 20:15:46.611+00	2026-03-09 20:15:46.611+00	2	\N
44	3	AY1	1ERE	98	2026-03-09 20:15:46.611+00	2026-03-09 20:15:46.611+00	2	\N
45	3	AY1	TERM	93	2026-03-09 20:15:46.612+00	2026-03-09 20:15:46.612+00	2	\N
46	4	AY1	PS	81	2026-03-09 20:15:46.612+00	2026-03-09 20:15:46.612+00	2	\N
47	4	AY1	MS	85	2026-03-09 20:15:46.612+00	2026-03-09 20:15:46.612+00	2	\N
48	4	AY1	GS	88	2026-03-09 20:15:46.613+00	2026-03-09 20:15:46.613+00	2	\N
49	4	AY1	CP	93	2026-03-09 20:15:46.613+00	2026-03-09 20:15:46.613+00	2	\N
50	4	AY1	CE1	94	2026-03-09 20:15:46.614+00	2026-03-09 20:15:46.614+00	2	\N
51	4	AY1	CE2	96	2026-03-09 20:15:46.614+00	2026-03-09 20:15:46.614+00	2	\N
52	4	AY1	CM1	99	2026-03-09 20:15:46.615+00	2026-03-09 20:15:46.615+00	2	\N
53	4	AY1	CM2	102	2026-03-09 20:15:46.615+00	2026-03-09 20:15:46.615+00	2	\N
54	4	AY1	6EME	109	2026-03-09 20:15:46.615+00	2026-03-09 20:15:46.615+00	2	\N
55	4	AY1	5EME	112	2026-03-09 20:15:46.616+00	2026-03-09 20:15:46.616+00	2	\N
56	4	AY1	4EME	115	2026-03-09 20:15:46.616+00	2026-03-09 20:15:46.616+00	2	\N
57	4	AY1	3EME	117	2026-03-09 20:15:46.617+00	2026-03-09 20:15:46.617+00	2	\N
58	4	AY1	2NDE	105	2026-03-09 20:15:46.617+00	2026-03-09 20:15:46.617+00	2	\N
59	4	AY1	1ERE	102	2026-03-09 20:15:46.617+00	2026-03-09 20:15:46.617+00	2	\N
60	4	AY1	TERM	101	2026-03-09 20:15:46.618+00	2026-03-09 20:15:46.618+00	2	\N
61	5	AY1	PS	86	2026-03-09 20:15:46.618+00	2026-03-09 20:15:46.618+00	2	\N
62	5	AY1	MS	90	2026-03-09 20:15:46.619+00	2026-03-09 20:15:46.619+00	2	\N
63	5	AY1	GS	94	2026-03-09 20:15:46.619+00	2026-03-09 20:15:46.619+00	2	\N
64	5	AY1	CP	98	2026-03-09 20:15:46.62+00	2026-03-09 20:15:46.62+00	2	\N
65	5	AY1	CE1	100	2026-03-09 20:15:46.62+00	2026-03-09 20:15:46.62+00	2	\N
66	5	AY1	CE2	102	2026-03-09 20:15:46.621+00	2026-03-09 20:15:46.621+00	2	\N
67	5	AY1	CM1	105	2026-03-09 20:15:46.621+00	2026-03-09 20:15:46.621+00	2	\N
68	5	AY1	CM2	108	2026-03-09 20:15:46.621+00	2026-03-09 20:15:46.621+00	2	\N
69	5	AY1	6EME	116	2026-03-09 20:15:46.622+00	2026-03-09 20:15:46.622+00	2	\N
70	5	AY1	5EME	119	2026-03-09 20:15:46.622+00	2026-03-09 20:15:46.622+00	2	\N
71	5	AY1	4EME	122	2026-03-09 20:15:46.623+00	2026-03-09 20:15:46.623+00	2	\N
72	5	AY1	3EME	124	2026-03-09 20:15:46.623+00	2026-03-09 20:15:46.623+00	2	\N
73	5	AY1	2NDE	111	2026-03-09 20:15:46.624+00	2026-03-09 20:15:46.624+00	2	\N
74	5	AY1	1ERE	108	2026-03-09 20:15:46.624+00	2026-03-09 20:15:46.624+00	2	\N
75	5	AY1	TERM	104	2026-03-09 20:15:46.625+00	2026-03-09 20:15:46.625+00	2	\N
76	6	AY1	PS	97	2026-03-09 20:15:46.625+00	2026-03-09 20:15:46.625+00	2	\N
77	6	AY1	MS	102	2026-03-09 20:15:46.626+00	2026-03-09 20:15:46.626+00	2	\N
78	6	AY1	GS	106	2026-03-09 20:15:46.626+00	2026-03-09 20:15:46.626+00	2	\N
79	6	AY1	CP	111	2026-03-09 20:15:46.627+00	2026-03-09 20:15:46.627+00	2	\N
80	6	AY1	CE1	113	2026-03-09 20:15:46.627+00	2026-03-09 20:15:46.627+00	2	\N
81	6	AY1	CE2	115	2026-03-09 20:15:46.628+00	2026-03-09 20:15:46.628+00	2	\N
82	6	AY1	CM1	118	2026-03-09 20:15:46.628+00	2026-03-09 20:15:46.628+00	2	\N
83	6	AY1	CM2	122	2026-03-09 20:15:46.629+00	2026-03-09 20:15:46.629+00	2	\N
84	6	AY1	6EME	131	2026-03-09 20:15:46.629+00	2026-03-09 20:15:46.629+00	2	\N
85	6	AY1	5EME	135	2026-03-09 20:15:46.629+00	2026-03-09 20:15:46.629+00	2	\N
86	6	AY1	4EME	138	2026-03-09 20:15:46.63+00	2026-03-09 20:15:46.63+00	2	\N
87	6	AY1	3EME	140	2026-03-09 20:15:46.63+00	2026-03-09 20:15:46.63+00	2	\N
88	6	AY1	2NDE	126	2026-03-09 20:15:46.631+00	2026-03-09 20:15:46.631+00	2	\N
89	6	AY1	1ERE	122	2026-03-09 20:15:46.631+00	2026-03-09 20:15:46.631+00	2	\N
90	6	AY1	TERM	118	2026-03-09 20:15:46.632+00	2026-03-09 20:15:46.632+00	2	\N
91	7	AY1	PS	94	2026-03-09 20:15:46.632+00	2026-03-09 20:15:46.632+00	2	\N
92	7	AY1	MS	100	2026-03-09 20:15:46.632+00	2026-03-09 20:15:46.632+00	2	\N
93	7	AY1	GS	103	2026-03-09 20:15:46.633+00	2026-03-09 20:15:46.633+00	2	\N
94	7	AY1	CP	108	2026-03-09 20:15:46.633+00	2026-03-09 20:15:46.633+00	2	\N
95	7	AY1	CE1	110	2026-03-09 20:15:46.634+00	2026-03-09 20:15:46.634+00	2	\N
96	7	AY1	CE2	112	2026-03-09 20:15:46.634+00	2026-03-09 20:15:46.634+00	2	\N
97	7	AY1	CM1	115	2026-03-09 20:15:46.635+00	2026-03-09 20:15:46.635+00	2	\N
98	7	AY1	CM2	119	2026-03-09 20:15:46.635+00	2026-03-09 20:15:46.635+00	2	\N
99	7	AY1	6EME	128	2026-03-09 20:15:46.636+00	2026-03-09 20:15:46.636+00	2	\N
100	7	AY1	5EME	131	2026-03-09 20:15:46.636+00	2026-03-09 20:15:46.636+00	2	\N
101	7	AY1	4EME	135	2026-03-09 20:15:46.637+00	2026-03-09 20:15:46.637+00	2	\N
102	7	AY1	3EME	136	2026-03-09 20:15:46.637+00	2026-03-09 20:15:46.637+00	2	\N
103	7	AY1	2NDE	122	2026-03-09 20:15:46.638+00	2026-03-09 20:15:46.638+00	2	\N
104	7	AY1	1ERE	119	2026-03-09 20:15:46.638+00	2026-03-09 20:15:46.638+00	2	\N
105	7	AY1	TERM	115	2026-03-09 20:15:46.638+00	2026-03-09 20:15:46.638+00	2	\N
\.


--
-- Data for Name: eos_provisions; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.eos_provisions (id, version_id, employee_id, years_of_service, eos_base, eos_annual, eos_monthly_accrual, as_of_date, calculated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fee_grids; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.fee_grids (id, version_id, academic_period, grade_level, nationality, tariff, dai, tuition_ttc, tuition_ht, term1_amount, term2_amount, term3_amount, created_at, updated_at, created_by, updated_by) FROM stdin;
1	2	AY1	PS	FR	Plein	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.4+00	2026-03-09 20:15:46.4+00	2	\N
2	2	AY1	PS	FR	RP	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.401+00	2026-03-09 20:15:46.401+00	2	\N
3	2	AY1	PS	FR	R3P	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.402+00	2026-03-09 20:15:46.402+00	2	\N
4	2	AY1	PS	NAT	Plein	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.402+00	2026-03-09 20:15:46.402+00	2	\N
5	2	AY1	PS	NAT	RP	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.403+00	2026-03-09 20:15:46.403+00	2	\N
6	2	AY1	PS	NAT	R3P	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.403+00	2026-03-09 20:15:46.403+00	2	\N
7	2	AY1	PS	AUT	Plein	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.404+00	2026-03-09 20:15:46.404+00	2	\N
8	2	AY1	PS	AUT	RP	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.405+00	2026-03-09 20:15:46.405+00	2	\N
9	2	AY1	PS	AUT	R3P	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.405+00	2026-03-09 20:15:46.405+00	2	\N
10	2	AY1	MS	FR	Plein	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.406+00	2026-03-09 20:15:46.406+00	2	\N
11	2	AY1	MS	FR	RP	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.406+00	2026-03-09 20:15:46.406+00	2	\N
12	2	AY1	MS	FR	R3P	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.406+00	2026-03-09 20:15:46.406+00	2	\N
13	2	AY1	MS	NAT	Plein	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.407+00	2026-03-09 20:15:46.407+00	2	\N
14	2	AY1	MS	NAT	RP	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.407+00	2026-03-09 20:15:46.407+00	2	\N
15	2	AY1	MS	NAT	R3P	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.408+00	2026-03-09 20:15:46.408+00	2	\N
16	2	AY1	MS	AUT	Plein	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.408+00	2026-03-09 20:15:46.408+00	2	\N
17	2	AY1	MS	AUT	RP	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.409+00	2026-03-09 20:15:46.409+00	2	\N
18	2	AY1	MS	AUT	R3P	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.41+00	2026-03-09 20:15:46.41+00	2	\N
19	2	AY1	GS	FR	Plein	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.41+00	2026-03-09 20:15:46.41+00	2	\N
20	2	AY1	GS	FR	RP	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.411+00	2026-03-09 20:15:46.411+00	2	\N
21	2	AY1	GS	FR	R3P	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.411+00	2026-03-09 20:15:46.411+00	2	\N
22	2	AY1	GS	NAT	Plein	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.412+00	2026-03-09 20:15:46.412+00	2	\N
23	2	AY1	GS	NAT	RP	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.412+00	2026-03-09 20:15:46.412+00	2	\N
24	2	AY1	GS	NAT	R3P	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.413+00	2026-03-09 20:15:46.413+00	2	\N
25	2	AY1	GS	AUT	Plein	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.413+00	2026-03-09 20:15:46.413+00	2	\N
26	2	AY1	GS	AUT	RP	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.413+00	2026-03-09 20:15:46.413+00	2	\N
27	2	AY1	GS	AUT	R3P	1200.0000	22080.0000	19200.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.414+00	2026-03-09 20:15:46.414+00	2	\N
28	2	AY1	CP	FR	Plein	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.414+00	2026-03-09 20:15:46.414+00	2	\N
29	2	AY1	CP	FR	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.415+00	2026-03-09 20:15:46.415+00	2	\N
30	2	AY1	CP	FR	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.415+00	2026-03-09 20:15:46.415+00	2	\N
31	2	AY1	CP	NAT	Plein	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.416+00	2026-03-09 20:15:46.416+00	2	\N
32	2	AY1	CP	NAT	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.417+00	2026-03-09 20:15:46.417+00	2	\N
33	2	AY1	CP	NAT	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.417+00	2026-03-09 20:15:46.417+00	2	\N
34	2	AY1	CP	AUT	Plein	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.417+00	2026-03-09 20:15:46.417+00	2	\N
35	2	AY1	CP	AUT	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.418+00	2026-03-09 20:15:46.418+00	2	\N
36	2	AY1	CP	AUT	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.418+00	2026-03-09 20:15:46.418+00	2	\N
37	2	AY1	CE1	FR	Plein	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.419+00	2026-03-09 20:15:46.419+00	2	\N
38	2	AY1	CE1	FR	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.419+00	2026-03-09 20:15:46.419+00	2	\N
39	2	AY1	CE1	FR	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.42+00	2026-03-09 20:15:46.42+00	2	\N
40	2	AY1	CE1	NAT	Plein	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.42+00	2026-03-09 20:15:46.42+00	2	\N
41	2	AY1	CE1	NAT	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.421+00	2026-03-09 20:15:46.421+00	2	\N
42	2	AY1	CE1	NAT	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.421+00	2026-03-09 20:15:46.421+00	2	\N
43	2	AY1	CE1	AUT	Plein	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.422+00	2026-03-09 20:15:46.422+00	2	\N
44	2	AY1	CE1	AUT	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.423+00	2026-03-09 20:15:46.423+00	2	\N
45	2	AY1	CE1	AUT	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.423+00	2026-03-09 20:15:46.423+00	2	\N
46	2	AY1	CE2	FR	Plein	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.424+00	2026-03-09 20:15:46.424+00	2	\N
47	2	AY1	CE2	FR	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.424+00	2026-03-09 20:15:46.424+00	2	\N
48	2	AY1	CE2	FR	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.424+00	2026-03-09 20:15:46.424+00	2	\N
49	2	AY1	CE2	NAT	Plein	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.425+00	2026-03-09 20:15:46.425+00	2	\N
50	2	AY1	CE2	NAT	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.425+00	2026-03-09 20:15:46.425+00	2	\N
51	2	AY1	CE2	NAT	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.426+00	2026-03-09 20:15:46.426+00	2	\N
52	2	AY1	CE2	AUT	Plein	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.426+00	2026-03-09 20:15:46.426+00	2	\N
53	2	AY1	CE2	AUT	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.427+00	2026-03-09 20:15:46.427+00	2	\N
54	2	AY1	CE2	AUT	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.427+00	2026-03-09 20:15:46.427+00	2	\N
55	2	AY1	CM1	FR	Plein	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.428+00	2026-03-09 20:15:46.428+00	2	\N
56	2	AY1	CM1	FR	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.428+00	2026-03-09 20:15:46.428+00	2	\N
57	2	AY1	CM1	FR	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.429+00	2026-03-09 20:15:46.429+00	2	\N
58	2	AY1	CM1	NAT	Plein	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.429+00	2026-03-09 20:15:46.429+00	2	\N
59	2	AY1	CM1	NAT	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.43+00	2026-03-09 20:15:46.43+00	2	\N
60	2	AY1	CM1	NAT	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.43+00	2026-03-09 20:15:46.43+00	2	\N
61	2	AY1	CM1	AUT	Plein	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.431+00	2026-03-09 20:15:46.431+00	2	\N
62	2	AY1	CM1	AUT	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.431+00	2026-03-09 20:15:46.431+00	2	\N
63	2	AY1	CM1	AUT	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.432+00	2026-03-09 20:15:46.432+00	2	\N
64	2	AY1	CM2	FR	Plein	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.432+00	2026-03-09 20:15:46.432+00	2	\N
65	2	AY1	CM2	FR	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.433+00	2026-03-09 20:15:46.433+00	2	\N
66	2	AY1	CM2	FR	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.433+00	2026-03-09 20:15:46.433+00	2	\N
67	2	AY1	CM2	NAT	Plein	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.434+00	2026-03-09 20:15:46.434+00	2	\N
68	2	AY1	CM2	NAT	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.434+00	2026-03-09 20:15:46.434+00	2	\N
69	2	AY1	CM2	NAT	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.435+00	2026-03-09 20:15:46.435+00	2	\N
70	2	AY1	CM2	AUT	Plein	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.435+00	2026-03-09 20:15:46.435+00	2	\N
71	2	AY1	CM2	AUT	RP	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.435+00	2026-03-09 20:15:46.435+00	2	\N
72	2	AY1	CM2	AUT	R3P	1320.0000	24150.0000	21000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.436+00	2026-03-09 20:15:46.436+00	2	\N
73	2	AY1	6EME	FR	Plein	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.437+00	2026-03-09 20:15:46.437+00	2	\N
74	2	AY1	6EME	FR	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.437+00	2026-03-09 20:15:46.437+00	2	\N
75	2	AY1	6EME	FR	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.438+00	2026-03-09 20:15:46.438+00	2	\N
76	2	AY1	6EME	NAT	Plein	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.438+00	2026-03-09 20:15:46.438+00	2	\N
77	2	AY1	6EME	NAT	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.439+00	2026-03-09 20:15:46.439+00	2	\N
78	2	AY1	6EME	NAT	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.439+00	2026-03-09 20:15:46.439+00	2	\N
79	2	AY1	6EME	AUT	Plein	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.439+00	2026-03-09 20:15:46.439+00	2	\N
80	2	AY1	6EME	AUT	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.44+00	2026-03-09 20:15:46.44+00	2	\N
81	2	AY1	6EME	AUT	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.44+00	2026-03-09 20:15:46.44+00	2	\N
82	2	AY1	5EME	FR	Plein	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.441+00	2026-03-09 20:15:46.441+00	2	\N
83	2	AY1	5EME	FR	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.442+00	2026-03-09 20:15:46.442+00	2	\N
84	2	AY1	5EME	FR	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.442+00	2026-03-09 20:15:46.442+00	2	\N
85	2	AY1	5EME	NAT	Plein	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.443+00	2026-03-09 20:15:46.443+00	2	\N
86	2	AY1	5EME	NAT	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.443+00	2026-03-09 20:15:46.443+00	2	\N
87	2	AY1	5EME	NAT	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.444+00	2026-03-09 20:15:46.444+00	2	\N
88	2	AY1	5EME	AUT	Plein	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.444+00	2026-03-09 20:15:46.444+00	2	\N
89	2	AY1	5EME	AUT	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.445+00	2026-03-09 20:15:46.445+00	2	\N
90	2	AY1	5EME	AUT	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.445+00	2026-03-09 20:15:46.445+00	2	\N
91	2	AY1	4EME	FR	Plein	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.446+00	2026-03-09 20:15:46.446+00	2	\N
92	2	AY1	4EME	FR	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.446+00	2026-03-09 20:15:46.446+00	2	\N
93	2	AY1	4EME	FR	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.446+00	2026-03-09 20:15:46.446+00	2	\N
94	2	AY1	4EME	NAT	Plein	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.447+00	2026-03-09 20:15:46.447+00	2	\N
95	2	AY1	4EME	NAT	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.448+00	2026-03-09 20:15:46.448+00	2	\N
96	2	AY1	4EME	NAT	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.449+00	2026-03-09 20:15:46.449+00	2	\N
97	2	AY1	4EME	AUT	Plein	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.449+00	2026-03-09 20:15:46.449+00	2	\N
98	2	AY1	4EME	AUT	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.45+00	2026-03-09 20:15:46.45+00	2	\N
99	2	AY1	4EME	AUT	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.45+00	2026-03-09 20:15:46.45+00	2	\N
100	2	AY1	3EME	FR	Plein	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.45+00	2026-03-09 20:15:46.45+00	2	\N
101	2	AY1	3EME	FR	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.451+00	2026-03-09 20:15:46.451+00	2	\N
102	2	AY1	3EME	FR	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.451+00	2026-03-09 20:15:46.451+00	2	\N
103	2	AY1	3EME	NAT	Plein	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.452+00	2026-03-09 20:15:46.452+00	2	\N
104	2	AY1	3EME	NAT	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.452+00	2026-03-09 20:15:46.452+00	2	\N
105	2	AY1	3EME	NAT	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.453+00	2026-03-09 20:15:46.453+00	2	\N
106	2	AY1	3EME	AUT	Plein	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.453+00	2026-03-09 20:15:46.453+00	2	\N
107	2	AY1	3EME	AUT	RP	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.454+00	2026-03-09 20:15:46.454+00	2	\N
108	2	AY1	3EME	AUT	R3P	1500.0000	27600.0000	24000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.454+00	2026-03-09 20:15:46.454+00	2	\N
109	2	AY1	2NDE	FR	Plein	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.455+00	2026-03-09 20:15:46.455+00	2	\N
110	2	AY1	2NDE	FR	RP	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.455+00	2026-03-09 20:15:46.455+00	2	\N
111	2	AY1	2NDE	FR	R3P	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.456+00	2026-03-09 20:15:46.456+00	2	\N
112	2	AY1	2NDE	NAT	Plein	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.456+00	2026-03-09 20:15:46.456+00	2	\N
113	2	AY1	2NDE	NAT	RP	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.457+00	2026-03-09 20:15:46.457+00	2	\N
114	2	AY1	2NDE	NAT	R3P	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.457+00	2026-03-09 20:15:46.457+00	2	\N
115	2	AY1	2NDE	AUT	Plein	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.458+00	2026-03-09 20:15:46.458+00	2	\N
116	2	AY1	2NDE	AUT	RP	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.458+00	2026-03-09 20:15:46.458+00	2	\N
117	2	AY1	2NDE	AUT	R3P	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.459+00	2026-03-09 20:15:46.459+00	2	\N
118	2	AY1	1ERE	FR	Plein	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.459+00	2026-03-09 20:15:46.459+00	2	\N
119	2	AY1	1ERE	FR	RP	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.459+00	2026-03-09 20:15:46.459+00	2	\N
120	2	AY1	1ERE	FR	R3P	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.46+00	2026-03-09 20:15:46.46+00	2	\N
121	2	AY1	1ERE	NAT	Plein	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.46+00	2026-03-09 20:15:46.46+00	2	\N
122	2	AY1	1ERE	NAT	RP	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.461+00	2026-03-09 20:15:46.461+00	2	\N
123	2	AY1	1ERE	NAT	R3P	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.461+00	2026-03-09 20:15:46.461+00	2	\N
124	2	AY1	1ERE	AUT	Plein	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.462+00	2026-03-09 20:15:46.462+00	2	\N
125	2	AY1	1ERE	AUT	RP	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.462+00	2026-03-09 20:15:46.462+00	2	\N
126	2	AY1	1ERE	AUT	R3P	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.463+00	2026-03-09 20:15:46.463+00	2	\N
127	2	AY1	TERM	FR	Plein	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.463+00	2026-03-09 20:15:46.463+00	2	\N
128	2	AY1	TERM	FR	RP	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.464+00	2026-03-09 20:15:46.464+00	2	\N
129	2	AY1	TERM	FR	R3P	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.464+00	2026-03-09 20:15:46.464+00	2	\N
130	2	AY1	TERM	NAT	Plein	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.465+00	2026-03-09 20:15:46.465+00	2	\N
131	2	AY1	TERM	NAT	RP	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.465+00	2026-03-09 20:15:46.465+00	2	\N
132	2	AY1	TERM	NAT	R3P	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.466+00	2026-03-09 20:15:46.466+00	2	\N
133	2	AY1	TERM	AUT	Plein	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.466+00	2026-03-09 20:15:46.466+00	2	\N
134	2	AY1	TERM	AUT	RP	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.467+00	2026-03-09 20:15:46.467+00	2	\N
135	2	AY1	TERM	AUT	R3P	1680.0000	31050.0000	27000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.467+00	2026-03-09 20:15:46.467+00	2	\N
136	2	AY2	PS	FR	Plein	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.468+00	2026-03-09 20:15:46.468+00	2	\N
137	2	AY2	PS	FR	RP	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.468+00	2026-03-09 20:15:46.468+00	2	\N
138	2	AY2	PS	FR	R3P	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.468+00	2026-03-09 20:15:46.468+00	2	\N
139	2	AY2	PS	NAT	Plein	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.469+00	2026-03-09 20:15:46.469+00	2	\N
140	2	AY2	PS	NAT	RP	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.469+00	2026-03-09 20:15:46.469+00	2	\N
141	2	AY2	PS	NAT	R3P	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.47+00	2026-03-09 20:15:46.47+00	2	\N
142	2	AY2	PS	AUT	Plein	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.47+00	2026-03-09 20:15:46.47+00	2	\N
143	2	AY2	PS	AUT	RP	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.471+00	2026-03-09 20:15:46.471+00	2	\N
144	2	AY2	PS	AUT	R3P	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.471+00	2026-03-09 20:15:46.471+00	2	\N
145	2	AY2	MS	FR	Plein	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.472+00	2026-03-09 20:15:46.472+00	2	\N
146	2	AY2	MS	FR	RP	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.472+00	2026-03-09 20:15:46.472+00	2	\N
147	2	AY2	MS	FR	R3P	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.473+00	2026-03-09 20:15:46.473+00	2	\N
148	2	AY2	MS	NAT	Plein	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.473+00	2026-03-09 20:15:46.473+00	2	\N
149	2	AY2	MS	NAT	RP	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.474+00	2026-03-09 20:15:46.474+00	2	\N
150	2	AY2	MS	NAT	R3P	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.474+00	2026-03-09 20:15:46.474+00	2	\N
151	2	AY2	MS	AUT	Plein	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.475+00	2026-03-09 20:15:46.475+00	2	\N
152	2	AY2	MS	AUT	RP	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.475+00	2026-03-09 20:15:46.475+00	2	\N
153	2	AY2	MS	AUT	R3P	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.476+00	2026-03-09 20:15:46.476+00	2	\N
154	2	AY2	GS	FR	Plein	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.476+00	2026-03-09 20:15:46.476+00	2	\N
155	2	AY2	GS	FR	RP	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.477+00	2026-03-09 20:15:46.477+00	2	\N
156	2	AY2	GS	FR	R3P	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.477+00	2026-03-09 20:15:46.477+00	2	\N
157	2	AY2	GS	NAT	Plein	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.477+00	2026-03-09 20:15:46.477+00	2	\N
158	2	AY2	GS	NAT	RP	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.478+00	2026-03-09 20:15:46.478+00	2	\N
159	2	AY2	GS	NAT	R3P	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.479+00	2026-03-09 20:15:46.479+00	2	\N
160	2	AY2	GS	AUT	Plein	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.479+00	2026-03-09 20:15:46.479+00	2	\N
161	2	AY2	GS	AUT	RP	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.479+00	2026-03-09 20:15:46.479+00	2	\N
162	2	AY2	GS	AUT	R3P	800.0000	14720.0000	12800.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.48+00	2026-03-09 20:15:46.48+00	2	\N
163	2	AY2	CP	FR	Plein	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.48+00	2026-03-09 20:15:46.48+00	2	\N
164	2	AY2	CP	FR	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.481+00	2026-03-09 20:15:46.481+00	2	\N
165	2	AY2	CP	FR	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.481+00	2026-03-09 20:15:46.481+00	2	\N
166	2	AY2	CP	NAT	Plein	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.482+00	2026-03-09 20:15:46.482+00	2	\N
167	2	AY2	CP	NAT	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.482+00	2026-03-09 20:15:46.482+00	2	\N
168	2	AY2	CP	NAT	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.483+00	2026-03-09 20:15:46.483+00	2	\N
169	2	AY2	CP	AUT	Plein	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.483+00	2026-03-09 20:15:46.483+00	2	\N
170	2	AY2	CP	AUT	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.484+00	2026-03-09 20:15:46.484+00	2	\N
171	2	AY2	CP	AUT	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.484+00	2026-03-09 20:15:46.484+00	2	\N
172	2	AY2	CE1	FR	Plein	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.485+00	2026-03-09 20:15:46.485+00	2	\N
173	2	AY2	CE1	FR	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.486+00	2026-03-09 20:15:46.486+00	2	\N
174	2	AY2	CE1	FR	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.486+00	2026-03-09 20:15:46.486+00	2	\N
175	2	AY2	CE1	NAT	Plein	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.486+00	2026-03-09 20:15:46.486+00	2	\N
176	2	AY2	CE1	NAT	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.487+00	2026-03-09 20:15:46.487+00	2	\N
177	2	AY2	CE1	NAT	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.487+00	2026-03-09 20:15:46.487+00	2	\N
178	2	AY2	CE1	AUT	Plein	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.488+00	2026-03-09 20:15:46.488+00	2	\N
179	2	AY2	CE1	AUT	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.488+00	2026-03-09 20:15:46.488+00	2	\N
180	2	AY2	CE1	AUT	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.489+00	2026-03-09 20:15:46.489+00	2	\N
181	2	AY2	CE2	FR	Plein	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.489+00	2026-03-09 20:15:46.489+00	2	\N
182	2	AY2	CE2	FR	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.49+00	2026-03-09 20:15:46.49+00	2	\N
183	2	AY2	CE2	FR	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.49+00	2026-03-09 20:15:46.49+00	2	\N
184	2	AY2	CE2	NAT	Plein	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.491+00	2026-03-09 20:15:46.491+00	2	\N
185	2	AY2	CE2	NAT	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.491+00	2026-03-09 20:15:46.491+00	2	\N
186	2	AY2	CE2	NAT	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.492+00	2026-03-09 20:15:46.492+00	2	\N
187	2	AY2	CE2	AUT	Plein	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.492+00	2026-03-09 20:15:46.492+00	2	\N
188	2	AY2	CE2	AUT	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.493+00	2026-03-09 20:15:46.493+00	2	\N
189	2	AY2	CE2	AUT	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.493+00	2026-03-09 20:15:46.493+00	2	\N
190	2	AY2	CM1	FR	Plein	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.493+00	2026-03-09 20:15:46.493+00	2	\N
191	2	AY2	CM1	FR	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.494+00	2026-03-09 20:15:46.494+00	2	\N
192	2	AY2	CM1	FR	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.494+00	2026-03-09 20:15:46.494+00	2	\N
193	2	AY2	CM1	NAT	Plein	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.495+00	2026-03-09 20:15:46.495+00	2	\N
194	2	AY2	CM1	NAT	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.495+00	2026-03-09 20:15:46.495+00	2	\N
195	2	AY2	CM1	NAT	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.496+00	2026-03-09 20:15:46.496+00	2	\N
196	2	AY2	CM1	AUT	Plein	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.496+00	2026-03-09 20:15:46.496+00	2	\N
197	2	AY2	CM1	AUT	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.497+00	2026-03-09 20:15:46.497+00	2	\N
198	2	AY2	CM1	AUT	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.497+00	2026-03-09 20:15:46.497+00	2	\N
199	2	AY2	CM2	FR	Plein	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.498+00	2026-03-09 20:15:46.498+00	2	\N
200	2	AY2	CM2	FR	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.498+00	2026-03-09 20:15:46.498+00	2	\N
201	2	AY2	CM2	FR	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.498+00	2026-03-09 20:15:46.498+00	2	\N
202	2	AY2	CM2	NAT	Plein	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.499+00	2026-03-09 20:15:46.499+00	2	\N
203	2	AY2	CM2	NAT	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.499+00	2026-03-09 20:15:46.499+00	2	\N
204	2	AY2	CM2	NAT	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.5+00	2026-03-09 20:15:46.5+00	2	\N
205	2	AY2	CM2	AUT	Plein	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.5+00	2026-03-09 20:15:46.5+00	2	\N
206	2	AY2	CM2	AUT	RP	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.501+00	2026-03-09 20:15:46.501+00	2	\N
207	2	AY2	CM2	AUT	R3P	880.0000	16100.0000	14000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.501+00	2026-03-09 20:15:46.501+00	2	\N
208	2	AY2	6EME	FR	Plein	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.502+00	2026-03-09 20:15:46.502+00	2	\N
209	2	AY2	6EME	FR	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.502+00	2026-03-09 20:15:46.502+00	2	\N
210	2	AY2	6EME	FR	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.503+00	2026-03-09 20:15:46.503+00	2	\N
211	2	AY2	6EME	NAT	Plein	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.503+00	2026-03-09 20:15:46.503+00	2	\N
212	2	AY2	6EME	NAT	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.504+00	2026-03-09 20:15:46.504+00	2	\N
213	2	AY2	6EME	NAT	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.505+00	2026-03-09 20:15:46.505+00	2	\N
214	2	AY2	6EME	AUT	Plein	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.505+00	2026-03-09 20:15:46.505+00	2	\N
215	2	AY2	6EME	AUT	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.506+00	2026-03-09 20:15:46.506+00	2	\N
216	2	AY2	6EME	AUT	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.506+00	2026-03-09 20:15:46.506+00	2	\N
217	2	AY2	5EME	FR	Plein	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.507+00	2026-03-09 20:15:46.507+00	2	\N
218	2	AY2	5EME	FR	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.507+00	2026-03-09 20:15:46.507+00	2	\N
219	2	AY2	5EME	FR	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.508+00	2026-03-09 20:15:46.508+00	2	\N
220	2	AY2	5EME	NAT	Plein	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.508+00	2026-03-09 20:15:46.508+00	2	\N
221	2	AY2	5EME	NAT	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.509+00	2026-03-09 20:15:46.509+00	2	\N
222	2	AY2	5EME	NAT	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.51+00	2026-03-09 20:15:46.51+00	2	\N
223	2	AY2	5EME	AUT	Plein	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.51+00	2026-03-09 20:15:46.51+00	2	\N
224	2	AY2	5EME	AUT	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.511+00	2026-03-09 20:15:46.511+00	2	\N
225	2	AY2	5EME	AUT	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.511+00	2026-03-09 20:15:46.511+00	2	\N
226	2	AY2	4EME	FR	Plein	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.512+00	2026-03-09 20:15:46.512+00	2	\N
227	2	AY2	4EME	FR	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.512+00	2026-03-09 20:15:46.512+00	2	\N
228	2	AY2	4EME	FR	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.513+00	2026-03-09 20:15:46.513+00	2	\N
229	2	AY2	4EME	NAT	Plein	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.513+00	2026-03-09 20:15:46.513+00	2	\N
230	2	AY2	4EME	NAT	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.514+00	2026-03-09 20:15:46.514+00	2	\N
231	2	AY2	4EME	NAT	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.515+00	2026-03-09 20:15:46.515+00	2	\N
232	2	AY2	4EME	AUT	Plein	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.515+00	2026-03-09 20:15:46.515+00	2	\N
233	2	AY2	4EME	AUT	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.516+00	2026-03-09 20:15:46.516+00	2	\N
234	2	AY2	4EME	AUT	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.517+00	2026-03-09 20:15:46.517+00	2	\N
235	2	AY2	3EME	FR	Plein	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.517+00	2026-03-09 20:15:46.517+00	2	\N
236	2	AY2	3EME	FR	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.518+00	2026-03-09 20:15:46.518+00	2	\N
237	2	AY2	3EME	FR	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.518+00	2026-03-09 20:15:46.518+00	2	\N
238	2	AY2	3EME	NAT	Plein	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.519+00	2026-03-09 20:15:46.519+00	2	\N
239	2	AY2	3EME	NAT	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.519+00	2026-03-09 20:15:46.519+00	2	\N
240	2	AY2	3EME	NAT	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.52+00	2026-03-09 20:15:46.52+00	2	\N
241	2	AY2	3EME	AUT	Plein	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.52+00	2026-03-09 20:15:46.52+00	2	\N
242	2	AY2	3EME	AUT	RP	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.52+00	2026-03-09 20:15:46.52+00	2	\N
243	2	AY2	3EME	AUT	R3P	1000.0000	18400.0000	16000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.521+00	2026-03-09 20:15:46.521+00	2	\N
244	2	AY2	2NDE	FR	Plein	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.521+00	2026-03-09 20:15:46.521+00	2	\N
245	2	AY2	2NDE	FR	RP	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.522+00	2026-03-09 20:15:46.522+00	2	\N
246	2	AY2	2NDE	FR	R3P	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.522+00	2026-03-09 20:15:46.522+00	2	\N
247	2	AY2	2NDE	NAT	Plein	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.523+00	2026-03-09 20:15:46.523+00	2	\N
248	2	AY2	2NDE	NAT	RP	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.523+00	2026-03-09 20:15:46.523+00	2	\N
249	2	AY2	2NDE	NAT	R3P	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.524+00	2026-03-09 20:15:46.524+00	2	\N
250	2	AY2	2NDE	AUT	Plein	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.524+00	2026-03-09 20:15:46.524+00	2	\N
251	2	AY2	2NDE	AUT	RP	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.525+00	2026-03-09 20:15:46.525+00	2	\N
252	2	AY2	2NDE	AUT	R3P	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.525+00	2026-03-09 20:15:46.525+00	2	\N
253	2	AY2	1ERE	FR	Plein	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.526+00	2026-03-09 20:15:46.526+00	2	\N
254	2	AY2	1ERE	FR	RP	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.526+00	2026-03-09 20:15:46.526+00	2	\N
255	2	AY2	1ERE	FR	R3P	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.527+00	2026-03-09 20:15:46.527+00	2	\N
256	2	AY2	1ERE	NAT	Plein	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.527+00	2026-03-09 20:15:46.527+00	2	\N
257	2	AY2	1ERE	NAT	RP	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.528+00	2026-03-09 20:15:46.528+00	2	\N
258	2	AY2	1ERE	NAT	R3P	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.528+00	2026-03-09 20:15:46.528+00	2	\N
259	2	AY2	1ERE	AUT	Plein	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.529+00	2026-03-09 20:15:46.529+00	2	\N
260	2	AY2	1ERE	AUT	RP	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.529+00	2026-03-09 20:15:46.529+00	2	\N
261	2	AY2	1ERE	AUT	R3P	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.53+00	2026-03-09 20:15:46.53+00	2	\N
262	2	AY2	TERM	FR	Plein	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.53+00	2026-03-09 20:15:46.53+00	2	\N
263	2	AY2	TERM	FR	RP	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.531+00	2026-03-09 20:15:46.531+00	2	\N
264	2	AY2	TERM	FR	R3P	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.532+00	2026-03-09 20:15:46.532+00	2	\N
265	2	AY2	TERM	NAT	Plein	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.532+00	2026-03-09 20:15:46.532+00	2	\N
266	2	AY2	TERM	NAT	RP	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.532+00	2026-03-09 20:15:46.532+00	2	\N
267	2	AY2	TERM	NAT	R3P	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.533+00	2026-03-09 20:15:46.533+00	2	\N
268	2	AY2	TERM	AUT	Plein	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.533+00	2026-03-09 20:15:46.533+00	2	\N
269	2	AY2	TERM	AUT	RP	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.534+00	2026-03-09 20:15:46.534+00	2	\N
270	2	AY2	TERM	AUT	R3P	1120.0000	20700.0000	18000.0000	0.0000	0.0000	0.0000	2026-03-09 20:15:46.534+00	2026-03-09 20:15:46.534+00	2	\N
\.


--
-- Data for Name: fiscal_periods; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.fiscal_periods (id, fiscal_year, month, status, actual_version_id, locked_at, locked_by_id, created_at, updated_at, updated_by_id) FROM stdin;
1	2026	1	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
2	2026	2	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
3	2026	3	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
4	2026	4	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
5	2026	5	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
6	2026	6	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
7	2026	7	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
8	2026	8	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
9	2026	9	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
10	2026	10	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
11	2026	11	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
12	2026	12	Draft	\N	\N	\N	2026-03-08 16:33:24.581+00	2026-03-08 16:33:24.581+00	\N
\.


--
-- Data for Name: grade_levels; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.grade_levels (id, grade_code, grade_name, band, max_class_size, plancher_pct, cible_pct, plafond_pct, display_order, version, created_at, updated_at) FROM stdin;
1	PS	Petite Section	MATERNELLE	28	0.7000	0.8000	0.9000	1	1	2026-03-07 22:19:06.426+00	2026-03-08 20:16:39.695+00
2	MS	Moyenne Section	MATERNELLE	28	0.7000	0.8000	0.9000	2	1	2026-03-07 22:19:06.429+00	2026-03-08 20:16:39.698+00
3	GS	Grande Section	MATERNELLE	28	0.7500	0.8500	0.9500	3	1	2026-03-07 22:19:06.43+00	2026-03-08 20:16:39.699+00
4	CP	Cours Preparatoire	ELEMENTAIRE	28	0.7500	0.8500	0.9500	4	1	2026-03-07 22:19:06.43+00	2026-03-08 20:16:39.699+00
5	CE1	Cours Elementaire 1	ELEMENTAIRE	30	0.7500	0.8500	0.9500	5	1	2026-03-07 22:19:06.431+00	2026-03-08 20:16:39.7+00
6	CE2	Cours Elementaire 2	ELEMENTAIRE	30	0.7500	0.8500	0.9500	6	1	2026-03-07 22:19:06.432+00	2026-03-08 20:16:39.7+00
7	CM1	Cours Moyen 1	ELEMENTAIRE	30	0.7500	0.8500	0.9500	7	1	2026-03-07 22:19:06.432+00	2026-03-08 20:16:39.701+00
8	CM2	Cours Moyen 2	ELEMENTAIRE	30	0.7500	0.8500	0.9500	8	1	2026-03-07 22:19:06.433+00	2026-03-08 20:16:39.701+00
9	6EME	Sixieme	COLLEGE	30	0.8000	0.8500	0.9500	9	1	2026-03-07 22:19:06.433+00	2026-03-08 20:16:39.702+00
10	5EME	Cinquieme	COLLEGE	30	0.8000	0.8500	0.9500	10	1	2026-03-07 22:19:06.434+00	2026-03-08 20:16:39.702+00
11	4EME	Quatrieme	COLLEGE	30	0.8000	0.8500	0.9500	11	1	2026-03-07 22:19:06.434+00	2026-03-08 20:16:39.703+00
12	3EME	Troisieme	COLLEGE	30	0.8000	0.8500	0.9500	12	1	2026-03-07 22:19:06.435+00	2026-03-08 20:16:39.703+00
13	2NDE	Seconde	LYCEE	35	0.8000	0.9000	1.0000	13	1	2026-03-07 22:19:06.435+00	2026-03-08 20:16:39.703+00
14	1ERE	Premiere	LYCEE	35	0.8000	0.9000	1.0000	14	1	2026-03-07 22:19:06.435+00	2026-03-08 20:16:39.704+00
15	TERM	Terminale	LYCEE	35	0.8000	0.9000	1.0000	15	1	2026-03-07 22:19:06.436+00	2026-03-08 20:16:39.704+00
\.


--
-- Data for Name: monthly_budget_summary; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.monthly_budget_summary (id, version_id, month, revenue_ht, staff_costs, net_profit, calculated_at) FROM stdin;
\.


--
-- Data for Name: monthly_other_revenue; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.monthly_other_revenue (id, version_id, scenario_name, line_item_name, ifrs_category, executive_category, month, amount, calculated_at, calculated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: monthly_revenue; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.monthly_revenue (id, version_id, scenario_name, academic_period, grade_level, nationality, tariff, month, gross_revenue_ht, discount_amount, scholarship_deduction, net_revenue_ht, vat_amount, calculated_at, calculated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: monthly_staff_costs; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.monthly_staff_costs (id, version_id, employee_id, month, base_gross, adjusted_gross, housing_allowance, transport_allowance, responsibility_premium, hsa_amount, gosi_amount, ajeer_amount, eos_monthly_accrual, total_cost, calculated_at, calculated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: nationalities; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.nationalities (id, code, label, vat_exempt, version, created_at, updated_at, created_by, updated_by) FROM stdin;
1	FR	Francais	f	1	2026-03-09 20:15:46.26+00	2026-03-09 20:19:33.072+00	2	2
2	NAT	Nationaux	f	1	2026-03-09 20:15:46.267+00	2026-03-09 20:19:33.074+00	2	2
3	AUT	Autres	f	1	2026-03-09 20:15:46.268+00	2026-03-09 20:19:33.074+00	2	2
\.


--
-- Data for Name: nationality_breakdown; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.nationality_breakdown (id, version_id, academic_period, grade_level, nationality, weight, headcount, is_overridden, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: other_revenue_items; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.other_revenue_items (id, version_id, line_item_name, annual_amount, distribution_method, weight_array, specific_months, ifrs_category, created_at, updated_at, created_by, updated_by) FROM stdin;
1	2	DAI — Maternelle	600000.0000	ACADEMIC	\N	{}	Registration Fees	2026-03-09 20:15:46.54+00	2026-03-09 20:15:46.54+00	2	\N
2	2	DAI — Elementaire	1100000.0000	ACADEMIC	\N	{}	Registration Fees	2026-03-09 20:15:46.541+00	2026-03-09 20:15:46.541+00	2	\N
3	2	DAI — College	1350000.0000	ACADEMIC	\N	{}	Registration Fees	2026-03-09 20:15:46.542+00	2026-03-09 20:15:46.542+00	2	\N
4	2	DAI — Lycee	905000.0000	ACADEMIC	\N	{}	Registration Fees	2026-03-09 20:15:46.542+00	2026-03-09 20:15:46.542+00	2	\N
5	2	DPI Revenue	450000.0000	SPECIFIC_MONTHS	\N	{1,9}	Registration Fees	2026-03-09 20:15:46.543+00	2026-03-09 20:15:46.543+00	2	\N
6	2	Frais de Dossier	350000.0000	SPECIFIC_MONTHS	\N	{3,4,5}	Registration Fees	2026-03-09 20:15:46.543+00	2026-03-09 20:15:46.543+00	2	\N
7	2	Examination Fees — BAC	78000.0000	SPECIFIC_MONTHS	\N	{3}	Examination Fees	2026-03-09 20:15:46.544+00	2026-03-09 20:15:46.544+00	2	\N
8	2	Examination Fees — DNB	69500.0000	SPECIFIC_MONTHS	\N	{3}	Examination Fees	2026-03-09 20:15:46.544+00	2026-03-09 20:15:46.544+00	2	\N
9	2	Examination Fees — EAF	60000.0000	SPECIFIC_MONTHS	\N	{4}	Examination Fees	2026-03-09 20:15:46.545+00	2026-03-09 20:15:46.545+00	2	\N
10	2	Examination Fees — SIELE	42000.0000	SPECIFIC_MONTHS	\N	{5}	Examination Fees	2026-03-09 20:15:46.545+00	2026-03-09 20:15:46.545+00	2	\N
11	2	After-School Activities	280000.0000	ACADEMIC	\N	{}	Activities & Services	2026-03-09 20:15:46.546+00	2026-03-09 20:15:46.546+00	2	\N
12	2	Daycare Revenue	195000.0000	ACADEMIC	\N	{}	Activities & Services	2026-03-09 20:15:46.546+00	2026-03-09 20:15:46.546+00	2	\N
13	2	Class Photos Revenue	35000.0000	SPECIFIC_MONTHS	\N	{10,11}	Activities & Services	2026-03-09 20:15:46.546+00	2026-03-09 20:15:46.546+00	2	\N
14	2	PSG Academy Rental	120000.0000	EVEN	\N	{}	Activities & Services	2026-03-09 20:15:46.547+00	2026-03-09 20:15:46.547+00	2	\N
15	2	Evaluation Fees	87500.0000	SPECIFIC_MONTHS	\N	{1,2,3}	Registration Fees	2026-03-09 20:15:46.547+00	2026-03-09 20:15:46.547+00	2	\N
16	2	Bourses AEFE	-450000.0000	EVEN	\N	{}	Other Revenue	2026-03-09 20:15:46.548+00	2026-03-09 20:15:46.548+00	2	\N
17	2	Bourses AESH	-120000.0000	EVEN	\N	{}	Other Revenue	2026-03-09 20:15:46.548+00	2026-03-09 20:15:46.548+00	2	\N
18	2	Transport Service — Buses	680000.0000	ACADEMIC	\N	{}	Activities & Services	2026-03-09 20:15:46.549+00	2026-03-09 20:15:46.549+00	2	\N
19	2	Cafeteria Concession	95000.0000	EVEN	\N	{}	Other Revenue	2026-03-09 20:15:46.549+00	2026-03-09 20:15:46.549+00	2	\N
20	2	Uniform Sales Commission	45000.0000	SPECIFIC_MONTHS	\N	{8,9}	Other Revenue	2026-03-09 20:15:46.55+00	2026-03-09 20:15:46.55+00	2	\N
21	2	Summer Camp Revenue	150000.0000	SPECIFIC_MONTHS	\N	{7,8}	Activities & Services	2026-03-09 20:15:46.55+00	2026-03-09 20:15:46.55+00	2	\N
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.refresh_tokens (id, user_id, token_hash, family_id, is_revoked, expires_at, created_at) FROM stdin;
58	1	9aaa4059abc208c6923305d0fe543e84dcf610c4b7c8830c5ba9bf671b0e7429	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:55:01.149+00	2026-03-08 21:55:01.15+00
1	1	0567f0f6f5989b13ef1fbdda4fc60fa0008d4c774ff90456351ad21f43fac5f8	985e34a0-e0c5-429f-a1da-5df8b6852060	t	2026-03-08 06:19:22.078+00	2026-03-07 22:19:22.079+00
59	1	7c0f83c71f10ba1fa3251b8926ad41f9d9d0c273007ec500939ca2a3883c8446	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:55:14.16+00	2026-03-08 21:55:14.161+00
2	1	932a53615bd4ff6fbd93410e9e15113c37d3782473f0d7244f7a0284792eecbc	013b4daf-e306-441e-befd-b4f1162264d6	t	2026-03-08 06:19:28.217+00	2026-03-07 22:19:28.217+00
4	1	8b5cf138efe7337d8860dc577a379d5226311a07d8d64ac1cb745592edd8ed2f	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-08 06:23:31.315+00	2026-03-07 22:23:31.315+00
60	1	7e586e43a40763e96e11144a5e1b284f5bf6c7429e59e832761b1e9ee41a4fa6	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:55:20.123+00	2026-03-08 21:55:20.124+00
5	1	5a280156187255f32f29311df959878e84093428279d5ed4f0e794c505801e48	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-08 07:11:44.606+00	2026-03-07 23:11:44.607+00
6	1	45e1f9d17c7fd82d180450baa48a6df93d544f5e78044aabdcb245a3efd5c306	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-08 07:11:47.973+00	2026-03-07 23:11:47.974+00
7	1	7ed9a7f9ac5ffb7793af928ad4d9e05f73a79ff53a681b3c48b104681fbc6506	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-08 09:31:49.105+00	2026-03-08 01:31:49.106+00
8	1	9e01cf3817a123fc224cd7bf31c5c1de89333c56cdc01aa48c320184b23f3b93	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-08 14:39:34.492+00	2026-03-08 06:39:34.493+00
9	1	db34e30f4aad7b875f2e4010f675f3e92e1b6ff89ecd548ebde0e352758bc8e9	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-08 19:01:49.978+00	2026-03-08 11:01:49.979+00
10	1	9d417a511fdb35ab51d06351b4024012290a53df865bf4d7272cb6e1c955430b	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-08 21:25:44.009+00	2026-03-08 13:25:44.009+00
11	1	cdfdef12030ba76d78500a7fcafe43db0b5f8fcad33fee4a675334821cb4d32c	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-08 21:25:48.121+00	2026-03-08 13:25:48.122+00
12	1	a1851860730d78218e22da27a469135ae168538d69485ab9c8b989f046af6ceb	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-08 21:41:08.192+00	2026-03-08 13:41:08.193+00
13	1	696b39542bf79d920fec407f9550db7bb893ebfef79107484abba3bfe9d9e783	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-08 21:41:09.105+00	2026-03-08 13:41:09.106+00
14	1	bc6b1337fc592a63a07b6dfa428bbce46fa1320e6fe9c5401538fd52698be299	f90f14f9-d8ff-480b-828d-cb4b3488e0c6	t	2026-03-09 00:19:46.261+00	2026-03-08 16:19:46.262+00
15	1	f409756fa34e4302276ead7f01b4c99224a9baffcafdd7c4e501f58f3f641246	2d19ba37-8cb8-40b8-b663-baecb7921c2c	t	2026-03-09 00:31:36.426+00	2026-03-08 16:31:36.426+00
21	1	83f3280738f84e8e4c071b443716894992a79807d04b4c0744f96cc71b65ca0d	1940d1de-1dd7-4c78-a9fe-dc6584763918	t	2026-03-09 01:38:19.159+00	2026-03-08 17:38:19.16+00
23	1	76f150d57a7cf30cfe6d7767b76c30d02755007b08f720027c2826b76ba829b4	4807eb79-5993-42e9-90c5-49d54c324151	t	2026-03-09 01:40:33.257+00	2026-03-08 17:40:33.257+00
22	1	a1db3f2269bbc28cf84c17e106793842a5fe3098d3fce2dbb0d9b74dc3a06cdd	0178110a-99e3-47ea-bd26-1231006ea6e4	t	2026-03-09 01:38:37.109+00	2026-03-08 17:38:37.109+00
24	1	80da89724e0bf9d1a3e47e999a77a616bf8b2259024b0b6c50c373753c2a7d31	4807eb79-5993-42e9-90c5-49d54c324151	t	2026-03-09 02:50:51.806+00	2026-03-08 18:50:51.806+00
25	1	b4e2d2221dab318b9ec1b0ecc64e4207f87bdb1b2aefe62c05ccb34b2ee1c880	0178110a-99e3-47ea-bd26-1231006ea6e4	t	2026-03-09 02:53:09.79+00	2026-03-08 18:53:09.791+00
26	1	e2f05201dbcd873dfa6aa8fd23b8416ccf3de112d565dd8ed4a3954ec697bd86	4807eb79-5993-42e9-90c5-49d54c324151	t	2026-03-09 02:53:09.861+00	2026-03-08 18:53:09.862+00
27	1	737e14327fd971a23ceea702ae656ca4f78bedc0a274f8881a145da1eac5d8c1	0178110a-99e3-47ea-bd26-1231006ea6e4	t	2026-03-09 02:54:16.967+00	2026-03-08 18:54:16.968+00
28	1	5d860f7578226edb003b0285f6bb10e5296803f619204d76e572cf41056956e8	4807eb79-5993-42e9-90c5-49d54c324151	t	2026-03-09 02:54:16.974+00	2026-03-08 18:54:16.975+00
30	1	9f3912db1c546b89a201ee3842bf0b3cc632e5eeb6646f20f98d60ca66396470	0178110a-99e3-47ea-bd26-1231006ea6e4	t	2026-03-09 03:05:46.113+00	2026-03-08 19:05:46.113+00
29	1	1ef3966d7122c9f5d2eac04a8382d8d27b9206c122d818b1283d53fd9b3257ea	4807eb79-5993-42e9-90c5-49d54c324151	t	2026-03-09 03:05:46.112+00	2026-03-08 19:05:46.113+00
32	1	69ea7c224820a44255980a1065f20dd619cb548b4dbd84fd005fe8a06f37494f	4807eb79-5993-42e9-90c5-49d54c324151	t	2026-03-09 03:12:08.685+00	2026-03-08 19:12:08.686+00
33	1	0a329a35e5aed3861af9360325cf96e55cad7db67dfa118cfa1bb1131a2a8f98	4807eb79-5993-42e9-90c5-49d54c324151	t	2026-03-09 03:12:28.157+00	2026-03-08 19:12:28.158+00
31	1	7aef536b548184b53538ed6124e6f787e2fac59a18d3e78c2aec876d23a1f993	0178110a-99e3-47ea-bd26-1231006ea6e4	t	2026-03-09 03:06:46.921+00	2026-03-08 19:06:46.922+00
35	1	614e280b2575d93ed99b77f900bc583049f28d0574b1bf140b3ca59ac01ab42a	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:12:49.965+00	2026-03-08 19:12:49.966+00
36	1	be1b9a6dfbb3652af53b56c8c56a59568ec2d92f732e3afa48c91ff0e46a7f8f	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:13:47.102+00	2026-03-08 19:13:47.103+00
37	1	e2cf84eab7eb538ebecabf0499d3883cff1928b0efb0f7d667ee08f278f4557e	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:14:09.527+00	2026-03-08 19:14:09.528+00
38	1	04062ba6846295145d97d10fdc8072a5c09932a3261d0d80d64080464d60912d	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:16:43.212+00	2026-03-08 19:16:43.212+00
39	1	ba8d946f5b2484eb05df07ab96a34e455bd18a3af38e9f3c6eced0a7f6456179	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:17:10.373+00	2026-03-08 19:17:10.374+00
40	1	983a81569fba12430d2392f82a9f1333a0f715fe7a3b9e8b4a376d4e11ceb970	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:17:29.008+00	2026-03-08 19:17:29.009+00
41	1	3d62b399da72e20f816ee4414f8b6251e76b0c9893730b97a2d12b94e6de2ed9	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:17:49.422+00	2026-03-08 19:17:49.423+00
42	1	a79bd96b5cca72dde008d2748db6ee542ae8f23f8590179017e7e7241eb333a4	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:18:09.113+00	2026-03-08 19:18:09.113+00
43	1	0747b94a08f97e970f943471b6cf56cd0a2924b7c8e13df3db5f5e344ca9bb94	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:18:30.498+00	2026-03-08 19:18:30.498+00
44	1	270634da6aa03fcead8aa3366c47bda72cb57b2a1aebc1bc0e87e0ea57c54103	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:19:47.673+00	2026-03-08 19:19:47.674+00
45	1	e89e5af3fc5b749bfe6f3451f8dca8f5808f792193021a631934d380a5da8e54	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:20:13.043+00	2026-03-08 19:20:13.044+00
46	1	950e9759bbd46f4cd3d17b2d90c027fef9c11d856de732bc276e6ba114e662ea	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:21:31.204+00	2026-03-08 19:21:31.205+00
34	1	c40734802245c5d804217fbb77e3a76f75b90be60fe585889ec77c9fcd46a8b2	4807eb79-5993-42e9-90c5-49d54c324151	t	2026-03-09 03:12:44.397+00	2026-03-08 19:12:44.398+00
47	1	8007694b0267d9ff579e54e90792c7f982119b0cfdb3c2f3ab33e700f39aa7cf	b1e8735b-70bb-4962-8ae2-3fa247728ec9	t	2026-03-09 03:34:16.083+00	2026-03-08 19:34:16.084+00
49	1	5e7d37793882ee98f10820e50a3eb99b53ab67282970f3347859393f3ce1b65a	d8697512-db0b-440c-8c93-d9f57786ceee	t	2026-03-09 03:38:50.939+00	2026-03-08 19:38:50.939+00
48	1	e398a19b6452ef24bbbac38e6325b574c0766f37c85466c50683daaa4e4c13f4	32ec98e7-b1a8-42b3-a445-9952934e2a01	t	2026-03-09 03:35:44.626+00	2026-03-08 19:35:44.627+00
3	1	7b8562caaae4634e60fe865a12a2a01e2cbcfb7d24b830364e14394b5b7cfe57	292ae4b6-30c5-4d73-840e-3ac8ef635fbe	t	2026-03-08 06:20:03.65+00	2026-03-07 22:20:03.651+00
50	1	f90e22228f34dc952ba726d48d7f03aec255cafe5e401b72fa5fd6f9c90e5784	d8697512-db0b-440c-8c93-d9f57786ceee	t	2026-03-09 04:16:48.535+00	2026-03-08 20:16:48.536+00
51	1	059500a34ee76de32182af145ababff5976112648789d24d0135286ba8799489	6cf6edcc-3c4d-42a3-917d-8c203dedf738	t	2026-03-09 04:17:12.895+00	2026-03-08 20:17:12.896+00
52	1	64b1dffbbe20349835228a2f1ca7a5e48f1aff86c8b9c1dbf5db390289d19824	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:50:04.796+00	2026-03-08 21:50:04.797+00
53	1	be4a4b7596c48d9c50a820b117e8cc7186d18941d4c4610079699a4af4b5a1b0	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:54:19.157+00	2026-03-08 21:54:19.158+00
54	1	ad42f8c11d62629cda1e739c2171214e1adcb75f7350d70a723715b8c9ae97e2	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:54:25.111+00	2026-03-08 21:54:25.111+00
55	1	662da2e33088de978ac506092250e63e0f9b4bd7d0752554e098dec4a2ae2cdb	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:54:38.104+00	2026-03-08 21:54:38.105+00
56	1	d9432ad6046777be0a0fd7dab5c6b9a5ab1bce4d0cbed225bfba9f238deb473b	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:54:44.097+00	2026-03-08 21:54:44.097+00
57	1	f5678ecf97e051b6c80ca49183a4f6716b131c0366f9d26c821f2159d56dd6a8	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:54:50.063+00	2026-03-08 21:54:50.064+00
61	1	d213b11bdbee0607519589cf9c5a68e1af44951cd87ec5b92a1b4318b5d916b4	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:55:54.13+00	2026-03-08 21:55:54.131+00
62	1	264476f784d306b11cff31741706b4cc30da9b7ceaba6ccec79b301d747ffa9a	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:55:55.067+00	2026-03-08 21:55:55.067+00
63	1	d79d81e0e6be385966dfd45d093689d6bbb78f135f9f8ade5e37d4040d25e18a	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:56:00.096+00	2026-03-08 21:56:00.097+00
64	1	a283526d45ad42eba530fc0887de420485e985eecabedaff1705858d60cd379a	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:56:13.176+00	2026-03-08 21:56:13.177+00
65	1	9deddbe14dea4fc38eb74fcb394cac5583ecd74d91e85a13cabaed4ec366d307	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:56:24.098+00	2026-03-08 21:56:24.099+00
66	1	bba75ac505c689cfa6bcc2f09f92110692f518e1fe82569c820a7e13d454b38e	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:56:33.237+00	2026-03-08 21:56:33.237+00
67	1	30421b5fb8e6b31dc1ee6881dc00fa09e5a17d4561f793edc90847822c444b0c	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:57:00.133+00	2026-03-08 21:57:00.133+00
68	1	cb1305fc19150e6b3157e0b08f4bd6a1e62b14eb0ebdc330adde2fa59193656e	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:57:05.12+00	2026-03-08 21:57:05.12+00
69	1	90c25d844ca4bcf4f724182d9b76a007a835c38147f0c22f6beff1e1ee682a0d	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 05:57:33.14+00	2026-03-08 21:57:33.141+00
70	1	d3cec048e61bd31c721fa61bb8415140b0c76752a0a09add12c1b8ecff9c5fdb	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 06:01:45.341+00	2026-03-08 22:01:45.342+00
71	1	960548c472abfe6c12697dbd857d488b38b933ed0cab74a0d6a97c27c1e24ca8	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 06:02:16.244+00	2026-03-08 22:02:16.244+00
72	1	b009e30320d78f758f9ad15a7f1323f3faab938e071c3a0cd26fd3331992a372	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 06:47:50.43+00	2026-03-08 22:47:50.431+00
73	1	cf4923305904c8c79fd9e8e5cdaf853885c951fe56466335af1457b6faa7ec57	702fa665-5f28-433a-8df9-aa88adf39afc	t	2026-03-09 06:51:03.295+00	2026-03-08 22:51:03.297+00
74	1	003c9db3f6e3ba82734134b017cc4a1b4452e6565e1534b5b0bbf3c23efbad4c	702fa665-5f28-433a-8df9-aa88adf39afc	f	2026-03-09 14:18:58.212+00	2026-03-09 06:18:58.216+00
75	1	08011e3d54ae964742221613fe3b646023892b886dfe8e8043a88b8d74f97fab	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:06:34.84+00	2026-03-09 16:06:34.841+00
76	1	13223e09bea0dc613ffb514c3a8c42d031b8126eac2e03785db402f44f65b54d	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:08:03.2+00	2026-03-09 16:08:03.201+00
77	1	719fa10a0039b31a0cc72f97c39f47b9f035a33896788a8815f670b228c94b05	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:08:57.885+00	2026-03-09 16:08:57.886+00
78	1	2a51d51b07a0040776ef195e55541c06cfd39b4b934c7b3f1e836e040ffdb95f	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:09:10.85+00	2026-03-09 16:09:10.851+00
79	1	d38104ef1045f482ba2e93be38b649d631b13a87165b4a0ec858a2aa7632985d	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:09:53.424+00	2026-03-09 16:09:53.425+00
80	1	469f3a1b1e0d357a65775d7c3c55fc49c20d78e30b9392eb663c8350620e5627	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:12:34.374+00	2026-03-09 16:12:34.375+00
81	1	e23949cf741913c53387770cba25571e424c364fea7717188eba418740b4b115	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:15:45.456+00	2026-03-09 16:15:45.457+00
82	1	f9c69809bae2209237c925c92b11ead33392379efb2bdc2ff82c7e30cf6ea2a7	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:18:24.26+00	2026-03-09 16:18:24.262+00
83	1	887fca783ab602847abdb56486a8f2235852766fc9a6b656e17ed5da5fe8515e	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:19:18.149+00	2026-03-09 16:19:18.15+00
84	1	028783c5921529f51948cb2050182f81a69235700ffd2e566032fea2896388e7	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:21:31.709+00	2026-03-09 16:21:31.71+00
85	1	ce6660a466582f1c3bc21e03dad3136ba0ce019818a01ea85c702cc98ee843b4	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:30:11.537+00	2026-03-09 16:30:11.538+00
86	1	ae79e8ee3e08753e0edaf521f771785d0d451f4f08bbf416582bf8f9ead9207a	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:30:12.279+00	2026-03-09 16:30:12.28+00
87	1	5cc1b3aefe8fcc7f9d87c3bdf526fb4976cb31b329dff3381f048146c8c51a03	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:30:14.036+00	2026-03-09 16:30:14.037+00
88	1	ccca66b11e6bdb3cad8f3eb2e8c19f0119f2c3d96d54247c3c35bbfb2edc2aee	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:30:16.565+00	2026-03-09 16:30:16.565+00
89	1	c36e734efdcb013a312814ebd87702563a3c7a5b7b47096db38816927df470b8	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:30:17.998+00	2026-03-09 16:30:17.998+00
90	1	c6d59376d651d4821c2c18708c36c622974ae90f6e8e98f09ddc9ed314f709aa	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:30:19.552+00	2026-03-09 16:30:19.552+00
91	1	57a8e0299d7cf4f1da2038d7e72608861266768e22f49f048b4cc5a5fa581920	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:31:57.766+00	2026-03-09 16:31:57.767+00
92	1	768ed6ac631df9f0672878b13af4724c24f59e5773e731663168e488bf12807e	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 00:33:29.121+00	2026-03-09 16:33:29.122+00
93	1	3d5410d532845dc83b091705e71e9e74323456c45a1827ed37595a5eaf133aed	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 01:50:01.853+00	2026-03-09 17:50:01.857+00
94	1	10e3481208fe9ed2d6ffb0c48b33ba526d6c47f784332afb7cced6ce4971acb7	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 01:50:02.485+00	2026-03-09 17:50:02.485+00
95	1	190aa6c421fce017f4313038b0b71bb64afb1416f883b8ec190b1550bdcf131d	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 01:50:03.468+00	2026-03-09 17:50:03.469+00
96	1	d2178e425089a8d72e41c69a023fc6621aba551bebb5f97aa524ba1becc16009	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 01:54:05.508+00	2026-03-09 17:54:05.509+00
97	1	645bd4d08f5f5446928627eef398e40afc9c8299327fc45bb7c1e17f32417b67	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 01:57:44.527+00	2026-03-09 17:57:44.528+00
98	1	ab3ec3b22997b869bf6753b6899afa68cde59cfb07f1677c80591dd398957e4f	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:01:21.666+00	2026-03-09 19:01:21.668+00
99	1	38571d3624c2fdc8c65556a56ef3d09be61e5406fa4bd7c80eaa6362bb5d0018	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:01:22.453+00	2026-03-09 19:01:22.453+00
100	1	5290cba410f8958293a1df78a65f324428a5d6d46ff2664323442aec94f72de3	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:02:49.511+00	2026-03-09 19:02:49.512+00
101	1	ff4e83dc9e31784ee2fd5e9bfcfa492be83385f44b3dd12a1dce251e6e236072	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:17:09.561+00	2026-03-09 19:17:09.562+00
102	1	5f126e154417b1f43d8170d2d29e80d6b52b713170d5828b4ce406da476c83d8	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:17:14.498+00	2026-03-09 19:17:14.499+00
103	1	f35374dce887b16c6b63026f4751a3783630aeb25e396461ea29634de82da662	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:17:38.522+00	2026-03-09 19:17:38.523+00
104	1	e6bfc57ec100c8ffa7a4c83e1a13086bd32cabd5bcb69dfccb54acb628f12675	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:45:34.614+00	2026-03-09 19:45:34.616+00
105	1	e40a2cfa5dde0a4442224fc9a937314dc49b93d9eb598adb05b0695462572b87	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:46:28.523+00	2026-03-09 19:46:28.524+00
106	1	4e28e8c83ea077484883d567fa745ca8d58c681e4f46501f04604f5f2c014d1e	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:47:29.52+00	2026-03-09 19:47:29.52+00
107	1	186d7b865e504f235f75e2c3ddd6f1be64169e7b36580713293456275b0e708d	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:52:43.599+00	2026-03-09 19:52:43.6+00
108	1	f8508549ca7bcb986a5879422af0c6f7fcdff12c81f52ef80b1757f061cc3e5f	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:53:05.583+00	2026-03-09 19:53:05.584+00
109	1	c9b1d2903cd667e5266d131bf5a4ed8d7bfc7e3ecfeb97ef4e22d2729eb7276a	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 03:57:11.565+00	2026-03-09 19:57:11.565+00
110	1	0dcee3608597a9bc2d1052f1878f5bca9d45173c094f046d88850f3f55c53122	63ac93a0-6354-4c24-a4a0-415e262f06f5	t	2026-03-10 04:00:57.622+00	2026-03-09 20:00:57.623+00
111	1	b27480111e4f2a536e88eb37c57032e9e4eb2875138916542ea54e0ef31e3f7d	63ac93a0-6354-4c24-a4a0-415e262f06f5	f	2026-03-10 04:03:42.463+00	2026-03-09 20:03:42.464+00
112	1	20154e70c72126bdfc6500b344610398a12d1659192b58566073341aa7886e7c	9ecc1774-8b98-4cca-acf1-7ce7432dba20	f	2026-03-10 04:03:48.077+00	2026-03-09 20:03:48.078+00
\.


--
-- Data for Name: schema_version; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.schema_version (id, version, applied_at) FROM stdin;
\.


--
-- Data for Name: system_config; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.system_config (key, value, data_type, description, updated_at, updated_by) FROM stdin;
max_sessions_per_user	2	number	Maximum concurrent sessions per user	2026-03-07 22:19:06.402+00	\N
session_timeout_minutes	30	number	Session timeout in minutes	2026-03-07 22:19:06.411+00	\N
lockout_threshold	5	number	Failed login attempts before lockout	2026-03-07 22:19:06.413+00	\N
lockout_duration_minutes	30	number	Lockout duration in minutes	2026-03-07 22:19:06.415+00	\N
fiscal_year_start_month	9	number	Fiscal year start month (1-12)	2026-03-07 22:19:06.42+00	\N
fiscal_year_range	10	number	Fiscal year range in years	2026-03-07 22:19:06.422+00	\N
autosave_interval_seconds	30	number	Auto-save interval in seconds	2026-03-07 22:19:06.423+00	\N
schoolYear	2025-2026	string	Current school year displayed in context bar	2026-03-07 22:19:06.424+00	\N
\.


--
-- Data for Name: tariffs; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.tariffs (id, code, label, description, version, created_at, updated_at, created_by, updated_by) FROM stdin;
3	PLEIN	Plein Tarif	\N	1	2026-03-09 20:19:33.075+00	2026-03-09 20:19:33.075+00	2	2
4	RP	Reduit Personnel	\N	1	2026-03-09 20:19:33.077+00	2026-03-09 20:19:33.077+00	2	2
5	R3P	Reduit 3+	\N	1	2026-03-09 20:19:33.078+00	2026-03-09 20:19:33.078+00	2	2
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.users (id, email, password_hash, role, is_active, failed_attempts, locked_until, force_password_reset, last_login_at, created_at, updated_at) FROM stdin;
1	admin@efir.edu.sa	$2b$12$vGZDrNa/MawU3H7cJFvGI.0clcxYGcAWd17JgyrZ4z0N7nSITcGdK	Admin	t	0	\N	t	2026-03-09 20:03:48.068+00	2026-03-07 22:19:06.393+00	2026-03-09 20:03:48.074+00
2	migration@system	$2b$12$zjYL3WnFLBa38U1A75IMneixRUbmQIKMJEvsXk698DyCRbgSb4WBi	Admin	f	0	\N	f	\N	2026-03-09 20:15:46.255+00	2026-03-09 20:15:46.255+00
\.


--
-- Name: academic_years_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.academic_years_id_seq', 6, true);


--
-- Name: actuals_import_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.actuals_import_log_id_seq', 7, true);


--
-- Name: assumptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.assumptions_id_seq', 1, false);


--
-- Name: audit_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.audit_entries_id_seq', 143, true);


--
-- Name: budget_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.budget_versions_id_seq', 7, true);


--
-- Name: calculation_audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.calculation_audit_log_id_seq', 1, false);


--
-- Name: category_monthly_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.category_monthly_costs_id_seq', 1, false);


--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.chart_of_accounts_id_seq', 77, true);


--
-- Name: cohort_parameters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.cohort_parameters_id_seq', 1, false);


--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.departments_id_seq', 6, true);


--
-- Name: dhg_grille_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.dhg_grille_config_id_seq', 148, true);


--
-- Name: dhg_requirements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.dhg_requirements_id_seq', 1, false);


--
-- Name: discount_policies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.discount_policies_id_seq', 3, true);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.employees_id_seq', 1, false);


--
-- Name: enrollment_detail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.enrollment_detail_id_seq', 214, true);


--
-- Name: enrollment_headcount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.enrollment_headcount_id_seq', 105, true);


--
-- Name: eos_provisions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.eos_provisions_id_seq', 1, false);


--
-- Name: fee_grids_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.fee_grids_id_seq', 270, true);


--
-- Name: fiscal_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.fiscal_periods_id_seq', 12, true);


--
-- Name: grade_levels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.grade_levels_id_seq', 90, true);


--
-- Name: monthly_budget_summary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.monthly_budget_summary_id_seq', 1, false);


--
-- Name: monthly_other_revenue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.monthly_other_revenue_id_seq', 1, false);


--
-- Name: monthly_revenue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.monthly_revenue_id_seq', 1, false);


--
-- Name: monthly_staff_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.monthly_staff_costs_id_seq', 1, false);


--
-- Name: nationalities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.nationalities_id_seq', 6, true);


--
-- Name: nationality_breakdown_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.nationality_breakdown_id_seq', 1, false);


--
-- Name: other_revenue_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.other_revenue_items_id_seq', 21, true);


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.refresh_tokens_id_seq', 112, true);


--
-- Name: tariffs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.tariffs_id_seq', 5, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: academic_years academic_years_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.academic_years
    ADD CONSTRAINT academic_years_pkey PRIMARY KEY (id);


--
-- Name: actuals_import_log actuals_import_log_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.actuals_import_log
    ADD CONSTRAINT actuals_import_log_pkey PRIMARY KEY (id);


--
-- Name: assumptions assumptions_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.assumptions
    ADD CONSTRAINT assumptions_pkey PRIMARY KEY (id);


--
-- Name: audit_entries audit_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.audit_entries
    ADD CONSTRAINT audit_entries_pkey PRIMARY KEY (id);


--
-- Name: budget_versions budget_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.budget_versions
    ADD CONSTRAINT budget_versions_pkey PRIMARY KEY (id);


--
-- Name: calculation_audit_log calculation_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.calculation_audit_log
    ADD CONSTRAINT calculation_audit_log_pkey PRIMARY KEY (id);


--
-- Name: category_monthly_costs category_monthly_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.category_monthly_costs
    ADD CONSTRAINT category_monthly_costs_pkey PRIMARY KEY (id);


--
-- Name: chart_of_accounts chart_of_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_pkey PRIMARY KEY (id);


--
-- Name: cohort_parameters cohort_parameters_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.cohort_parameters
    ADD CONSTRAINT cohort_parameters_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: dhg_grille_config dhg_grille_config_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.dhg_grille_config
    ADD CONSTRAINT dhg_grille_config_pkey PRIMARY KEY (id);


--
-- Name: dhg_requirements dhg_requirements_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.dhg_requirements
    ADD CONSTRAINT dhg_requirements_pkey PRIMARY KEY (id);


--
-- Name: discount_policies discount_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.discount_policies
    ADD CONSTRAINT discount_policies_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: enrollment_detail enrollment_detail_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_detail
    ADD CONSTRAINT enrollment_detail_pkey PRIMARY KEY (id);


--
-- Name: enrollment_headcount enrollment_headcount_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_headcount
    ADD CONSTRAINT enrollment_headcount_pkey PRIMARY KEY (id);


--
-- Name: eos_provisions eos_provisions_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.eos_provisions
    ADD CONSTRAINT eos_provisions_pkey PRIMARY KEY (id);


--
-- Name: fee_grids fee_grids_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.fee_grids
    ADD CONSTRAINT fee_grids_pkey PRIMARY KEY (id);


--
-- Name: fiscal_periods fiscal_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.fiscal_periods
    ADD CONSTRAINT fiscal_periods_pkey PRIMARY KEY (id);


--
-- Name: grade_levels grade_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.grade_levels
    ADD CONSTRAINT grade_levels_pkey PRIMARY KEY (id);


--
-- Name: monthly_budget_summary monthly_budget_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_budget_summary
    ADD CONSTRAINT monthly_budget_summary_pkey PRIMARY KEY (id);


--
-- Name: monthly_other_revenue monthly_other_revenue_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_other_revenue
    ADD CONSTRAINT monthly_other_revenue_pkey PRIMARY KEY (id);


--
-- Name: monthly_revenue monthly_revenue_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_revenue
    ADD CONSTRAINT monthly_revenue_pkey PRIMARY KEY (id);


--
-- Name: monthly_staff_costs monthly_staff_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_staff_costs
    ADD CONSTRAINT monthly_staff_costs_pkey PRIMARY KEY (id);


--
-- Name: nationalities nationalities_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.nationalities
    ADD CONSTRAINT nationalities_pkey PRIMARY KEY (id);


--
-- Name: nationality_breakdown nationality_breakdown_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.nationality_breakdown
    ADD CONSTRAINT nationality_breakdown_pkey PRIMARY KEY (id);


--
-- Name: other_revenue_items other_revenue_items_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.other_revenue_items
    ADD CONSTRAINT other_revenue_items_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: schema_version schema_version_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.schema_version
    ADD CONSTRAINT schema_version_pkey PRIMARY KEY (id);


--
-- Name: system_config system_config_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_pkey PRIMARY KEY (key);


--
-- Name: tariffs tariffs_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.tariffs
    ADD CONSTRAINT tariffs_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: academic_years_fiscal_year_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX academic_years_fiscal_year_key ON public.academic_years USING btree (fiscal_year);


--
-- Name: assumptions_key_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX assumptions_key_key ON public.assumptions USING btree (key);


--
-- Name: chart_of_accounts_account_code_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX chart_of_accounts_account_code_key ON public.chart_of_accounts USING btree (account_code);


--
-- Name: departments_code_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX departments_code_key ON public.departments USING btree (code);


--
-- Name: eos_provisions_employee_id_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX eos_provisions_employee_id_key ON public.eos_provisions USING btree (employee_id);


--
-- Name: grade_levels_grade_code_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX grade_levels_grade_code_key ON public.grade_levels USING btree (grade_code);


--
-- Name: idx_audit_entries_created; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_audit_entries_created ON public.audit_entries USING btree (created_at);


--
-- Name: idx_audit_entries_operation; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_audit_entries_operation ON public.audit_entries USING btree (operation);


--
-- Name: idx_audit_entries_table_record; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_audit_entries_table_record ON public.audit_entries USING btree (table_name, record_id);


--
-- Name: idx_audit_entries_user; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_audit_entries_user ON public.audit_entries USING btree (user_id);


--
-- Name: idx_budget_versions_created_by; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_budget_versions_created_by ON public.budget_versions USING btree (created_by_id);


--
-- Name: idx_budget_versions_fiscal_year; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_budget_versions_fiscal_year ON public.budget_versions USING btree (fiscal_year);


--
-- Name: idx_budget_versions_source; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_budget_versions_source ON public.budget_versions USING btree (source_version_id);


--
-- Name: idx_budget_versions_status; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_budget_versions_status ON public.budget_versions USING btree (status);


--
-- Name: idx_budget_versions_updated_by; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_budget_versions_updated_by ON public.budget_versions USING btree (updated_by_id);


--
-- Name: idx_calc_audit_module_status; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_calc_audit_module_status ON public.calculation_audit_log USING btree (module, status);


--
-- Name: idx_calc_audit_run_id; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_calc_audit_run_id ON public.calculation_audit_log USING btree (run_id);


--
-- Name: idx_calc_audit_triggered_by; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_calc_audit_triggered_by ON public.calculation_audit_log USING btree (triggered_by);


--
-- Name: idx_calc_audit_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_calc_audit_version ON public.calculation_audit_log USING btree (version_id);


--
-- Name: idx_category_monthly_costs_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_category_monthly_costs_version ON public.category_monthly_costs USING btree (version_id);


--
-- Name: idx_cohort_parameters_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_cohort_parameters_version ON public.cohort_parameters USING btree (version_id);


--
-- Name: idx_dhg_grille_grade; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_dhg_grille_grade ON public.dhg_grille_config USING btree (grade_level);


--
-- Name: idx_dhg_requirements_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_dhg_requirements_version ON public.dhg_requirements USING btree (version_id);


--
-- Name: idx_discount_policies_calc; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_discount_policies_calc ON public.discount_policies USING btree (version_id, tariff, nationality);


--
-- Name: idx_discount_policies_created_by; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_discount_policies_created_by ON public.discount_policies USING btree (created_by);


--
-- Name: idx_employees_department; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_employees_department ON public.employees USING btree (version_id, department);


--
-- Name: idx_employees_status; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_employees_status ON public.employees USING btree (version_id, status);


--
-- Name: idx_employees_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_employees_version ON public.employees USING btree (version_id);


--
-- Name: idx_enrollment_detail_version_period_grade; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_enrollment_detail_version_period_grade ON public.enrollment_detail USING btree (version_id, academic_period, grade_level);


--
-- Name: idx_enrollment_headcount_version_period; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_enrollment_headcount_version_period ON public.enrollment_headcount USING btree (version_id, academic_period);


--
-- Name: idx_eos_provisions_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_eos_provisions_version ON public.eos_provisions USING btree (version_id);


--
-- Name: idx_fee_grids_created_by; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_fee_grids_created_by ON public.fee_grids USING btree (created_by);


--
-- Name: idx_fee_grids_revenue_calc; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_fee_grids_revenue_calc ON public.fee_grids USING btree (version_id, academic_period, grade_level, nationality, tariff);


--
-- Name: idx_fiscal_periods_actual_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_fiscal_periods_actual_version ON public.fiscal_periods USING btree (actual_version_id);


--
-- Name: idx_fiscal_periods_fiscal_year; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_fiscal_periods_fiscal_year ON public.fiscal_periods USING btree (fiscal_year);


--
-- Name: idx_fiscal_periods_locked_by; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_fiscal_periods_locked_by ON public.fiscal_periods USING btree (locked_by_id);


--
-- Name: idx_fiscal_periods_updated_by; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_fiscal_periods_updated_by ON public.fiscal_periods USING btree (updated_by_id);


--
-- Name: idx_monthly_other_revenue_calculated_by; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_monthly_other_revenue_calculated_by ON public.monthly_other_revenue USING btree (calculated_by);


--
-- Name: idx_monthly_other_revenue_version_category; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_monthly_other_revenue_version_category ON public.monthly_other_revenue USING btree (version_id, executive_category);


--
-- Name: idx_monthly_other_revenue_version_month; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_monthly_other_revenue_version_month ON public.monthly_other_revenue USING btree (version_id, month);


--
-- Name: idx_monthly_revenue_calculated_by; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_monthly_revenue_calculated_by ON public.monthly_revenue USING btree (calculated_by);


--
-- Name: idx_monthly_revenue_version_month; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_monthly_revenue_version_month ON public.monthly_revenue USING btree (version_id, month);


--
-- Name: idx_monthly_revenue_version_period; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_monthly_revenue_version_period ON public.monthly_revenue USING btree (version_id, academic_period);


--
-- Name: idx_monthly_staff_costs_employee; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_monthly_staff_costs_employee ON public.monthly_staff_costs USING btree (employee_id);


--
-- Name: idx_monthly_staff_costs_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_monthly_staff_costs_version ON public.monthly_staff_costs USING btree (version_id);


--
-- Name: idx_monthly_staff_costs_version_month; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_monthly_staff_costs_version_month ON public.monthly_staff_costs USING btree (version_id, month);


--
-- Name: idx_monthly_summary_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_monthly_summary_version ON public.monthly_budget_summary USING btree (version_id);


--
-- Name: idx_nationality_breakdown_version_period; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_nationality_breakdown_version_period ON public.nationality_breakdown USING btree (version_id, academic_period);


--
-- Name: idx_other_revenue_items_created_by; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_other_revenue_items_created_by ON public.other_revenue_items USING btree (created_by);


--
-- Name: idx_other_revenue_items_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_other_revenue_items_version ON public.other_revenue_items USING btree (version_id);


--
-- Name: idx_refresh_tokens_expires; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_refresh_tokens_expires ON public.refresh_tokens USING btree (expires_at);


--
-- Name: idx_refresh_tokens_family; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_refresh_tokens_family ON public.refresh_tokens USING btree (family_id);


--
-- Name: idx_refresh_tokens_user_active; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_refresh_tokens_user_active ON public.refresh_tokens USING btree (user_id, is_revoked);


--
-- Name: nationalities_code_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX nationalities_code_key ON public.nationalities USING btree (code);


--
-- Name: refresh_tokens_token_hash_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX refresh_tokens_token_hash_key ON public.refresh_tokens USING btree (token_hash);


--
-- Name: tariffs_code_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX tariffs_code_key ON public.tariffs USING btree (code);


--
-- Name: uq_budget_version_name_fy; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_budget_version_name_fy ON public.budget_versions USING btree (fiscal_year, name);


--
-- Name: uq_category_monthly_cost; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_category_monthly_cost ON public.category_monthly_costs USING btree (version_id, month, category);


--
-- Name: uq_cohort_parameter; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_cohort_parameter ON public.cohort_parameters USING btree (version_id, grade_level);


--
-- Name: uq_dhg_grille; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_dhg_grille ON public.dhg_grille_config USING btree (grade_level, subject, effective_from_year);


--
-- Name: uq_dhg_requirement; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_dhg_requirement ON public.dhg_requirements USING btree (version_id, academic_period, grade_level);


--
-- Name: uq_discount_policy; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_discount_policy ON public.discount_policies USING btree (version_id, tariff, nationality);


--
-- Name: uq_employee_code_version; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_employee_code_version ON public.employees USING btree (version_id, employee_code);


--
-- Name: uq_enrollment_detail; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_enrollment_detail ON public.enrollment_detail USING btree (version_id, academic_period, grade_level, nationality, tariff);


--
-- Name: uq_enrollment_headcount; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_enrollment_headcount ON public.enrollment_headcount USING btree (version_id, academic_period, grade_level);


--
-- Name: uq_eos_provision; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_eos_provision ON public.eos_provisions USING btree (version_id, employee_id);


--
-- Name: uq_fee_grid; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_fee_grid ON public.fee_grids USING btree (version_id, academic_period, grade_level, nationality, tariff);


--
-- Name: uq_fiscal_period; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_fiscal_period ON public.fiscal_periods USING btree (fiscal_year, month);


--
-- Name: uq_monthly_other_revenue; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_monthly_other_revenue ON public.monthly_other_revenue USING btree (version_id, scenario_name, line_item_name, month);


--
-- Name: uq_monthly_revenue; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_monthly_revenue ON public.monthly_revenue USING btree (version_id, scenario_name, academic_period, grade_level, nationality, tariff, month);


--
-- Name: uq_monthly_staff_cost; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_monthly_staff_cost ON public.monthly_staff_costs USING btree (version_id, employee_id, month);


--
-- Name: uq_monthly_summary; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_monthly_summary ON public.monthly_budget_summary USING btree (version_id, month);


--
-- Name: uq_nationality_breakdown; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_nationality_breakdown ON public.nationality_breakdown USING btree (version_id, academic_period, grade_level, nationality);


--
-- Name: uq_other_revenue_item; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX uq_other_revenue_item ON public.other_revenue_items USING btree (version_id, line_item_name);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: academic_years academic_years_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.academic_years
    ADD CONSTRAINT academic_years_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: academic_years academic_years_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.academic_years
    ADD CONSTRAINT academic_years_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: actuals_import_log actuals_import_log_imported_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.actuals_import_log
    ADD CONSTRAINT actuals_import_log_imported_by_id_fkey FOREIGN KEY (imported_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: actuals_import_log actuals_import_log_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.actuals_import_log
    ADD CONSTRAINT actuals_import_log_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: assumptions assumptions_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.assumptions
    ADD CONSTRAINT assumptions_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: audit_entries audit_entries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.audit_entries
    ADD CONSTRAINT audit_entries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: budget_versions budget_versions_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.budget_versions
    ADD CONSTRAINT budget_versions_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: budget_versions budget_versions_source_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.budget_versions
    ADD CONSTRAINT budget_versions_source_version_id_fkey FOREIGN KEY (source_version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: budget_versions budget_versions_updated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.budget_versions
    ADD CONSTRAINT budget_versions_updated_by_id_fkey FOREIGN KEY (updated_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: calculation_audit_log calculation_audit_log_triggered_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.calculation_audit_log
    ADD CONSTRAINT calculation_audit_log_triggered_by_fkey FOREIGN KEY (triggered_by) REFERENCES public.users(id);


--
-- Name: calculation_audit_log calculation_audit_log_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.calculation_audit_log
    ADD CONSTRAINT calculation_audit_log_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: category_monthly_costs category_monthly_costs_calculated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.category_monthly_costs
    ADD CONSTRAINT category_monthly_costs_calculated_by_fkey FOREIGN KEY (calculated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: category_monthly_costs category_monthly_costs_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.category_monthly_costs
    ADD CONSTRAINT category_monthly_costs_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chart_of_accounts chart_of_accounts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: chart_of_accounts chart_of_accounts_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: cohort_parameters cohort_parameters_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.cohort_parameters
    ADD CONSTRAINT cohort_parameters_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON DELETE CASCADE;


--
-- Name: departments departments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: departments departments_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: dhg_requirements dhg_requirements_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.dhg_requirements
    ADD CONSTRAINT dhg_requirements_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON DELETE CASCADE;


--
-- Name: discount_policies discount_policies_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.discount_policies
    ADD CONSTRAINT discount_policies_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: discount_policies discount_policies_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.discount_policies
    ADD CONSTRAINT discount_policies_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: discount_policies discount_policies_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.discount_policies
    ADD CONSTRAINT discount_policies_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: employees employees_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: employees employees_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: employees employees_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: enrollment_detail enrollment_detail_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_detail
    ADD CONSTRAINT enrollment_detail_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: enrollment_detail enrollment_detail_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_detail
    ADD CONSTRAINT enrollment_detail_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: enrollment_detail enrollment_detail_version_id_academic_period_grade_level_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_detail
    ADD CONSTRAINT enrollment_detail_version_id_academic_period_grade_level_fkey FOREIGN KEY (version_id, academic_period, grade_level) REFERENCES public.enrollment_headcount(version_id, academic_period, grade_level) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: enrollment_detail enrollment_detail_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_detail
    ADD CONSTRAINT enrollment_detail_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: enrollment_headcount enrollment_headcount_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_headcount
    ADD CONSTRAINT enrollment_headcount_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: enrollment_headcount enrollment_headcount_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_headcount
    ADD CONSTRAINT enrollment_headcount_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: enrollment_headcount enrollment_headcount_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.enrollment_headcount
    ADD CONSTRAINT enrollment_headcount_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: eos_provisions eos_provisions_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.eos_provisions
    ADD CONSTRAINT eos_provisions_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: eos_provisions eos_provisions_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.eos_provisions
    ADD CONSTRAINT eos_provisions_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fee_grids fee_grids_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.fee_grids
    ADD CONSTRAINT fee_grids_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: fee_grids fee_grids_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.fee_grids
    ADD CONSTRAINT fee_grids_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fee_grids fee_grids_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.fee_grids
    ADD CONSTRAINT fee_grids_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fiscal_periods fiscal_periods_actual_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.fiscal_periods
    ADD CONSTRAINT fiscal_periods_actual_version_id_fkey FOREIGN KEY (actual_version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fiscal_periods fiscal_periods_locked_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.fiscal_periods
    ADD CONSTRAINT fiscal_periods_locked_by_id_fkey FOREIGN KEY (locked_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fiscal_periods fiscal_periods_updated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.fiscal_periods
    ADD CONSTRAINT fiscal_periods_updated_by_id_fkey FOREIGN KEY (updated_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: monthly_budget_summary monthly_budget_summary_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_budget_summary
    ADD CONSTRAINT monthly_budget_summary_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: monthly_other_revenue monthly_other_revenue_calculated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_other_revenue
    ADD CONSTRAINT monthly_other_revenue_calculated_by_fkey FOREIGN KEY (calculated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: monthly_other_revenue monthly_other_revenue_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_other_revenue
    ADD CONSTRAINT monthly_other_revenue_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: monthly_revenue monthly_revenue_calculated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_revenue
    ADD CONSTRAINT monthly_revenue_calculated_by_fkey FOREIGN KEY (calculated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: monthly_revenue monthly_revenue_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_revenue
    ADD CONSTRAINT monthly_revenue_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: monthly_staff_costs monthly_staff_costs_calculated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_staff_costs
    ADD CONSTRAINT monthly_staff_costs_calculated_by_fkey FOREIGN KEY (calculated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: monthly_staff_costs monthly_staff_costs_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_staff_costs
    ADD CONSTRAINT monthly_staff_costs_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: monthly_staff_costs monthly_staff_costs_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.monthly_staff_costs
    ADD CONSTRAINT monthly_staff_costs_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: nationalities nationalities_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.nationalities
    ADD CONSTRAINT nationalities_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: nationalities nationalities_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.nationalities
    ADD CONSTRAINT nationalities_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: nationality_breakdown nationality_breakdown_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.nationality_breakdown
    ADD CONSTRAINT nationality_breakdown_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON DELETE CASCADE;


--
-- Name: other_revenue_items other_revenue_items_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.other_revenue_items
    ADD CONSTRAINT other_revenue_items_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: other_revenue_items other_revenue_items_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.other_revenue_items
    ADD CONSTRAINT other_revenue_items_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: other_revenue_items other_revenue_items_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.other_revenue_items
    ADD CONSTRAINT other_revenue_items_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: system_config system_config_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tariffs tariffs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.tariffs
    ADD CONSTRAINT tariffs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tariffs tariffs_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.tariffs
    ADD CONSTRAINT tariffs_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TABLE audit_entries; Type: ACL; Schema: public; Owner: app_user
--

REVOKE SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.audit_entries FROM app_user;
GRANT SELECT,INSERT,REFERENCES,TRIGGER,TRUNCATE ON TABLE public.audit_entries TO app_user;


--
-- PostgreSQL database dump complete
--

\unrestrict 14oWCJj2iBoqxpg1OUC9VhKwq76vMlsPw7uG0coawRUnGRS3oz5wwIP8LksXEgv

